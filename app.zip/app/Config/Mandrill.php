<?php

$config['mandrill_api_key'] = '316f1f8ed28363c44b8e3dd0ef4fc178-us9';