<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Auth::index');
$routes->get('/logout', 'Auth::logout');
$routes->group('', ['filter'=>'AuthCheck'],function($routes){
    //echo $_SERVER['loggeduserstatus'];
    $routes->get('/dashboard', 'Dashboard::index');
    $routes->get('/dashboard/activate/(:num)', 'Dashboard::activate/$1');
    $routes->get('/dashboard/deactivate/(:num)', 'Dashboard::deactivate/$1');
    $routes->get('/dashboard/delete/(:num)', 'Dashboard::delete/$1');
    $routes->get('/dashboard/users', 'Dashboard::users');

    $routes->get('/corporatAdminMng', 'CorporateAdminMng::index');
    $routes->get('/CorporateAdminMng/addNew', 'CorporateAdminMng::addNew');
    $routes->get('/CorporateAdminMng/edit', 'CorporateAdminMng::edit');
    $routes->get('/CorporateAdminMng/delete/(:num)', 'CorporateAdminMng::delete/$1');

    $routes->get('/DriverMng', 'DriverMng::index');
    $routes->get('/DriverMng/addNew', 'DriverMng::addNew');
    $routes->get('/DriverMng/edit/(:num)', 'DriverMng::edit/$1');
    $routes->get('DriverMng/delete/(:num)', 'DriverMng::delete/$1');

    $routes->get('/CarPreferenceMng', 'CarPreferenceMng::index');
    $routes->get('/CarPrerenceMng/edit/(:num)', 'CarPreferenceMng::edit/$1');
    $routes->get('/CarPrerenceMng/delete/(:num)', 'CarPreferenceMng::delete/$1');
    
    $routes->get('/regular_registrations', 'Regular_registrations::index');
    $routes->get('/regular_registrations/delete/(:num)', 'Regular_registrations::delete/$1');

    $routes->get('/corporate_registrations', 'Corporate_registrations::index');
    
    $routes->get('/booking/trip-booking', 'Booking::index');
    $routes->get('/booking/corporate', 'Booking::corporate');
    $routes->get('/booking/delete/(:num)', 'Booking::delete/$1');
    $routes->get('/booking/approve/(:num)', 'Booking::approve/$1');
    $routes->add('/booking/tripBooking', 'Booking::regular');
    $routes->get('/booking/save', 'Booking::save');
    $routes->get('/booking/view/(:any)', 'Booking::view/$1');  
    $routes->get('/booking/assign', 'Booking::assign');
    $routes->get('/booking/edit/(:num)', 'Booking::edit/$1');
    $routes->get('/booking/editTrip/(:num)', 'Booking::editTrip/$1');
    $routes->get('/booking/regularEditTrip/(:num)', 'Booking::regularEditTrip/$1');
    $routes->get('/booking/corporateEditTrip/(:num)', 'Booking::corporateEditTrip/$1');
    $routes->get('/booking/editBooking/(:num)', 'Booking::editBooking/$1');
    $routes->get('/booking/approve_assign/(:num)', 'Booking::approve_assign/$1');
    $routes->get('/booking/viewCorporateBooking/(:any)', 'Booking::viewCorporateBooking/$1');
    $routes->get('/booking/approve_assign_corporate/(:num)', 'Booking::approve_assign_corporate/$1');   
    $routes->get('/booking/viewReports', 'Booking::viewReports');
    $routes->get('/booking/export', 'Booking::export');
    $routes->get('/auth/resetPassword', 'Auth::resetPassword');
    $routes->get('auth/edituserProfile', 'Auth::edituserProfile'); 
    $routes->get('/booking/mainviewReports', 'Booking::mainviewReports');
    $routes->get('/booking/mainexport', 'Booking::mainexport'); 

    $routes->get('/Jobcards', 'Jobcards::index');
    $routes->get('/FleetMng', 'FleetMng::index');
        
    $routes->get('/suppliers', 'Suppliers::index');
    $routes->get('/suppliers/addNew', 'Suppliers::addNew');
    $routes->get('/suppliers/edit/(:num)', 'Suppliers::edit/$1');
    $routes->get('/suppliers/delete/(:num)', 'Suppliers::delete/$1');

    
    
    
});
/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
