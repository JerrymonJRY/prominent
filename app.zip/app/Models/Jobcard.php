<?php

namespace App\Models;

use CodeIgniter\Model;

class Jobcard extends Model
{
   
    protected $table='job_card';
    protected $primaryKey = 'job_id';
    protected $allowedFields = ['driver_id', 'booking_id', 'date', 'time', 'assigned_date', 'active', 'supplier_id'];
    
}
?>
