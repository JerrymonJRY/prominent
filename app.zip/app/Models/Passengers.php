<?php

namespace App\Models;

use CodeIgniter\Model;

class Passengers extends Model
{
   
    protected $table='passengers';
    protected $primaryKey = 'passenger_id';
    protected $allowedFields = ['passenger_name', 'passenger_contact','passenger_location', 'booking_id'];
    
}
?>
