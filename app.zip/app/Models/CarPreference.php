<?php

namespace App\Models;

use CodeIgniter\Model;

class CarPreference extends Model
{
   
    protected $table='cartype';
    protected $primaryKey = 'ct_id';
    protected $allowedFields = ['ct_type', 'ct_created_date', 'cl_lastUpdated_date'];
    
}
?>
