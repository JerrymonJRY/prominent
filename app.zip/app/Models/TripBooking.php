<?php

namespace App\Models;

use CodeIgniter\Model;

class TripBooking extends Model
{
   
    protected $table='trip_booking';
    protected $primaryKey = 'booking_id';
    protected $allowedFields = ['carType_id', 'bookType_id', 'booking_date', 'booking_time', 'tripType_id',
                                'booking_from', 'booking_to', 'booking_stop', 'booking_NoPassengers', 'booking_projectCode',
                                'sadmin_approval', 'cadmin_approval', 'booking_createdDate', 'booking_cadmin_date',
                                'booking_sadmin_date','user_id', 'user_type', 'company_Id', 'assign_dr_supp','booking_return_time',
                                'cadmin_reason_cancel','sadmin_reason_cancel','driver_note','booking_amount','booking_taskCode',
                                'booking_remarks','booking_department'];
    
}
?>
