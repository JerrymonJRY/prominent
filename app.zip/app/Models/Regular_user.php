<?php

namespace App\Models;

use CodeIgniter\Model;

class Regular_user extends Model
{
   
    protected $table='regular_user';
    protected $primaryKey = 'reg_id';
    protected $allowedFields = ['reg_name','reg_contactCode', 'reg_contact', 'reg_email', 'user_id'];
    
}
?>
