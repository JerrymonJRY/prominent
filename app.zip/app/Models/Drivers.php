<?php

namespace App\Models;

use CodeIgniter\Model;

class Drivers extends Model
{
   
    protected $table='drivers';
    protected $primaryKey = 'driver_id';
    protected $allowedFields = ['driver_name', 'driver_nationality', 'driver_contact', 'driver_email', 
                                'driver_address', 'driver_license', 'driver_license_exp', 'driver_emirates_id',
                                'driver_emirates_exp', 'driver_photo', 'driver_createdDate', 'driver_lastUpdatedDate',
                                'driver_address_india','driver_dob', 'driver_emergency_contact', 'driver_emergency_contactIn',
                                'driver_passport_no', 'driver_passport_exp','driver_visa_no', 'driver_visa_exp',
                                'driver_limousin_Permit_no', 'driver_limousin_Permit_exp', 'driver_leave_date',
                                'driver_return_date', 'driver_no_offdays','driver_daman_exp','driver_join_date','driver_history',
                                'driver_vehicle_model','driver_plate_no'];
    
}
?>
