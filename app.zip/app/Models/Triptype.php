<?php

namespace App\Models;

use CodeIgniter\Model;

class Triptype extends Model
{
   
    protected $table='trip_type';
    protected $primaryKey = 'trt_id';
    protected $allowedFields = ['trt_type', 'trt_created_date', 'trl_lastUpdated_date'];
    
}
?>
