<?php

namespace App\Models;

use CodeIgniter\Model;

class User extends Model
{
   
    protected $table='users';
    protected $primaryKey = 'user_id';
    protected $allowedFields = ['user_username', 'user_password', 'user_status', 'user_role', 'user_active', 'user_created_date', 'user_updated_date'];
    
    protected $beforeInsert = ['beforeInsert'];
    protected $beforeUpdate = ['beforeUpdate'];
    
    protected function beforeInsert(array $data) {
        
        $data = $this->passwordHash($data);
        
        return $data;
    }
    
    protected function beforeUpdate(array $data) {
        $data = $this->passwordHash($data);
        return $data;
    }

    protected function passwordHash(array $data){
        if(isset($data['data']['user_password']))
            $data['data']['user_password'] = password_hash($data['data']['user_password'], PASSWORD_DEFAULT);
        return $data;
    }

    public function checkPassword($enteredPassword,$dbPassword){
        if(password_verify($enteredPassword,$dbPassword)){
            return true;
        }else{
            return false;
        }
    }

    
    
}
?>
