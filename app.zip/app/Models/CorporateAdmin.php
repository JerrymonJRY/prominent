<?php

namespace App\Models;

use CodeIgniter\Model;

class CorporateAdmin extends Model
{
   
    protected $table='corporate_admin';
    protected $primaryKey = 'cadmin_id';
    protected $allowedFields = ['cadmin_companyName', 'cadmin_email', 'cadmin_contact', 'cadmin_contactPerson', 
                                'cadmin_address', 'cadmin_companyCode', 'user_id', 'cadmin_tradeLNo', 
                                 'cadmin_vatNo', 'cadmin_acc_email', 'cadmin_acc_no', 'cadmin_adm_email', 'cadmin_adm_no'];
    
}
?>
