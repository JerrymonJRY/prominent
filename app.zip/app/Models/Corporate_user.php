<?php

namespace App\Models;

use CodeIgniter\Model;

class Corporate_user extends Model
{
   
    protected $table='corporate_users';
    protected $primaryKey = 'cor_id';
   protected $allowedFields = ['cor_name','cor_contactCode','cor_contact', 'cor_email', 'cor_companyID', 'cor_employeeId','user_id'];
    
}
?>
