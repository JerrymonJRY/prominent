<?php

namespace App\Models;

use CodeIgniter\Model;

class Fleet extends Model
{
   
    protected $table='fleet';
    protected $primaryKey = 'Id';
    protected $allowedFields = ['Name', 'Thumbnail','Background', 'Specifications', 'Features', 'Description', 'Whychoose', 'Type', 'GalleryImages','created_date','last_updated','starting_price'];
    
}
?>