<?php

namespace App\Models;

use CodeIgniter\Model;

class Supplier extends Model
{
   
    protected $table='supplier';
    protected $primaryKey = 'sup_id';
    protected $allowedFields = ['sup_name', 'sup_tel', 'sup_email','sup_created_date','sup_updated_date',
                                'sup_reservation_contact','sup_reservation_email','sup_acc_email','sup_acc_contact',
                                'sup_bank_acc'];
    
}
?>
