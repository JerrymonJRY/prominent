<?php

namespace App\Models;

use CodeIgniter\Model;

class Booktype extends Model
{
   
    protected $table='book_type';
    protected $primaryKey = 'bt_id';
    protected $allowedFields = ['bt_type', 'bt_created_date', 'bl_lastUpdated_date'];
    
}
?>
