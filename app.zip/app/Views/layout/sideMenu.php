

<nav class="pcoded-navbar">

<div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>

<div class="pcoded-inner-navbar main-menu">

<ul class="pcoded-item pcoded-left-item">

<?php if($status==1){?>  

        <li <?=($active=='index')?'class="active"':'';?>>
            <a href="<?=base_url('dashboard')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li <?=($active=='corporateAdmin')?'class="active"':'';?> >
            <a href="<?=base_url('corporatAdminMng')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Corporate Admin Management</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li <?=($active=='driver')?'class="active"':'';?>>
            <a href="<?=base_url('DriverMng')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Driver Management</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        <li <?=($active=='supplier')?'class="active"':'';?>>
            <a href="<?=base_url('suppliers')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Supplier Management</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li <?=($active=='car')?'class="active"':'';?>>
            <a href="<?=base_url('CarPreferenceMng')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Car Preference</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li class="pcoded-hasmenu <?=($active=='customer')?'active':'';?> <?=($active=='customer')?'pcoded-trigger':'';?> "  >
            <a href="javascript:void(0)" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Customer Registrations </span> 
                <span class="pcoded-mcaret"></span>
            </a>
            <ul class="pcoded-submenu">
                <li <?=($sub=='regular')?'class="active"':'';?> >
                    <a href="<?=base_url('regular_registrations');?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                        <span class="pcoded-mtext active" data-i18n="nav.basic-components.alert">Regular Registrations</span>
                        <span class="pcoded-mcaret"></span>
                    </a>
                </li>

                <li  <?=($sub=='corporate')?'class="active"':'';?>>
                    <a href="<?=base_url('corporate_registrations');?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                        <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Corporate Registrations </span>
                        <span class="pcoded-mcaret"></span>
                    </a>
                </li>
            </ul>
        </li>


        <li <?=($active=='view')?'class="active"':'';?>>
            <a href="<?=base_url('booking/view/new')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">View Bookings</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li <?=($active=='jobcard')?'class="active"':'';?>>
            <a href="<?=base_url('Jobcards')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">View Job-Cards</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        <!-- added by shifa 8/6/2022 -->
        <li <?=($active=='fleet')?'class="active"':'';?>>
            <a href="<?=base_url('FleetMng')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Fleet Management</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li <?=($active=='report')?'class="active"':'';?> >
            <a href="<?=base_url('booking/mainviewReports')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Reports</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <!--<li class="">
            <a href="#" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">User Management</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>        

        <li class="">
            <a href="#" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">User Logs</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

        <li class="">
            <a href="#" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Reports</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>-->



   
<?php }else if($status==2){?>
  
        <li <?=($active=='index')?'class="active"':'';?>>
            <a href="<?=base_url('dashboard')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                <span class="pcoded-mcaret"></span>
            </a>
         </li>

         <li <?=($active=='view')?'class="active"':'';?> >
            <a href="<?=base_url('booking/viewCorporateBooking/all')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Bookings</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        <li <?=($active=='report')?'class="active"':'';?> >
            <a href="<?=base_url('booking/viewReports')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Reports</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        
        <li <?=($active=='users')?'class="active"':'';?> >
            <a href="<?=base_url('dashboard/users')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Users</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

<?php }else if($status==3){ ?>
        <li <?=($active=='index')?'class="active"':'';?>>
            <a href="<?=base_url('dashboard')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        <li <?=($active=='book')?'class="active"':'';?> >
            <a href="<?=base_url('booking/tripBooking')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Trip Booking</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

       
<?php } else { ?>
        <li <?=($active=='index')?'class="active"':'';?>>
            <a href="<?=base_url('dashboard')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        <li <?=($active=='book')?'class="active"':'';?> >
            <a href="<?=base_url('booking/trip-booking')?>" class="waves-effect waves-dark">
                <span class="pcoded-micon"><i class="ti-direction-alt"></i><b>D</b></span>
                <span class="pcoded-mtext" data-i18n="nav.dash.main">Trip Booking</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>

       
<?php } ?>
</ul>
</div>

</nav>