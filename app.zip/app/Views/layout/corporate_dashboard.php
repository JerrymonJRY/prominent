<div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-body start -->
                                    <div class="page-body ">
                                        <div class="row dashboard">
                                            <!-- task, page, download counter  start -->
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card totalamount-current-month-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 text-left">
                                                                
                                                            </div>
                                                            <div class="col-12">
                                                                <h4 class="text-white"><?=$curr_total;?></h4>
                                                                <h6 class="text-white m-b-0">Number of bookings in <?php echo date('F');?> </h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card totalamount-last-month-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 text-lrft">
                                                               
                                                            </div>
                                                            <div class="col-12">
                                                                <h4 class="text-white"><?=$prev_total;?></h4>
                                                                <h6 class="text-white m-b-0"> Number of bookings in 
                                                                                            <?php
                                                                                                $d=strtotime("-1 Months");
                                                                                                echo date("F", $d); 
                                                                                            ?></h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card total-booking-this-year-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 text-lrft">
                                                                
                                                            </div>
                                                            <div class="col-12">
                                                                <h4 class="text-white"><?=$total;?></h4>
                                                                <h6 class="text-white m-b-0">Total number of bookings</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- task, page, download counter  end -->

                                            <!--  sale analytics start -->

                                        </div>
                                        <div class="row">
                                            <div class="col-12 mt-3 mb-3">
                                                <hr>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-xl-12 col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Monthwise Bookings Graph <?=date('Y');?></h5>
                                                    </div>
                                                    <div class="card-block" id="bar_month_wise">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-12 col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Monthwise Amount Graph <?=date('Y');?></h5>
                                                    </div>
                                                    <div class="card-block" id="bar_month_wise_total">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <!-- Page-body end -->
                                </div>
<script>
 
 // Draw the bar chart for registered users year wise
 google.charts.setOnLoadCallback(barChart);
  
 // for
 function barChart() {
    //Monthly bookings graph
   /* Define the chart to be drawn.*/
   var data = google.visualization.arrayToDataTable([
       ['Month', 'Bookings'],     
    
       <?php 
       
        foreach ($get_graph as $row){
        echo "['".$row['barmonth']."',".$row['counter']."],";
        }
        ?>
   ]);
   var options = {
       //title: 'Year wise Registered Users Bar Chart',
       is3D: true,
       width:900,
        height:500,
      
         };
   /* Instantiate and draw the chart.*/
   var chart = new google.visualization.ColumnChart(document.getElementById('bar_month_wise'));
   chart.draw(data, options);

   //Monthly Total Amount graph
 /* Define the chart to be drawn.*/
 var data2 = google.visualization.arrayToDataTable([
       ['Month', 'Amount',{ role: 'style' } ],        
       <?php 
       
        foreach ($get_graph_total as $rows){
        echo "['".$rows['barmonth']."',".$rows['total'].",'#b87333'],";
        }
        ?>
   ]);
  
   var options2 = {
       //title: 'Year wise Registered Users Bar Chart',
       is3D: true,
       width:900,
        height:500,
         };
   /* Instantiate and draw the chart.*/
   var chart2 = new google.visualization.ColumnChart(document.getElementById('bar_month_wise_total'));
   chart2.draw(data2, options2);

 }
</script>
                  