
                                    <!-- Page-body start -->
                                    <div class="page-body ">
                                        <div class="row dashboard">
                                            <!-- task, page, download counter  start -->
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card total-booking-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$total?></h4>
                                                                <h6 class="text-white m-b-0">Total Booking</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-right">
                                                                <i class="fa fa-file-text-o f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card total-regular-booking-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$totalReg?></h4>
                                                                <h6 class="text-white m-b-0">Total regular booking</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-right">
                                                                <i class="fa fa-book f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card total-corporate-booking-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$totalCor?></h4>
                                                                <h6 class="text-white m-b-0">Total corporate bookings</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-right">
                                                                <i class="fa fa-tablet f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    .l
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card trip-booking-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$drivers?></h4>
                                                                <h6 class="text-white m-b-0">Total Drivers</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-white text-right">
                                                                <i class="fa fa-tripadvisor f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card view-Job-card-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$jobcards?></h4>
                                                                <h6 class="text-white m-b-0">View Job Card</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-right">
                                                                <i class="fa fa-credit-card f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6">
                                                <div class="card user-management-bg">
                                                    <div class="card-block">
                                                        <div class="row align-items-center">
                                                            <div class="col-12 col-sm-9">
                                                                <h4 class="text-white"><?=$totalUsers-1;?></h4>
                                                                <h6 class="text-white m-b-0">Total Users</h6>
                                                            </div>
                                                            <div class="col-12 col-sm-3 text-right">
                                                                <i class="fa fa-user f-44 text-white mb-2"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- task, page, download counter  end -->

                                            <!--  sale analytics start -->

                                        </div>
                                        <div class="row">
                                            <div class="col-12 mt-3 mb-3">
                                                <hr>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-xl-12 col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Monthwise Bookings Graph <?=date('Y');?></h5>
                                                    </div>
                                                    <div class="card-block" id="bar_month_wise">
                                                        
                                                    </div>
                                                </div>
                                            </div>                                            
                                        </div>
                                        <div class="row">
                                        <div class="col-xl-12 col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Monthwise Amount Graph <?=date('Y');?></h5>
                                                    </div>
                                                    <div class="card-block" id="bar_month_wise_total">
                                                        
                                                    </div>
                                                </div>
                                            </div>
</div>  
                                        <div class="row">
                                            <div class="col-12 mt-3 mb-3">
                                                <hr>
                                            </div>
                                        </div>
                              
                                                </div>
                                                <script>
 
 // Draw the bar chart for registered users year wise
 google.charts.setOnLoadCallback(barChart);
  
 // for
 function barChart() {
    //Monthly bookings graph
   /* Define the chart to be drawn.*/
   var data = google.visualization.arrayToDataTable([
       ['Month', 'Bookings'],     
    
       <?php 
       
        foreach ($get_graph as $row){
        echo "['".$row['barmonth']."',".$row['counter']."],";
        }
        ?>
   ]);
   var options = {
       //title: 'Year wise Registered Users Bar Chart',
       is3D: true,
       width:900,
        height:500,
      
         };
   /* Instantiate and draw the chart.*/
   var chart = new google.visualization.ColumnChart(document.getElementById('bar_month_wise'));
   chart.draw(data, options);

   //Monthly Total Amount graph
 /* Define the chart to be drawn.*/
 var data2 = google.visualization.arrayToDataTable([
       ['Month', 'Amount',{ role: 'style' } ],        
       <?php 
       
        foreach ($get_graph_total as $rows){
        echo "['".$rows['barmonth']."',".$rows['total'].",'#b87333'],";
        }
        ?>
   ]);
  
   var options2 = {
       //title: 'Year wise Registered Users Bar Chart',
       is3D: true,
       width:900,
        height:500,
        color:'#b87333',
         };
   /* Instantiate and draw the chart.*/
   var chart2 = new google.visualization.ColumnChart(document.getElementById('bar_month_wise_total'));
   chart2.draw(data2, options2);

 }
</script>
                                          
                                   