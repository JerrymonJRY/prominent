<!DOCTYPE html>

<html lang="en">

<head>

    <title>Prominent Limousine </title>

    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 10]>

    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->

    <!-- Meta -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <meta name="description" content="Mega Able Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />

    <meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />

    <meta name="author" content="codedthemes" />

    <!-- Favicon icon -->

    <link rel="icon" href="<?php echo base_url('assets/images/favicon.ico');?>" type="image/x-icon">

    <!-- Google font-->

    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">

    <!-- waves.css -->

    <link rel="stylesheet" href="<?=base_url('assets/pages/waves/css/waves.min.css')?>" type="text/css" media="all">

    <!-- Required Fremwork -->

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap/css/bootstrap.min.css')?>">

    <!-- waves.css -->

    <link rel="stylesheet" href="<?=base_url('assets/pages/waves/css/waves.min.css')?>" type="text/css" media="all">

    <!-- themify-icons line icon -->

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/icon/themify-icons/themify-icons.css');?>">

    <!-- ico font -->

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/icon/icofont/css/icofont.css');?>">

    <!-- Font Awesome -->

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/icon/font-awesome/css/font-awesome.min.css')?>">

    <!-- Style.css -->

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/style.css')?>">

    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/jquery.mCustomScrollbar.css')?>">
    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/jquery-ui.multidatespicker.css')?>">
    <link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> 
  <script type="text/javascript">
      google.charts.load('visualization', "1", {
          packages: ['corechart']
      });
  </script>




</head>



<body>

    <!-- Pre-loader start -->

    <div class="theme-loader">

        <div class="loader-track">

            <div class="preloader-wrapper">

                <div class="spinner-layer spinner-blue">

                    <div class="circle-clipper left">

                        <div class="circle"></div>

                    </div>

                    <div class="gap-patch">

                        <div class="circle"></div>

                    </div>

                    <div class="circle-clipper right">

                        <div class="circle"></div>

                    </div>

                </div>

                <div class="spinner-layer spinner-red">

                    <div class="circle-clipper left">

                        <div class="circle"></div>

                    </div>

                    <div class="gap-patch">

                        <div class="circle"></div>

                    </div>

                    <div class="circle-clipper right">

                        <div class="circle"></div>

                    </div>

                </div>



                <div class="spinner-layer spinner-yellow">

                    <div class="circle-clipper left">

                        <div class="circle"></div>

                    </div>

                    <div class="gap-patch">

                        <div class="circle"></div>

                    </div>

                    <div class="circle-clipper right">

                        <div class="circle"></div>

                    </div>

                </div>



                <div class="spinner-layer spinner-green">

                    <div class="circle-clipper left">

                        <div class="circle"></div>

                    </div>

                    <div class="gap-patch">

                        <div class="circle"></div>

                    </div>

                    <div class="circle-clipper right">

                        <div class="circle"></div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- Pre-loader end -->

    <div id="pcoded" class="pcoded">

        <div class="pcoded-overlay-box"></div>

        <div class="pcoded-container navbar-wrapper">

            <nav class="navbar header-navbar pcoded-header">

                <div class="navbar-wrapper">

                    <div class="navbar-logo">

                        <a class="mobile-menu waves-effect waves-light" id="mobile-collapse" href="#!">

                            <i class="ti-menu"></i>

                        </a>

                        <div class="mobile-search waves-effect waves-light">

                            <div class="header-search">

                                <div class="main-search morphsearch-search">

                                    <div class="input-group">

                                        <span class="input-group-addon search-close"><i class="ti-close"></i></span>

                                        <input type="text" class="form-control" placeholder="Enter Keyword">

                                        <span class="input-group-addon search-btn"><i class="ti-search"></i></span>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <a href="index.html">

                            <img class="img-fluid" src="<?=base_url('assets/images/logo.png')?>" alt="Theme-Logo" />

                        </a>

                        <a class="mobile-options waves-effect waves-light">

                            <i class="ti-more"></i>

                        </a>

                    </div>



                    <div class="navbar-container container-fluid">

                        <ul class="nav-left">

                            <li>

                                <div class="sidebar_toggle"><a href="javascript:void(0)"><i class="ti-menu"></i></a>

                                </div>

                            </li>

                           

                            <li>

                                <a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">

                                    <i class="ti-fullscreen"></i>

                                </a>

                            </li>

                        </ul>

                        <ul class="nav-right">

                            <li class="header-notification">

                                <a href="#!" class="waves-effect waves-light">

                                    <i class="ti-bell"></i>

                                    <span class="badge bg-c-red"></span>

                                </a>

                               
                            </li>

                            <li class="user-profile header-notification">

                                <a href="#!" class="waves-effect waves-light">

                                   <!-- <img src="" class="img-radius" alt="User-Profile-Image">-->

                                    <span>
                                        <?php
                                            echo session()->get('name');
                                        ?>
                                    </span>

                                    <i class="ti-angle-down"></i>

                                </a>

                                <ul class="show-notification profile-notification">

                                   <?php if($status!=1){?>
                                    <?php if($status==4){?>
                                    <li class="waves-effect waves-light">

                                        <a href="<?=base_url('auth/edituserProfile')?>">

                                            <i class="ti-user"></i> Profile

                                        </a>

                                    </li>
                                   
                                   <?php }
                                }?>
                                   <li class="waves-effect waves-light">

                                        <a href="<?=base_url('auth/resetPassword')?>">

                                            <i class="ti-write"></i> Reset Password

                                        </a>

                                    </li>
                                    
                                    <li class="waves-effect waves-light">

                                        <a href="<?=base_url('logout')?>">

                                            <i class="ti-layout-sidebar-left"></i> Logout

                                        </a>

                                    </li>

                                </ul>

                            </li>

                        </ul>

                    </div>

                </div>

            </nav>


            <div class="pcoded-main-container">

                <div class="pcoded-wrapper">
                <?= $this->renderSection('sideMenu')?>

                    <div class="pcoded-content">

                        <!-- Page-header start -->

                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            
                                            <p class="m-b-0">Welcome to Prominent Limousine</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb-title">
                                            <li class="breadcrumb-item">
                                                <a href="<?=base_url('dashboard')?>"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="<?=base_url('dashboard')?>">Dashboard</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>                        <!-- Page-header end -->

                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->

                            <div class="main-body">

                                <div class="page-wrapper">



                                    <!-- Page body start -->

                                    <?= $this->renderSection('pageBody') ?>
                                        <!-- Page body end -->

                                    </div>

                                </div>

                                <!-- Main-body end -->

                                <div id="styleSelector">



                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>





       
        <script type="text/javascript" src="<?=base_url('assets/js/jquery/jquery.min.js')?>"></script>

        <script type="text/javascript" src="<?=base_url('assets/js/jquery-ui/jquery-ui.min.js')?> "></script>

        <script type="text/javascript" src="<?=base_url('assets/js/popper.js/popper.min.js')?>"></script>

        <script type="text/javascript" src="<?=base_url('assets/js/bootstrap/js/bootstrap.min.js')?> "></script>

        <!-- jquery slimscroll js -->

        <script type="text/javascript" src="<?=base_url('assets/js/jquery-slimscroll/jquery.slimscroll.js')?> "></script>

        <!-- waves js -->

        <script src="<?=base_url('assets/pages/waves/js/waves.min.js')?>"></script>



        <!-- modernizr js -->

        <script type="text/javascript" src="<?=base_url('assets/js/SmoothScroll.js')?>"></script>

        <script src="<?=base_url('assets/js/jquery.mCustomScrollbar.concat.min.js')?> "></script>

        <!-- Custom js -->

        <script src="<?=base_url('assets/js/pcoded.min.js')?>"></script>

        <script src="<?=base_url('assets/js/vertical-layout.min.js')?> "></script>

        <script src="<?=base_url('assets/js/jquery.mCustomScrollbar.concat.min.js')?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/pages/notification/notification.js')?>"></script>

        <script type="text/javascript" src="<?=base_url('assets/js/script.js')?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/js/jquery-ui.multidatespicker.js')?>"></script>
        
        <!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>--> i

        <script>
             /*$(document).ready(function(){  
                 var m=0;
             $('#dateadd').click(function(){  
                   m++;           
           $('#dynamic_field_date').append('<tr id="row'+m+'" ><td><i class="ti-calendar date-ic"></i><input id="datepicker" name="datepicker[]" class="form-control" placeholder="Select Date" required /> </td><td><button type="button" name="remove" id="'+m+'" class="btn btn-danger btn-sm red-btn">X</button></td></tr>');  
           $("#datepicker").datepicker({dateFormat: 'yy-mm-dd'});
      });
             });*/
            $(function() {

                $("#dob").datepicker({dateFormat: 'yy-mm-dd'}); 
                $("#return_date").datepicker({dateFormat: 'yy-mm-dd'});
                $("#leave_date").datepicker({dateFormat: 'yy-mm-dd'});
                $("#join_date").datepicker({dateFormat: 'yy-mm-dd'});
                $("#datepicker").datepicker({dateFormat: 'yy-mm-dd',minDate: 0});
               // var date = new Date();              
               /* $('#mdp-demo').multiDatesPicker({
                dateFormat: 'yy-mm-dd',
                minDate: 0,
                maxDate:0
                }).on('keydown',function(event){
                   
						event.preventDefault();
					});*/

            $('#search').keyup(function(){
    $('.dtails').hide();
    var txt = $('#search').val();
    $('.dtails').each(function(){
       if($(this).text().toUpperCase().indexOf(txt.toUpperCase()) != -1){
           $(this).show();
       }
    });
});
            });
           

            function searchCompany() {

                const trs = document.querySelectorAll('#bookings tr:not(.header)')

                const filter = document.querySelector('#company').value

                const regex = new RegExp(filter, 'i')

                const isFoundInTds = td => regex.test(td.innerHTML)

                const isFound = childrenArr => childrenArr.some(isFoundInTds)

                const setTrStyleDisplay = ({
                    style,
                    children
                }) => {

                    style.display = isFound([

                        ...children // <-- All columns

                    ]) ? '' : 'none'

                }



                trs.forEach(setTrStyleDisplay)

            }

           
           
        </script>

<?= $this->renderSection('scriptjava') ?>

</body>



</html>