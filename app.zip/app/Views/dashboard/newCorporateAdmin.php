
<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">


<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

                

                <?php
                    if(isset($validation)):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?= isset($validation)?display_errors($validation,'companyName'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'email'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'tarde_lno'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'adm_email'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'acc_email'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'companycode'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'username'): '' ?>
                </span>
                <?php endif;?>
                                        
                <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    `<span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                
                <h5>New Corporate Admin </h5>
            </div>

            <div class="card-block">
<form action="" method="POST">
<?= csrf_field();?>
                       
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Company Name</label>
                 <div class="col-sm-5">
                   <input type="text" name="companyName" id="companyName" class="form-control" required="" value="<?=set_value('companyName');?>">
                  </div>
                </div>
                <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right"> Company Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="email" id="email" class="form-control" required="" value="<?=set_value('email');?>">
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="contactNo" id="contactNo" class="form-control" required=" value="<?=set_value('contactNo');?>">
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Contact Person</label>
                 <div class="col-sm-5">
                   <input type="text" name="contactPerson" id="contactPerson" class="form-control" required="" value="<?=set_value('contactPerson');?>">
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right"> Address</label>
                 <div class="col-sm-5">
                   <textarea name="address" id="address" class="form-control" required=""> <?=set_value('address');?></textarea>
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Trade License Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="trade_lno" id="trade_lno" class="form-control" required="" value="<?=set_value('trade_lno');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">VAT Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="vat_no" id="vat_no" class="form-control" required="" value="<?=set_value('vat_no');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Administration Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="adm_email" id="adm_email" class="form-control" required="" value="<?=set_value('adm_email');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Administration Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="adm_no" id="adm_no" class="form-control" required="" value="<?=set_value('adm_no');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Accountant Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="acc_email" id="acc_email" class="form-control" required="" value="<?=set_value('acc_email');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Accountant Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="acc_no" id="acc_no" class="form-control" required="" value="<?=set_value('acc_no');?>" />
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Company Code</label>
                 <div class="col-sm-5">
                   <input type="text" name="companycode" id="companycode" class="form-control" required="" value="<?=set_value('companycode');?>">
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Username</label>
                 <div class="col-sm-5">
                   <input type="email" name="username" id="username" class="form-control" required="" value="<?=set_value('username');?>">
                 </div>
               </div>
               <div class="form-group row">
               <label class="col-sm-4 col-form-label text-right">Password</label>
                 <div class="col-sm-5">
                   <input type="password" name="password" id="password" class="form-control" required="" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">.</label>
                <div class="col-sm-5">
                    <input type="reset" class="btn btn-primary" value="Reset" />
                    <input type="submit" class="btn btn-primary" value="Save" />
                </div>
               </div>
       </form> 

       </div>

</div>

</div>

</div>

</div>  
<?=$this->endSection()?>
          