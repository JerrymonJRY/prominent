<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
        <!-- Basic Form Inputs card start -->
            <div class="card">
                <div class="card-header">
                <div class="dtails">
                    <div class="row m-0">
                        <div class="col-md-9 p-4">                            
                            <ul class="float-left w-30 text-left">                
                                <li class="text-red">Booking ID: <?=$tripdetails['booking_id'];?></li>
                                <li >Done By: <?=$doneBy;?></li>
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?=$companyName;?> </li>                  
                                <?php 
                                if($tripdetails['booking_projectCode']!=''){ ?>
                                <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$tripdetails['booking_projectCode'];?></li>                   
                                 <?php } ?>                    
                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$tripdetails['ct_type'];?></li>
                            </ul>
                            <ul class="float-left w-35 text-left">
                                <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$tripdetails['bt_type'];?></li>
                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$tripdetails['trt_type'];?></li>
                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$tripdetails['booking_date'];?></li>
                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$tripdetails['booking_time'];?></li>
                                <?php if(trim($tripdetails['booking_return_time'])!=''){?>
                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$tripdetails['booking_return_time'];?></li>
                                <?php } ?>
                            </ul>
                            <ul class="float-left w-35 text-left"> 
                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$tripdetails['booking_from'];?></li>                    
                                <?php if($tripdetails['booking_stop']!=''){?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php
                                    $arr=explode('-*-',$tripdetails['booking_stop']);
                                    echo $imp=implode(",",$arr);
                                    ?>
                                </li>
                                <?php } ?>
                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$tripdetails['booking_to'];?></li>
                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$tripdetails['booking_NoPassengers'];?></li>
                            </ul>
                            <ul class="float-left w-35 text-left"> 
                                <?php 
                                $obj_passengers=new \App\Models\Passengers();
                                $getPassengers=$obj_passengers->where('booking_id',$tripdetails['booking_id'])->findAll();
                                if(sizeof($getPassengers)>0){
                                    $n=1;                                    
                                foreach($getPassengers as $get){
                                ?>
                                <li> <i class="fa fa-user"></i>
                                <?php if($get['passenger_name']!='') { 
                                        echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                } 
                                if($get['passenger_contact']!=''){
                                echo $get['passenger_contact'];
                                 } 
                                $n++;
                                 }
                                }
                                ?> 
                                <li>Driver Note: <?php if($tripdetails['driver_note']=='') { 
                                                echo 'Nil';
                                                } else{ 
                                                echo $tripdetails['driver_note'];
                                                }?></li>   
                            
               <?php 
                            if(($tripdetails['cadmin_approval']==2)||($tripdetails['cadmin_approval']==3)){
                        ?>
                   <li> Reason for cancellation : 
                        <?=$tripdetails['cadmin_reason_cancel'];?></li>
                        <?php } ?>
               
          
           </div>
           <div class="col-md-3 p-4"> 
            
           <?php if($tripdetails['cadmin_approval']==0){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                    <?php }else  if($tripdetails['cadmin_approval']==1){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Approved</a></li>
                    <?php } else if($tripdetails['cadmin_approval']==2){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                    <?php }else  if($tripdetails['cadmin_approval']==3){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                    <?php } ?>                                                                                            
                            <?php if($tripdetails['sadmin_approval']==0){ ?>
                           
                           <li><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
               <?php    
                     }else if($tripdetails['sadmin_approval']==1){ ?>
                            <li><a href="#" class="pwait-btn" title="Prominent Approval">Approved by prominent</a></li>    
               <?php } else if($tripdetails['sadmin_approval']==2){  ?>
                            <li><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
               <?php } else if($tripdetails['sadmin_approval']==3){  ?>
                   <li><a href="#" class="pwait-btn" title="Prominent Approval">Re Send</a></li>  
               <?php } ?>
               
            </div>
            </ul>
            </div>            
                                                
            </div>
                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                    <h5><?=$header;?></h5>
                
                <div class="card-block">
                    <form action="" method="POST">
                    <div class="dtails p-4">
                    <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Status</label>
                            <div class="col-sm-5">
                                <select id="status" name="status" class="form-control">
                                <?php if($tripdetails['sadmin_approval']==0) { ?><option value="">Select status</option> <?php } ?>
                                    
                                    <option value="1" <?php if($tripdetails['sadmin_approval']==1){ echo 'selected';} else {echo '';} ?> >Confirm</option>
                                    <option value="2" <?php if($tripdetails['sadmin_approval']==2){ echo 'selected';} else {echo '';} ?> >Cancel</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row" id="reasondiv" style="display: none;">
                            <label class="col-sm-4 col-form-label text-right">Reason For cancellation</label>
                            <div class="col-sm-5">
                            <input type="text" id="reason" name="reason" class="form-control"  value="<?=$tripdetails['sadmin_reason_cancel'];?>" placeholder="cancellation reason">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">.</label>
                            <div class="col-sm-5">
                                <button class="btn btn-primary btn-round waves-effect waves-light w-50">Submit</button>
                            </div>
                        </div>
                    </div>
                    </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
     $('#status').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    if(valueSelected==2){        
        $('#reasondiv').show();
        $('#assigndiv').hide();
    }else{
        $('#assigndiv').show();
        $('#reasondiv').hide();
       
    }
});


</script>
<?= $this->endSection() ?>