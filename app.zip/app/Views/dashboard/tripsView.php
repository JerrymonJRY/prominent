<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

    <input type="text" id="search"  placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>                
            </div>
            <?php $i=1;?>
            <ul class="nav nav-tabs  tabs" role="tablist">            
                    <li class="nav-item"><a class="nav-link <?php if($cat=='new'){echo 'active';}?>"  href="<?php echo base_url('/booking/view/new');?>" role="tab">New Bookings</a></li>
                    <li class="nav-item"><a class="nav-link <?php if($cat=='assign'){echo 'active';}?>"  href="<?php echo base_url('/booking/view/assign');?>" role="tab">Assigned bookings</a></li>
                    <li class="nav-item"><a class="nav-link <?php if($cat=='notAssign'){echo 'active';}?>"  href="<?php echo base_url('/booking/view/notAssign');?>" role="tab">Not Assigned bookings</a></li>
                    <li class="nav-item"><a class="nav-link <?php if($cat=='complete'){echo 'active';}?>"  href="<?php echo base_url('/booking/view/complete');?>" role="tab">Completed bookings</a></li>
                    <li class="nav-item"><a class="nav-link <?php if($cat=='cancel'){echo 'active';}?>"  href="<?php echo base_url('/booking/view/cancel');?>" role="tab">Cancelled bookings</a></li>            
                    <!-- <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#paid" role="tab"> Paid booking</a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#unpaid" role="tab"> Un Paid booking</a></li>   -->
                    <li class="nav-item"><a class="nav-link <?php if($cat=='all'){echo 'active';}?> "  href="<?php echo base_url('/booking/view/all');?>" role="tab"> All</a></li> 
                </ul>
            <div class="tab-content tabs card-block">
                <!--all start-->
                <div class="tab-pane <?php if($cat=='all'){echo 'active';}?> " id="all" role="tabpanel">
                    <div class="card-block">
                            <?php
                                    $all=0;
                                    foreach($trips as $trip):
                                        $all=$all+1;
                                        
                                ?>
                                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                                    <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                                    <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                                    <div class="dtails">
                                    <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                                    <input  type="submit" class="btn btn-danger" value="Delete" />  
                                    </div>
                                    </form>
                                </div>
                                <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                    <div class="row m-0">
                                        <div class="col-md-9 p-4">  
                                         <?php
                                         if($trip['sadmin_approval']==1){
                                         if($trip['assign_dr_supp']==0){?>
                                                <div class="unassigned">Not assigned </div>
                                            <?php
                                            }else{?>
                                              <div class="assigned">Assigned </div>
                                            <?php 
                                            } 
                                         }
                                            ?>      
                                            <ul class="float-left w-30 text-left">
                                            <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                            <?php 
                                if(trim($trip['company_Id'])==0){ ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                            <?php  }else{
                                    $obj_cadmin=new App\Models\CorporateAdmin();
                                    $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                <?php 
                                }
                            ?>
                            
                            <?php 
                                if($trip['booking_projectCode']!=''){ ?>
                                <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                            <?php } ?>
                                                
                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                </ul>
                                            <ul class="float-left w-35 text-left">
                                                <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                <?php if(trim($trip['booking_return_time'])!=''){?>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                <?php } ?>
                                            </ul>
                                            <ul class="float-left w-35 text-left">    
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                
                                            </ul>
                                            <ul class="bdr-btn mt-29">                
                                            <?php if($trip['company_Id']==0){?>
                                            
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                    <?php }else{ ?>
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                        
                                    <?php } ?>
                                    <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                    <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                    
                                
                                <li class="mr-2 border-btn green-border float-right"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3 p-4 price-bg text-center">
                                        <?php 
                                                if(trim($trip['booking_amount'])!=''){ ?>
                                                    <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>  
                                            <?php } ?>
                                              <!-- Tooltip style 5 card start -->  
                                             <?php
                                             if(($trip['sadmin_approval']==4)||($trip['sadmin_approval']==5)){
                                                if(trim($trip['booking_remarks'])!=''){ ?>                                         
                                                       <span class="mytooltip tooltip-effect-5">
                                                   <span class="tooltip-item">?</span>
                                                   <span class="tooltip-content clearfix">
                                                     <span class="tooltip-text"><?=$trip['booking_remarks'];?></span>
                                                 </span>
                                             </span>
                                             <?php } } ?>
                                             
                                            <ul class="w-100 text-center">
                                            <?php if($trip['sadmin_approval']==0){ ?>
                                
                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                    <?php    
                            }else if($trip['sadmin_approval']==1){ ?>
                                    <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                    <?php } else if($trip['sadmin_approval']==2){  ?>
                                    <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                    <?php } else if($trip['sadmin_approval']==3){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                    <?php } else if($trip['sadmin_approval']==4){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                    <?php } else if($trip['sadmin_approval']==5){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                    <?php } ?>
                                            </ul>
                                    <?php 
                                    if($trip['sadmin_approval']==2){
                                    if(trim($trip['sadmin_reason_cancel'])!=''){ ?>                                         
                                                       <span class="mytooltip tooltip-effect-5" >
                                                   <span class="tooltip-item" style="background:#e37f7f;font-weigh:600;color:#fff;margin-top:7px;">!</span>
                                                   <span class="tooltip-content clearfix">
                                                     <span class="tooltip-text"><?=$trip['sadmin_reason_cancel'];?></span>
                                                 </span>
                                             </span>
                                             <?php } }?>
                                        </div>
                                    </div>
                                    <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                            <div class="dtails p-0 border-0 ">
                            <?php 
                                                            $obj_passengers=new \App\Models\Passengers();
                                                            $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                            if(sizeof($getPassengers)>0){
                                                            ?>
                                                            <ul>
                                                            <?php
                                                            $n=1;                                    
                                                            foreach($getPassengers as $get){
                                                            ?>
                                                            <li> <i class="fa fa-user"></i>
                                                                <?php if($get['passenger_name']!='') { 
                                                                echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                } 
                                                                if($get['passenger_contact']!=''){
                                                                    echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                } if($get['passenger_location']!=''){
                                                                    echo $get['passenger_location'];
                                                                }?>
                                                            </li>
                                                            <?php
                                                            $n++;
                                                            }
                                                            ?>
                                                            </ul>
                                                            <?php
                                                            }
                                                            ?>
                            <ul class="w-100 float-left">
                            <li class="text-red">Driver Note: <?=$trip['driver_note'];?> </li>
                             </ul>
                             <?php if(($trip['sadmin_approval']==4)||($trip['sadmin_approval']==5)){?>
                                <ul class="w-100 float-left">
                                    <li class="text-red">Remarks:  </li>
                                    <li><?=$trip['booking_remarks'];?></li>
                                </ul>
                            <?php } ?>
                            <?php if($trip['sadmin_approval']==2){?>
                                <ul class="w-100 float-left">
                                    <li class="text-red">Cancellation Reason:  </li>
                                    <li><?=$trip['sadmin_reason_cancel'];?></li>
                                </ul>
                            <?php } ?>
                            <?php if($trip['sadmin_approval']==1){
                                
                        $obj_job= new \App\Models\Jobcard(); 
                        $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                    
                        if($getJob['driver_id']!=0){
                        $obj_driver= new \App\Models\Drivers();        
                    $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                    
                    ?>
                    <div class="dtails border-0">
                        <h3 class="text-left">Driver Details</h3>
                        <hr>
            
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                        <?php } ?><br/>
                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                                
                                                                                <ul>
                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col-lg-4 text-left">
                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php } 
                                                        
                                                        if($getJob['supplier_id']!=0){
                                                            $obj_supp= new \App\Models\Supplier();        
                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                        ?>
                                                            <div class="dtails border-0">
                                                                <h3 class="text-left">Supplier Details</h5>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        
                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">                                                          
                                                                    <ul>
                                                                            
                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-lg-4">  </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php }
                                                        } ?>
                            
                                
                                                                    </div>
                                                                </div>
                        </div>   <?php
                                                $i++;
                                            
                                                endforeach;
                                                
                                                if($all==0){
                                                    echo "Empty list";
                                                }
                                            ?>                                 
                                
                    </div>
                </div>
                <!--all finished and bookings start-->
                <div class="tab-pane <?php if($cat=='new'){echo 'active';}?>" id="bookings" role="tabpanel">
                    <div class="card-block">
                            <?php
                                    $books=0;
                                    foreach($trips as $trip):
                                    if(($trip['sadmin_approval']==0)||($trip['sadmin_approval']==3)){
                                        $books=$books+1;
                                        
                                ?>
                                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                                <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                    <div class="row m-0">
                                        <div class="col-md-12 p-2">
                                        <?php 
                                                if(trim($trip['booking_amount'])!=''){ ?>
                                                    <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>  
                                            <?php } ?>
                                            <ul class="float-left w-15 text-left">                                                                                                  
                                                    
                                                <?php if($trip['sadmin_approval']==0){ ?>                                
                                                    <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                                                        <?php    
                                                                }else if($trip['sadmin_approval']==1){ ?>
                                                                        <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                                        <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                                                        <?php } else if($trip['sadmin_approval']==3){  ?>
                                                            <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                                                        <?php } else if($trip['sadmin_approval']==4){  ?>
                                                            <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                                                        <?php } else if($trip['sadmin_approval']==5){  ?>
                                                    <li class="w-85 mt-10"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                                                <?php } ?>
                                            </ul>
                                            <ul class="float-left w-15 text-left">
                                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                <!-- <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li> -->

                                                <?php if($trip['booking_projectCode']!=''){ ?>
                                                       <!-- <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li> --> 
                                                          <?php 
                                                    if(trim($trip['company_Id'])==0){ ?>
                                                    
                                                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                                                <?php  }else{
                                                        $obj_cadmin=new App\Models\CorporateAdmin();
                                                        $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                                    ?>                                                    
                                                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                                    <?php }?>
                                                
                                                <?php } ?>
                                            </ul>

                                            <ul class="float-left w-20 text-left">
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                <?php if(trim($trip['booking_return_time'])!=''){?>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                <?php } ?>                                                
                                            </ul>

                                            <!-- <ul class="float-left w-20 text-left">
                                                
                                                <?php 
                                                    if(trim($trip['company_Id'])==0){ ?>
                                                    
                                                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                                                <?php  }else{
                                                        $obj_cadmin=new App\Models\CorporateAdmin();
                                                        $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                                    ?>                                                    
                                                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                                    <?php }?>
                                                
                                                                                                              
                                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                            </ul> -->
                                           
                                            <ul class="float-left w-30 text-left">                                                  
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                    <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                
                                            </ul>
                                            <ul class="bdr-btn w-20">  
                                            <li class="text-red w-100 pt-0 mt-0">Booking ID: <?=$trip['booking_id'];?></li>              
                                                <?php if($trip['company_Id']==0){?>                                            
                                                    <li class="mr-2 border-btn float-left"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                    <?php }else{ ?>
                                                            <li class="mr-2 border-btn float-left"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>                                                                        
                                                    <?php } ?>
                                                    <li class="mr-2 border-btn red-border float-left"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                                    <li class="mr-2 border-btn green-border float-left"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                                    <li class="mr-2 border-btn green-border float-left"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>   
                                            </ul>
                                        <!-- </div>
                                        <div class="col-md-3 p-4 price-bg text-center"> -->
                                       

                                        </div>
                                    </div>
                                    <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                            <div class="dtails p-0 border-0 ">
                            <?php 
                                                            $obj_passengers=new \App\Models\Passengers();
                                                            $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                            if(sizeof($getPassengers)>0){
                                                            ?>
                                                            <ul>
                                                            <?php
                                                            $n=1;                                    
                                                            foreach($getPassengers as $get){
                                                            ?>
                                                            <li> <i class="fa fa-user"></i>
                                                                <?php if($get['passenger_name']!='') { 
                                                                echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                } 
                                                                if($get['passenger_contact']!=''){
                                                                    echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                } if($get['passenger_location']!=''){
                                                                    echo $get['passenger_location'];
                                                                }?>
                                                            </li>
                                                            <?php
                                                            $n++;
                                                            }
                                                            ?>
                                                            </ul>
                                                            <?php
                                                            }
                                                            ?>
                            <ul class="w-100 float-left">
                            <li class="text-red">Driver Note: <?=$trip['driver_note'];?> </li>
                            <ul>
                            <?php if($trip['sadmin_approval']==1){
                                
                        $obj_job= new \App\Models\Jobcard(); 
                        $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                    
                        if($getJob['driver_id']!=0){
                        $obj_driver= new \App\Models\Drivers();        
                    $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                    
                    ?>
                    <div class="dtails border-0">
                        <h3 class="text-left">Driver Details</h3>
                        <hr>
            
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                        <?php } ?><br/>
                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                                
                                                                                <ul>
                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col-lg-4 text-left">
                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php } 
                                                        
                                                        if($getJob['supplier_id']!=0){
                                                            $obj_supp= new \App\Models\Supplier();        
                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                        ?>
                                                            <div class="dtails border-0">
                                                                <h3 class="text-left">Supplier Details</h5>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        
                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">                                                          
                                                                    <ul>
                                                                            
                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-lg-4">  </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php }
                                                        } ?>
                            
                                
                                                                    </div>
                                                                </div>
                        </div>   <?php
                                                    $i++;
                                                    }
                                                    endforeach;
                                                     if($books==0){
                                                    echo "Empty list";
                                                }
                                                ?>                                 
                                
                            </div>
                </div>
                <!--bookings end and start Assigned confirmed-->
                <div class="tab-pane <?php if($cat=='assign'){echo 'active';}?>" id="confirmed" role="tabpanel">
                    <div class="card-block">
                            <?php
                                    $assign=0;
                                    foreach($trips as $trip):
                                        if(($trip['sadmin_approval']==1)&&($trip['assign_dr_supp']==1)){
                                            $assign=$assign+1;
                                        
                                ?>
                                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                                <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                    <div class="row m-0">
                                        <div class="col-md-9 p-4"> 
                                       
                                          <?php //if($trip['assign_dr_supp']==0){?>
                                               <!-- <div class="unassigned">Not assigned </div>-->
                                            <?php
                                           // }else{?>
                                              <!--<div class="assigned">Assigned </div>-->
                                            <?php 

                                            //}    
                                            ?>   
                                            <ul class="float-left w-30 text-left">
                                            <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                            <?php 
                                if(trim($trip['company_Id'])==0){ ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                            <?php  }else{
                                    $obj_cadmin=new App\Models\CorporateAdmin();
                                    $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                <?php 
                                }
                            ?>
                            
                            <?php 
                                if($trip['booking_projectCode']!=''){ ?>
                                <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                            <?php } ?>
                                                
                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                </ul>
                                            <ul class="float-left w-35 text-left">
                                                <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                <?php if(trim($trip['booking_return_time'])!=''){?>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                <?php } ?>
                                            </ul>
                                            <ul class="float-left w-35 text-left">    
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                    <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                
                                            </ul>
                                            <ul class="bdr-btn mt-29">                
                                            <?php if($trip['company_Id']==0){?>
                                            
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                    <?php }else{ ?>
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                        
                                    <?php } ?>
                                    <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                    <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                    
                                
                                <li class="mr-2 border-btn green-border float-right"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3 p-4 price-bg text-center">
                                        <?php 
                                                if(trim($trip['booking_amount'])!=''){ ?>
                                                    <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>  
                                            <?php } ?>
                                            <ul class="w-100 text-center">
                                            <?php if($trip['sadmin_approval']==0){ ?>
                                
                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                        <?php    
                                }else if($trip['sadmin_approval']==1){ ?>
                                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                        <?php } else if($trip['sadmin_approval']==3){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                        <?php } else if($trip['sadmin_approval']==4){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                        <?php } else if($trip['sadmin_approval']==5){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                        <?php } ?>
                                                </ul>

                                            </div>
                                        </div>
                                        <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                <div class="dtails p-0 border-0 ">
                                <?php 
                                                                $obj_passengers=new \App\Models\Passengers();
                                                                $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                if(sizeof($getPassengers)>0){
                                                                ?>
                                                                <ul>
                                                                <?php
                                                                $n=1;                                    
                                                                foreach($getPassengers as $get){
                                                                ?>
                                                                <li> <i class="fa fa-user"></i>
                                                                    <?php if($get['passenger_name']!='') { 
                                                                    echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                    } 
                                                                    if($get['passenger_contact']!=''){
                                                                        echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                    } if($get['passenger_location']!=''){
                                                                        echo $get['passenger_location'];
                                                                    }?>
                                                                </li>
                                                                <?php
                                                                $n++;
                                                                }
                                                                ?>
                                                                </ul>
                                                                <?php
                                                                }
                                                                ?>
                                <ul class="w-100 float-left">
                                <li class="text-red">Driver Note: <?=$trip['driver_note'];?> </li>
                                <ul>
                                <?php if($trip['sadmin_approval']==1){
                                    
                            $obj_job= new \App\Models\Jobcard(); 
                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                        
                            if($getJob['driver_id']!=0){
                            $obj_driver= new \App\Models\Drivers();        
                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                        
                        ?>
                        <div class="dtails border-0">
                        <h3 class="text-left">Driver Details</h3>
                        <hr>
            
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                        <?php } ?><br/>
                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                                
                                                                                <ul>
                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col-lg-4 text-left">
                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php } 
                                                        
                                                        if($getJob['supplier_id']!=0){
                                                            $obj_supp= new \App\Models\Supplier();        
                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                        ?>
                                                            <div class="dtails border-0">
                                                                <h3 class="text-left">Supplier Details</h5>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        
                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">                                                          
                                                                    <ul>
                                                                            
                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-lg-4">  </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php }
                                                        } ?>
                            
                                
                                                                    </div>
                                                                </div>
                        </div>   <?php
                                                    $i++;
                                                    }
                                                    endforeach;
                                                     if($assign==0){
                                                    echo "Empty list";
                                                }
                                                ?>                                 
                                    
                    </div>
                </div>
                 <!--end Assigned confirmed and start Unassigned Confirmed-->
                
                <div class="tab-pane <?php if($cat=='notAssign'){echo 'active';}?> " id="notAssconfirmed" role="tabpanel">
                    <div class="card-block">
                            <?php
                                    $unassign=0;
                                    foreach($trips as $trip):
                                        if(($trip['sadmin_approval']==1)&&($trip['assign_dr_supp']==0)){
                                            $unassign=$unassign+1;
                                        
                                ?>
                                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                                <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                    <div class="row m-0">
                                        <div class="col-md-9 p-4"> 
                                       
                                           <?php //if($trip['assign_dr_supp']==0){?>
                                               <!-- <div class="unassigned">Not assigned </div>-->
                                            <?php
                                           // }else{?>
                                              <!--<div class="assigned">Assigned </div>-->
                                            <?php 

                                            //}    
                                            ?>  
                                            <ul class="float-left w-30 text-left">
                                            <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                            <?php 
                                if(trim($trip['company_Id'])==0){ ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                            <?php  }else{
                                    $obj_cadmin=new App\Models\CorporateAdmin();
                                    $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                <?php 
                                }
                            ?>
                            
                            <?php 
                                if($trip['booking_projectCode']!=''){ ?>
                                <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                            <?php } ?>
                                                
                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                </ul>
                                            <ul class="float-left w-35 text-left">
                                                <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                <?php if(trim($trip['booking_return_time'])!=''){?>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                <?php } ?>
                                            </ul>
                                            <ul class="float-left w-35 text-left">    
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                    <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                
                                            </ul>
                                            <ul class="bdr-btn mt-29">                
                                            <?php if($trip['company_Id']==0){?>
                                            
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                    <?php }else{ ?>
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                        
                                    <?php } ?>
                                    <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                    <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                    
                                
                                <li class="mr-2 border-btn green-border float-right"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3 p-4 price-bg text-center">
                                        <?php 
                                                if(trim($trip['booking_amount'])!=''){ ?>
                                                    <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>  
                                            <?php } ?>
                                            <ul class="w-100 text-center">
                                            <?php if($trip['sadmin_approval']==0){ ?>
                                
                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                        <?php    
                                }else if($trip['sadmin_approval']==1){ ?>
                                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                        <?php } else if($trip['sadmin_approval']==3){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                        <?php } else if($trip['sadmin_approval']==4){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                        <?php } else if($trip['sadmin_approval']==5){  ?>
                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                        <?php } ?>
                                                </ul>

                                            </div>
                                        </div>
                                        <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                <div class="dtails p-0 border-0 ">
                                <?php 
                                                                $obj_passengers=new \App\Models\Passengers();
                                                                $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                if(sizeof($getPassengers)>0){
                                                                ?>
                                                                <ul>
                                                                <?php
                                                                $n=1;                                    
                                                                foreach($getPassengers as $get){
                                                                ?>
                                                                <li> <i class="fa fa-user"></i>
                                                                    <?php if($get['passenger_name']!='') { 
                                                                    echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                    } 
                                                                    if($get['passenger_contact']!=''){
                                                                        echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                    } if($get['passenger_location']!=''){
                                                                        echo $get['passenger_location'];
                                                                    }?>
                                                                </li>
                                                                <?php
                                                                $n++;
                                                                }
                                                                ?>
                                                                </ul>
                                                                <?php
                                                                }
                                                                ?>
                                <ul class="w-100 float-left">
                                <li class="text-red">Driver Note: <?=$trip['driver_note'];?> </li>
                                <ul>
                                <?php if($trip['sadmin_approval']==1){
                                    
                            $obj_job= new \App\Models\Jobcard(); 
                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                        
                            if($getJob['driver_id']!=0){
                            $obj_driver= new \App\Models\Drivers();        
                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                        
                        ?>
                        <div class="dtails border-0">
                        <h3 class="text-left">Driver Details</h3>
                        <hr>
            
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                        <?php } ?><br/>
                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                                
                                                                                <ul>
                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col-lg-4 text-left">
                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php } 
                                                        
                                                        if($getJob['supplier_id']!=0){
                                                            $obj_supp= new \App\Models\Supplier();        
                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                        ?>
                                                            <div class="dtails border-0">
                                                                <h3 class="text-left">Supplier Details</h5>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        
                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">                                                          
                                                                    <ul>
                                                                            
                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-lg-4">  </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php }
                                                        } ?>
                            
                                
                                                                    </div>
                                                                </div>
                        </div>   <?php
                                                    $i++;
                                                    }
                                                    endforeach;
                                                     if($unassign==0){
                                                    echo "Empty list";
                                                }
                                                ?>                                 
                                    
                    </div>
                </div>
                 <!--end Not Assigned confirmed and start Completed-->
                <div class="tab-pane <?php if($cat=='complete'){echo 'active';}?> " id="completed" role="tabpanel">
                    <div class="card-block">
                               <!-- paid______                      --> 
                               
                               <div class="w-100 float-left"> 
                              
                                    <?php 
                                     $complete=0;
                                    foreach($trips as $trip):
                                                if(($trip['sadmin_approval']==4)||($trip['sadmin_approval']==5)){  
                                                    $complete=$complete+1;
                                        ?>
                                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                                    <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                                    <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                                        <div class="dtails">
                                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                                        </div>
                                    </form>
                                    </div>
                                    <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                            <div class="row m-0">
                                                <div class="col-md-9 p-4">                            
                                                    <ul class="float-left w-30 text-left">
                                                    <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                    <?php 
                                        if(trim($trip['company_Id'])==0){ ?>
                                        
                                        <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                                    <?php  }else{
                                            $obj_cadmin=new App\Models\CorporateAdmin();
                                            $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                        ?>
                                        
                                        <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                        <?php 
                                        }
                                    ?>
                                    
                                    <?php 
                                        if($trip['booking_projectCode']!=''){ ?>
                                        <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                                    <?php } ?>
                                                        
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                        </ul>
                                        <ul class="float-left w-35 text-left">
                                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                        <?php } ?>
                                        </ul>
                                        <ul class="float-left w-35 text-left">    
                                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                        <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                        
                                        </ul>
                                        <ul class="bdr-btn">                
                                                    <?php if($trip['company_Id']==0){?>
                                                    
                                                    <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <?php }else{ ?>
                                                    <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                                
                                            <?php } ?>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                            <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                            
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 p-4 price-bg text-center">
                                                    <?php 
                                                            if(trim($trip['booking_amount'])!=''){ ?>
                                                                <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span> </h5>  
                                                        <?php } ?>
                                                            
                                                                
                                                                <!-- Tooltip style 5 card start -->  
                                             <?php if(trim($trip['booking_remarks'])!=''){ ?>                                         
                                                       <span class="mytooltip tooltip-effect-5">
                                                   <span class="tooltip-item">?</span>
                                                   <span class="tooltip-content clearfix">
                                                     <span class="tooltip-text"><?=$trip['booking_remarks'];?></span>
                                                 </span>
                                             </span>
                                             <?php } ?>
                                                                
                                             
                                                        <ul class="w-100 text-center">
                                                        <?php if($trip['sadmin_approval']==0){ ?>
                                            
                                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                                            <?php    
                                                    }else if($trip['sadmin_approval']==1){ ?>
                                                            <li><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                                            <?php } else if($trip['sadmin_approval']==2){  ?>
                                                            <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                                            <?php } else if($trip['sadmin_approval']==3){  ?>
                                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                                            <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                                            <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                                            <?php } ?>
                                        </ul>

                                                </div>
                                            </div>
                                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                    <div class="dtails p-0 border-0 ">
                                    <?php 
                                                                    $obj_passengers=new \App\Models\Passengers();
                                                                    $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                    if(sizeof($getPassengers)>0){
                                                                    ?>
                                                                    <ul>
                                                                    <?php
                                                                    $n=1;                                    
                                                                    foreach($getPassengers as $get){
                                                                    ?>
                                                                    <li> <i class="fa fa-user"></i>
                                                                        <?php if($get['passenger_name']!='') { 
                                                                        echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                        } 
                                                                        if($get['passenger_contact']!=''){
                                                                            echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                        } if($get['passenger_location']!=''){
                                                                            echo $get['passenger_location'];
                                                                        }?>
                                                                    </li>
                                                                    <?php
                                                                    $n++;
                                                                    }
                                                                    ?>
                                                                    </ul>
                                                                    <?php
                                                                    }
                                                                    ?>
                                <ul class="w-100 float-left">
                                    <li class="text-red">Remarks:  </li>
                                    <li><?=$trip['booking_remarks'];?></li>
                                </ul>
                                    <ul class="w-100 float-left">
                                        
                                                                </ul>
                                            <?php if($trip['sadmin_approval']==1){
                                                
                                        $obj_job= new \App\Models\Jobcard(); 
                                        $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                    
                                        if($getJob['driver_id']!=0){
                                        $obj_driver= new \App\Models\Drivers();        
                                    $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();?>
                                        <div class="dtails border-0">
                                            <h3 class="text-left">Driver Details</h3>
                                            <hr>        
                                            <div class="row">
                                                <div class="col-12"></div>
                                                    <div class="col-lg-4">
                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                            <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                        <?php } ?><br/>
                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                                
                                                                                                <ul>
                                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                                    </ul>
                                                                                                </div>
                                                                                                <div class="col-lg-4 text-left">
                                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                                </div>
                                                                                    
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        if($getJob['supplier_id']!=0){
                                                                            $obj_supp= new \App\Models\Supplier();        
                                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                                        ?>
                                                                            <div class="dtails border-0">
                                                                                <h3 class="text-left">Supplier Details</h5>
                                                                                <hr>
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">                                                          
                                                                                    <ul>
                                                                                            
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="col-lg-4">  </div>
                                                                                    
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php }
                                                                        } ?>
                                            
                                                
                                                                                    </div>
                                                                                </div>
                                        </div>   
                                        <?php $i++;} endforeach;
                                        if($complete==0){
                                            echo "Empty list";
                                        }
                                        ?>                                 
                                </div>

                               <!-- END paid______                      -->


                  
                            <!-- END unpaid_______________ -->
                        </div>                    
                </div>
                <!--end Completed and start cancelled-->
                <div class="tab-pane <?php if($cat=='cancel'){echo 'active';}?> " id="cancelled" role="tabpanel">
                    <div class="card-block">
                            <?php
                                $cancel=0;
                                
                                    foreach($trips as $trip):
                                if($trip['sadmin_approval']==2){
                                    $cancel=$cancel+1;
                                        
                                ?>
                                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deleteBooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                                <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                                    <div class="row m-0">
                                        <div class="col-md-9 p-4">                            
                                            <ul class="float-left w-30 text-left">
                                            <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                            <?php 
                                if(trim($trip['company_Id'])==0){ ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo "Regular User "; ?></li>                   
                            <?php  }else{
                                    $obj_cadmin=new App\Models\CorporateAdmin();
                                    $get_user=$obj_cadmin->where('cadmin_id',$trip['company_Id'])->first();
                                ?>
                                
                                <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?php  echo $get_user['cadmin_companyName']; ?></li>                   
                                <?php 
                                }
                            ?>
                            
                            <?php 
                                if($trip['booking_projectCode']!=''){ ?>
                                <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                            <?php } ?>
                                                
                                <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                </ul>
                                            <ul class="float-left w-35 text-left">
                                                <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                                <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                                <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                                <?php if(trim($trip['booking_return_time'])!=''){?>
                                                <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                                <?php } ?>
                                            </ul>
                                            <ul class="float-left w-35 text-left">    
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                                <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                                <?php if($trip['booking_stop']!=''){?>
                                        
                                        <?php
                                            $arr=explode('-*-',$trip['booking_stop']);
                                            //print_r($arr);
                                           // $imp=implode(",",$arr);
                                           $j=0;
                                            foreach ($arr as $imp):
                                                $j=$j+1;
                                         ?>
                                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php echo "STOP".$j."-".$imp;?></li>
                                    <?php 
                                    endforeach;
                                } ?>
                                                <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                                <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                                
                                            </ul>
                                            <ul class="bdr-btn">                
                                            <?php if($trip['company_Id']==0){?>
                                            
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/regularEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                    <?php }else{ ?>
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/corporateEditTrip/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                                        
                                    <?php } ?>
                                    <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                    <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Assign Driver"></i></a></li>
                                    
                                
                                <li class="mr-2 border-btn green-border float-right"><a  class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3 p-4 price-bg text-center">
                                      
                                            <ul class="w-100 text-center">
                                            <?php if($trip['sadmin_approval']==0){ ?>
                                
                                <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
                    <?php    
                            }else if($trip['sadmin_approval']==1){ ?>
                                    <li><a href="#" class="wait-btn" title="Prominent Approval">Confirmed</a></li>    
                    <?php } else if($trip['sadmin_approval']==2){  ?>
                                    <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
                    <?php } else if($trip['sadmin_approval']==3){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
                    <?php } else if($trip['sadmin_approval']==4){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed</a></li>  
                    <?php } else if($trip['sadmin_approval']==5){  ?>
                        <li class="mr-0"><a href="#" class="wait-btn" title="Prominent Approval">Completed/Un Paid</a></li>  
                    <?php } ?>
                                            </ul>
                                              <!-- Tooltip style 5 card start -->  
                                             <?php if(trim($trip['sadmin_reason_cancel'])!=''){ ?>                                         
                                                       <span class="mytooltip tooltip-effect-5" >
                                                   <span class="tooltip-item" style="background:#e37f7f;font-weigh:600;color:#fff;margin-top:7px;">!</span>
                                                   <span class="tooltip-content clearfix">
                                                     <span class="tooltip-text"><?=$trip['sadmin_reason_cancel'];?></span>
                                                 </span>
                                             </span>
                                             <?php } ?>
                                        </div>
                                    </div>
                                    <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                            <div class="dtails p-0 border-0 ">
                            <?php 
                                                            $obj_passengers=new \App\Models\Passengers();
                                                            $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                            if(sizeof($getPassengers)>0){
                                                            ?>
                                                            <ul>
                                                            <?php
                                                            $n=1;                                    
                                                            foreach($getPassengers as $get){
                                                            ?>
                                                            <li> <i class="fa fa-user"></i>
                                                                <?php if($get['passenger_name']!='') { 
                                                                echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                } 
                                                                if($get['passenger_contact']!=''){
                                                                    echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                } if($get['passenger_location']!=''){
                                                                    echo $get['passenger_location'];
                                                                }?>
                                                            </li>
                                                            <?php
                                                            $n++;
                                                            }
                                                            ?>
                                                            </ul>
                                                            <?php
                                                            }
                                                            ?>
                            <ul class="w-100 float-left">
                            <li class="text-red">Driver Note: <?=$trip['driver_note'];?> </li>
                            <ul>
                            <ul class="w-100 float-left">
                                    <li class="text-red">Cancellation Reason:  </li>
                                    <li><?=$trip['sadmin_reason_cancel'];?></li>
                                </ul>
                            <?php if($trip['sadmin_approval']==1){
                                
                        $obj_job= new \App\Models\Jobcard(); 
                        $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                    
                        if($getJob['driver_id']!=0){
                        $obj_driver= new \App\Models\Drivers();        
                    $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                    
                    ?>
                    <div class="dtails border-0">
                        <h3 class="text-left">Driver Details</h3>
                        <hr>
            
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                        <?php } ?><br/>
                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                                
                                                                                <ul>
                                                                                        <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                                        <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col-lg-4 text-left">
                                                                                    <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                                    <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                                    <p>Emirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                                    <p>Emirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                                </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php } 
                                                        
                                                        if($getJob['supplier_id']!=0){
                                                            $obj_supp= new \App\Models\Supplier();        
                                                        $currentsupplier=$obj_supp->where('sup_id',$getJob['supplier_id'])->first();
                                                        ?>
                                                            <div class="dtails border-0">
                                                                <h3 class="text-left">Supplier Details</h5>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-12"></div>
                                                                    <div class="col-lg-4">
                                                                        
                                                                        <h3><?=$currentsupplier['sup_name'];?></h3>
                                                                    </div>
                                                                    <div class="col-lg-4">                                                          
                                                                    <ul>
                                                                            
                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                            <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-lg-4">  </div>
                                                                    
            
                                                                </div>
                                                            </div>
                                                        <?php }
                                                        } ?>
                            
                                
                                                                    </div>
                                                                </div>
                        </div>   <?php
                                                $i++;
                                                }
                                                endforeach;
                                                if($cancel==0){
                                                    echo "Empty List";
                                                }
                                            ?>                                 
                                
                            </div>
                </div>
                <!--end cancelled -->
            </div>

    </div>

</div>
<?php if ($pager) :?>
                                            <?php $pagi_path='/booking/view/'.$cat?>
                                            <?php $config = $this-> pager_config;
                                                  $config ['base_url'] = base_url($pagi_path); ?>
                                            <?php //$pager->setPath(site_url($pagi_path)); ?>
                                            <?= $pager->links() ?>
                                            <?php endif ?>
<?= $this->endSection() ?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $(document).ready(function(){      
     
      $(':radio').change(function(){
          var trip_typ=$(this).val();
          if(trip_typ==1){
              $('#drivers').show();
              $('#suppliers').hide();
          }else{
              $('#drivers').hide();
              $('#suppliers').show();
          }
      })
  
    });  
    $(document).ready(function() {
            $(".dlt-bt").click(function() {
                var me = $(this);
                var data = me.data('params');
                
                var delView='#delView'+data;
                
                            
                $(delView).toggle('slow');
            });

            $(".view-more-btn").click(function() {
                var me = $(this);
                var data = me.data('params');                
                var ViewFull='#viewFull'+data;        
                            
                $(ViewFull).toggle('slow');
               
            });
        });

   
   
</script>
<?= $this->endSection() ?>