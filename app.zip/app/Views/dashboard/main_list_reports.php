<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

        <input type="text" id="company" onkeyup="searchCompany()" placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">
            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>
                <a href="<?=base_url('booking/mainexport')?>" title="Save" class="btn btn-primary btn-sm" style="float: right;" ><i class="fas fa-save"></i> </a>
               
                
            </div>

            <div class="card-block">

                <div class="table-responsive">

                    <table id="bookings" class="table table-striped table-bordered" style="width:100%">

                        <thead>

                            <tr>
                                <th>Date</th>
                                <th>Booking ID</th>
                                <th>User</th>
                                <th>Pick up time</th> 
                                <th>From </th>  
                                <th>To </th>  
                                <th>Booking Type </th>      
                                <th>Trip Type </th>  
                                <th>Car Preferences</th>
                                <th>Passengers Details </th>
                                <th>Department</th>
                                <th>Project Code</th>
                                <th>Task Code</th>
                                <th>Trip Amount</th>
                                <th>Payment Status</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php 
                                //$i=1;
                                foreach($trips as $trip):
                            ?>                       

                            <tr>

                                <td><?=$trip['booking_date']?></td>
                                <td><?=$trip['booking_id']?></td>
                                <td><?=$trip['cor_name']."(".$trip['cadmin_companyName'].")"?></td>
                                <td><?=$trip['booking_time']?></td>
                                <td><?=$trip['booking_from']?></td>
                                <td><?=$trip['booking_to']?></td>
                                <td><?=$trip['bt_type']?></td>
                                <td><?=$trip['trt_type']?></td>
                                <td><?=$trip['ct_type']?></td>
                                <td> <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
  </td>
                                <td><?=$trip['booking_department']?></td>
                                <td><?=$trip['booking_projectCode']?></td>
                                <td><?=$trip['booking_taskCode']?></td>
                                <td><?=$trip['booking_amount']?></td>
                                <td><?php 
                                    if($trip['sadmin_approval']==4){
                                        echo "Paid";
                                    }
                                    if($trip['sadmin_approval']==5){
                                        echo "Un Paid";
                                    }
                                    ?>
                                    </td>

                            </tr> 
                        <?php 
                        endforeach;
                        ?>   
                        </tbody>

                       
                    </table>

                </div>
                <?php if ($pager) :?>
                <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                <?php $config = $this-> pager_config;
                      $config ['base_url'] = base_url($pagi_path); ?>
                <?php //$pager->setPath(site_url($pagi_path)); ?>
                <?= $pager->links() ?>
                <?php endif ?>
            </div>

        </div>

    </div>

</div>
<?=$this->endSection()?>


