<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

        <input type="text" id="search"  placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>

            </div>
                
            
            <ul class="nav nav-tabs  tabs" >
            <li class="nav-item"><a class="nav-link <?php if($cat=='all'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/all');?>" > All</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='bookings'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/bookings');?>" >Bookings</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='confirmed'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/confirmed');?>" >Confirmed booking</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='cancelled'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/cancelled');?>" role="tab">Prominent Cancelled booking</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='pending'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/pending');?>" role="tab"> Prominent-Pending</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='paid'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/paid');?>" role="tab"> Paid booking</a></li>
            <li class="nav-item"><a class="nav-link <?php if($cat=='unpaid'){echo 'active';}?>"  href="<?php echo base_url('/booking/viewCorporateBooking/unpaid');?>" role="tab"> Un Paid booking</a></li>
            </ul>
            <?php  $i=1; ?>
            <div class="tab-content tabs card-block">
            <div class="tab-pane <?php if($cat=='unpaid'){echo 'active';}?>" id="unpaid" role="tabpanel">
            <div class="card-block">
                    <?php
                           $upaid=0;
                            foreach($trips as $trip):
                                if($trip['sadmin_approval']==5){
                                    $unpaid=$unpaid+1;
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>  
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Task Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                          
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                               
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                            <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php } else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        }
                                        endforeach;
                                        if($unpaid==0){
                                            echo "Empty List";
                                        }
                                    ?>                                 
                            
                            
            

                        

                    </div>

            </div>
            <div class="tab-pane <?php if($cat=='paid'){echo 'active';}?> " id="paid" role="tabpanel">
            <div class="card-block">
                    <?php
                           $paid=0;
                           
                            foreach($trips as $trip):
                                if($trip['sadmin_approval']==4){
                                    $paid=$paid+1;
                        ?>
                        
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>  
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                               
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                            <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php } else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        }
                                        endforeach;
                                          if($paid==0){
                                            echo "Empty List";
                                        }
                                    ?>                                 
                            
                            
            

                        

                    </div>

            </div>
            <div class="tab-pane <?php if($cat=='bookings'){echo 'active';}?>" id="bookings" role="tabpanel">
            <div class="card-block">
                    <?php
                           $books=0;
                          
                            foreach($trips as $trip):
                               // if(($trip['cadmin_approval']==0)||($trip['cadmin_approval']==2)||($trip['cadmin_approval']==3)){
                                    $books=$books+1;
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>  
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            <?php
                                            if($trip['sadmin_approval']==0){
                                                ?>                                     
                                                
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/editBooking/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                            <?php } ?>
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                                <?php
                                                    if($trip['sadmin_approval']!=1){
                                                ?>
                                            <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign_corporate/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Approve /  cancel"></i></a></li>
                                                <?php } ?>
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                            <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php }else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                       <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        //}
                                        endforeach;
                                          if($books==0){
                                            echo "Empty List";
                                        }
                                    ?>                                 
                            
                            
            

                        

                    </div>

            </div>
                <div class="tab-pane <?php if($cat=='confirmed'){echo 'active';}?> " id="confirmed" role="tabpanel">
                    <div class="card-block">
                    <?php
                           $confirm=0;
                            foreach($trips as $trip):
                                if($trip['sadmin_approval']==1){
                                    $confirm=$confirm+1;
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>   
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            <?php
                                            if(($trip['sadmin_approval']==0)&& ($trip['cadmin_approval']==1)){
                                                ?>                                     
                                                
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/editBooking/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                            <?php } ?>
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                                <?php
                                                    if($trip['sadmin_approval']!=1){
                                                ?>
                                            <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign_corporate/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Approve /  cancel"></i></a></li>
                                                <?php } ?>
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                             <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php }else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                       <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        }
                                        endforeach;
                                          if($confirm==0){
                                            echo "Empty List";
                                        }
                                    ?>                                 
                            
                            
            

                        

                    </div>
                </div>
                <div class="tab-pane <?php if($cat=='cancelled'){echo 'active';}?>" id="cancelled" role="tabpanel">
                    <div class="card-block">
                    <?php
                           $cancel=0;
                            foreach($trips as $trip):
                                if($trip['sadmin_approval']==2){
                                    $cancel=$cancel+1;
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li> 
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>       <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/editBooking/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                            
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                               
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                            <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php } else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Reason For cancellation: <?=$trip['sadmin_reason_cancel'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        }
                                        endforeach;
                                          if($cancel==0){
                                            echo "Empty List";
                                        }
                                    ?>                                 
                            
                            
            

                        

                    </div>
                </div>
                <div class="tab-pane <?php if($cat=='pending'){echo 'active';}?> " id="pending" role="tabpanel">
                <div class="card-block">
                    <?php
                           $pending=0;
                            foreach($trips as $trip):
                                if(($trip['sadmin_approval']==0)&&($trip['cadmin_approval']==1)){
                                    $pending=$pending+1;
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            <?php
                                            if(($trip['sadmin_approval']==0)&& ($trip['cadmin_approval']==1)){
                                                ?>                                     
                                                
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/editBooking/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                            <?php } ?>
                                        
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                                <?php
                                                    if($trip['sadmin_approval']!=1){
                                                ?>
                                            <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign_corporate/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Approve /  cancel"></i></a></li>
                                                <?php } ?>
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                             <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php } else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        }
                                        endforeach;
                                          if($pending==0){
                                            echo "Empty List";
                                        }
                                    ?> 
                    </div>
                </div>
                <div class="tab-pane <?php if($cat=='all'){echo 'active';}?>" id="all" role="tabpanel">
            <div class="card-block">
                    <?php
                           $all=0;
                            foreach($trips as $trip):
                             $all=$all+1;  
                        ?>
                        <div class="view-detail-div w-50" id="delView<?=$i;?>">
                            <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                            <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                            <div class="dtails">
                            <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                            <input  type="submit" class="btn btn-danger" value="Delete" />  
                            </div>
                            </form>
                        </div>
                    
                        <div class="dtails p-0 <?php if($i%2 == 0){ echo 'dtails-alt'; }?>">
                            <div class="row m-0">
                                <div class="col-md-9 p-4">                            
                                    <ul class="float-left w-30 text-left">
                                        <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li>
                                        <li >Booked By: <?=$trip['cor_name'];?></li>
                                        <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>  
                                         <li><i class="fa fa-building" aria-hidden="true" title="Project Code"></i><?=$trip['booking_taskCode'];?></li>                                    
                                        <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>                                
                                    </ul>
                                    <ul class="float-left w-35 text-left">
                                        <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                                        <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                                        <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                                        <?php if(trim($trip['booking_return_time'])!=''){?>
                                        <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                                        <?php } ?>
                                    </ul>
                                    <ul class="float-left w-35 text-left">    
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                 
                                        <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                                
                                        <?php if($trip['booking_stop']!=''){?>
                                    
                                    <?php
                                        $arr=explode('-*-',$trip['booking_stop']);
                                        //print_r($arr);
                                       // echo $imp=implode(",",$arr);
                                       $j=0;
                                        foreach ($arr as $imp):
                                            $j=$j+1;
                                     ?>
                                <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - stop"></i><?php echo "STOP".$j."-".$imp;?></li>
                                <?php 
                                endforeach;
                            } ?>
                                        <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                                        <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                                        
                                    </ul>
                                    <ul class="bdr-btn">                
                                            <?php
                                            if(($trip['sadmin_approval']==0)||($trip['sadmin_approval']==2)||($trip['sadmin_approval']==3)){
                                                ?>                                     
                                                
                                            <li class="mr-2 border-btn float-right"><a href="<?=base_url('booking/editBooking/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                                            <li class="mr-2 border-btn red-border float-right"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                                           
                                            <?php } ?>
                                            <?php  if($trip['sadmin_approval']==0){ ?>
                                            <li class="mr-2 border-btn green-border float-right"><a href="<?=base_url('booking/approve_assign_corporate/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Approve /  cancel"></i></a></li>
                                          <?php } ?>
                                            <li class="mr-2 border-btn green-border float-right"><a class="plus-bt view-more-btn pointer" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                                                
                                    </ul>
                                </div>
                                <div class="col-md-3 p-4 price-bg text-center">
                                    <?php 
                                        if(trim($trip['booking_amount'])!=''){ ?>
                                             <h5 class="text-center text-red"><span> <?=$trip['booking_amount'];?> AED</span></h5>
                                            <!--<h5 class="text-center text-red"><?=$trip['booking_from'];?> <br><i class="fa fa-exchange" aria-hidden="true"></i> <br><?=$trip['booking_to'];?> :<span> <?=$trip['booking_amount'];?> AED</span></h5>  -->
                                    <?php } ?>
                                    <?=$trip['cor_name'];?>

                                    <ul>
                                        <?php if($trip['cadmin_approval']==0){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                                        <?php }else  if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Confirmed</a></li>
                                        <?php } else if($trip['cadmin_approval']==2){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                                        <?php }else  if($trip['cadmin_approval']==3){ ?>
                                                    <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                                        <?php } ?>

                                        <?php if($trip['sadmin_approval']==0){
                                                if($trip['cadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                                        <?php   } 
                                            }else  if($trip['sadmin_approval']==1){ ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Confirmed by prominent</a></li>    
                                        <?php } else if($trip['sadmin_approval']==2){  ?>
                                                    <li class="w-100 m-0 mb-1"><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                                        <?php }else if($trip['sadmin_approval']==3){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Resend to prominent</a></li>  
                                    <?php } else if($trip['sadmin_approval']==4){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval">  Paid </a></li>  
                                    <?php } else if($trip['sadmin_approval']==5){  ?>
                                                <li class="w-100 m-0 mb-1 mt-2"><a href="#" class="pwait-btn" title="Prominent Approval"> Un Paid </a></li>  
                                    <?php } ?>
                                    </ul>

                                </div>
                            </div>
                            <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                                        <div class="dtails pt-1 border-0 bg-none">
                                        <?php 
                                                                        $obj_passengers=new \App\Models\Passengers();
                                                                        $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                                        if(sizeof($getPassengers)>0){
                                                                        ?>
                                                                        <ul>
                                                                        <?php
                                                                        $n=1;                                    
                                                                        foreach($getPassengers as $get){
                                                                        ?>
                                                                        <li> <i class="fa fa-user"></i>
                                                                            <?php if($get['passenger_name']!='') { 
                                                                            echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_contact']!=''){
                                                                                echo $get['passenger_contact'].'&nbsp;&nbsp;&nbsp;';
                                                                            } 
                                                                            if($get['passenger_location']!=''){
                                                                                echo $get['passenger_location'];
                                                                            } ?>
                                                                        </li>
                                                                        <?php
                                                                        $n++;
                                                                        }
                                                                        ?>
                                                                        </ul>
                                                                        <?php
                                                                        }
                                                                        ?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                                        <ul>
                                        <?php if(trim($trip['sadmin_reason_cancel'])!=''){?>
                                        <ul class="w-100 float-left">
                                        <li class="text-red">Reason for cancellation: <?=$trip['sadmin_reason_cancel'];?></li>
                                        <ul>
                                            <?php } ?>
                                        <?php if($trip['sadmin_approval']==1){
                                            
                                            $obj_job= new \App\Models\Jobcard(); 
                                            $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                                        
                                            if($getJob['driver_id']!=0){
                                            $obj_driver= new \App\Models\Drivers();        
                                        $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                                        
                                        ?>
                                        <div class="dtails border-0">
                                        <h3 class="text-left">Driver Details</h3>
                                        <hr>
                            
                                                                                <div class="row">
                                                                                    <div class="col-12"></div>
                                                                                    <div class="col-lg-4">
                                                                                        <?php if($currentdriver['driver_photo']!='') {?>
                                                                                        <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                                        <?php } ?><br/>
                                                                                        <h3><?=$currentdriver['driver_name'];?></h3>
                                                                                    </div>
                                                                                    <div class="col-lg-4">
                                                                                        
                                                                                    <ul>
                                                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                                            <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                                            
                                                                                        </ul>
                                                                                    </div>
                                                                                
                            
                                                                                </div>
                                                                            </div>
                                                                        <?php } 
                                                                        
                                                                        
                                                                        } ?>
                                            
                                                
                                                    
                                        
                                                                            </div>
                                                                        </div>
                                </div>
                                <?php
                                        $i++;
                                        
                                        endforeach;
                                         if($all==0){
                                            echo "Empty List";
                                        }
                                        ?>
                                       
                    </div>
                   
            
            </div>
            
            </div>   

        </div>

    </div>

</div>
<?php if ($pager) :?>
                                            <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                                            <?php $config = $this-> pager_config;
                                                  $config ['base_url'] = base_url($pagi_path); ?>
                                            <?php //$pager->setPath(site_url($pagi_path)); ?>
                                            <?= $pager->links() ?>
                                            <?php endif ?>
                                     
<?=$this->endSection()?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $('select').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var rows = $('table tr');
    var cancel = rows.filter('#cancel');
    
    if(valueSelected==2){        
        cancel.show();
    }else{
        cancel.hide();
    }
});
$('form').on('submit', function (e) {
  
    var str=$(this).find("[id=reason]").val();
    
    var valueSelected = $(this).find('#status :selected').val();
    
    if(valueSelected==2){
        
        if($.trim(str)==''){ 
            $(this).find("[id=errmsg]").show();                      
            return false;
        }else{
            $(this).find("[id=errmsg]").hide();  
            return true;
        }
       
    }else{
        return true;
    }
});

/*$('[data-dismiss=modal]').on('click', function (e) {
    alert('hi');
    $(this).find('form').trigger('reset');
});*/

$('.modal').on('hidden.bs.modal', function () {
    
    $(this).find("[id=approval]").trigger('reset');
    var valueSelected = $(this).find('#status :selected').val();
    if(valueSelected==2){
        var rows = $('table tr');
        var cancel = rows.filter('#cancel');
        cancel.show();
    }
    });
    $(document).ready(function() {
            $(".dlt-bt").click(function() {
                var me = $(this);
                var data = me.data('params');
                
                var delView='#delView'+data;
                
                            
                $(delView).toggle('slow');
            });

            $(".view-more-btn").click(function() {
                
                var me = $(this);
                
                var data = me.data('params');  

                var ViewFull='#viewFull'+data;    
                //alert(ViewFull);    
                            
                $(ViewFull).toggle('slow');
               
            });
        });

</script>
<?=$this->endSection()?>


   