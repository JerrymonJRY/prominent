<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">


<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

                
                
                <?php
                    if(!empty(session()->getFlashdata('result'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?php 
                           $errors=session()->getFlashdata('result');
                           foreach($errors as $error){
                           echo $error."<br/>";
                           }
                    ?>
                </span>
                <?php endif;?>
                <h5><?=$header?> </h5>
             
            </div>

            <div class="card-block">
            <form  action="" method="POST" enctype="multipart/form-data" >
            <?= csrf_field();?>
                <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Name</label>
                 <div class="col-sm-5">
                   <input type="text" name="name" id="name" class="form-control" required="" value="<?=$supInfo['sup_name'];?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="email" id="email" class="form-control"  value="<?=$supInfo['sup_email'];?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="contactNo" id="contactNo" class="form-control" required="" value="<?=$supInfo['sup_tel'];?>">
                 </div>
               </div>

               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Reservation Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="reserve_contactNo" id="reserve_contactNo" class="form-control"  value="<?=$supInfo['sup_reservation_contact'];?>">
                 </div>
               </div>

               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Reservation  Email</label>
                 <div class="col-sm-5">
                   <input type="text" name="reserve_email" id="reserve_email" class="form-control"  value="<?=$supInfo['sup_reservation_email'];?>">
                 </div>
               </div>

               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Accounts Email</label>
                 <div class="col-sm-5">
                   <input type="text" name="acc_email" id="acc_email" class="form-control"  value="<?=$supInfo['sup_acc_email'];?>">
                 </div>
               </div>

               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Accounts Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="acc_contactNo" id="acc_contactNo" class="form-control"  value="<?=$supInfo['sup_acc_contact'];?>">
                 </div>
               </div>

               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Bank Account Details</label>
                 <div class="col-sm-5">
                   <input type="text" name="bank_acc" id="bank_acc" class="form-control"  value="<?=$supInfo['sup_bank_acc'];?>">
                 </div>
               </div>


               
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">.</label>
                <div class="col-sm-5">
                    <input type="reset" class="btn btn-primary" value="Reset" />
                    <input type="submit" class="btn btn-primary" value="Save" />
                </div>
               </div>

      
       </form> 

       </div>

</div>

</div>

</div>

</div>  
<?=$this->endSection()?>
          