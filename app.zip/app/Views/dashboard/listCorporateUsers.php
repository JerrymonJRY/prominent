<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

        <input type="text" id="company" onkeyup="searchCompany()" placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

                
                
               
                <?php
                    if(!empty(session()->getFlashdata('result'))):
                ?>
                <span class="btn btn-danger waves-effect" data-type="danger" data-from="top" data-align="right"><?= session()->getFlashdata('result')?></span>
                <?php endif;?>
                <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>
            </div>

            <div class="card-block">

                <div class="table-responsive">



                    <table id="bookings" class="table table-striped table-bordered" style="width:100%">

                        <thead>

                            <tr>
                                <th>Sl No</th>
                                <th>Employee Id</th>
                                <th>Name</th>
                                <th>Email/UserName</th>
                                <th>Contact</th>
                                <th>Active</th>                                 
                                <th>Delete</th>                                
                            </tr>                           
                        </thead>
                        <tbody>
                            <?php
                                 $i=1;
                                foreach($corUser as $details):
                            ?>
                            <tr>
                                <td><?=$i?></td>
                                <td><?=$details['cor_employeeId'];?></td>
                                <td><?=$details['cor_name'];?></td>
                                <td><?=$details['cor_email'];?></td>
                                <td><?=$details['cor_contact'];?></td>
                                <td>
                                    <?php 
                                        if($details['user_active']==1){
                                    ?>
                                            <a href="<?=base_url('dashboard/deactivate/'.$details['user_id']);?>" class="btn btn-success btn-sm">Activated</a>

                                    <?php                                            
                                        }else{
                                    ?>
                                            <a href="<?=base_url('dashboard/activate/'.$details['user_id']);?>" class="btn btn-danger btn-sm">Pending</a>
                                    <?php
                                        }
                                    ?>
                                </td>
                                <td> <a href="" title="Delete" class="btn btn-danger btn-sm red-btn" data-toggle="modal" data-target="#exampleModalDelete<?=$i?>">
                                    <i class="fa fa-trash fa-2x mr-0" aria-hidden="true"></i>
                                </a>  
                               
                                <div class="modal fade" id="exampleModalDelete<?=$i?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                    <form action="<?=base_url('dashboard/delete/'.$details['user_id'])?>" method="POST">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation  !!</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">                                
                                                <label> </label>
                                                <span>Are you confirm to delete "<?=$details['cor_name']?>" ?</span>                               
                                            </div>
                                            <div class="modal-footer">
                                                 
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <input  type="submit" class="btn btn-primary" value="OK" />                                
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                                </td>
                            </tr>
                            <?php
                                $i++;
                                endforeach;
                            ?>                            
                        </tbody>

                    </table>

                </div>
                <?php if ($pager) :?>
                <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                <?php $config = $this-> pager_config;
                      $config ['base_url'] = base_url($pagi_path); ?>
                <?php //$pager->setPath(site_url($pagi_path)); ?>
                <?= $pager->links() ?>
                <?php endif ?>
            </div>

        </div>

    </div>

</div>
<?=$this->endSection()?>