<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">


<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">
            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                
                <h5><?=$header?></h5>
                
                
                
            </div>
            <div class="card-block">
                <form  action="" method="POST" >
                <?= csrf_field();?>
                <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Name</label>
                 <div class="col-sm-5">
                   <input type="text" name="name" id="name" class="form-control" required value="<?=$info['cor_name'];?>" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="email" id="email" class="form-control" required value="<?=$info['cor_email'];?>" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Contact</label>
                <div class="col-sm-2">
                <input type="text" name="contactCode" id="contactCode" class="form-control " value="<?=$info['cor_contactCode'];?>" placeholder="Country Code"   required>
                </div>
                 <div class="col-sm-3">
                   <input type="text" name="contact" id="contact" class="form-control" required value="<?=$info['cor_contact'];?>" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Employee Id</label>
                 <div class="col-sm-5">
                   <input type="text" name="employeeid" id="employeeid" class="form-control" required value="<?=$info['cor_employeeId'];?>" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right"></label>
                <div class="col-sm-5">
                <input type="reset" class="btn btn-primary" value="Reset" />
                    <input type="submit" class="btn btn-primary" value="Save" />
                </div>
               </div>
      
       </form> 

       </div>


        </div>

    </div>

</div>
<?=$this->endSection()?>


