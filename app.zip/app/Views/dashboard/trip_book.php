<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
        <!-- Basic Form Inputs card start -->
            <div class="card">
                <div class="card-header">
                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>

                
                <span id="errmsgspan" class="alert alert-result-fail" style="display: none;">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                     </button>      
                </span>
                
                    <h5><?=$header;?></h5>
                </div>
                <div class="card-block">
                <form action="<?=base_url('booking/corporate');?>" method="POST">
                <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Car Preference</label>
                            <div class="col-sm-5">
                                <select name="carPreference" id="carPreference" class="form-control" required>
                                    <option >Car Preference</option>
                                    <?php foreach($carType as $type):?>                                    
                                    <option value="<?=$type['ct_id'];?>"><?=$type['ct_type'];?></option>
                                   <?php endforeach;?>                                                                       
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Booking Type</label>
                            <div class="col-sm-5">
                                <select name="bookType" id="bookType" class="form-control" required>
                                    <option >Booking Type</option>
                                    <?php foreach($bookType as $btype):
                                        if($btype['bt_id']==3){ ?>
                                        <option value="<?=$btype['bt_id'];?>"><?=$btype['bt_type'];?><label style="">(Select multiple dates in calendar)</lable></option>
                                       <?php  }else{ ?>
                                    
                                    <option value="<?=$btype['bt_id'];?>"><?=$btype['bt_type'];?></option>
                                    <?php } ?>
                                   <?php endforeach;?>                                                                            
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Trip Type</label>
                            <div class="col-sm-5">
                                <div class="btn-group btn-group-vertical" data-toggle="buttons">
                                    <?php 
                                    $i=0;
                                    foreach($tripType as $trip):
                                        if($i==0):
                                    ?>
                                            <label class="btn active">
                                            <input type="radio" name='trip' id="trip" value="<?=$trip['trt_id'];?>" checked><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i> <span> <?=$trip['trt_type'];?></span>
                                            </label>
                                    <?php   
                                        else:    
                                                                            
                                    ?>
                                            <label class="btn">
                                            <input type="radio" name='trip' id='trip' value="<?=$trip['trt_id'];?>" ><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i>
                                            <span> <?=$trip['trt_type'];?> 
                                                <?php 
                                                        if($i==2):
                                                         echo "( More than 10 hrs will be charged extra )";
                                                        endif;
                                                ?>
                                                        
                                            </span>
                                            </label>
                                    <?php
                                        endif;
                                        $i++;
                                    endforeach;
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Select Date</label>
                            <div class="col-sm-5">
                                <i class="ti-calendar date-ic"></i>
                                <input id="mdp-demo" name="mdp-demo" class="form-control" placeholder="Select Date"   required>                                                                   
                                <!--<label class="text-right" style="color: #BDC3C7;">Date format : yyyy-mm-dd <br/> eg : 2022-02-02</label>
                                <label id="errdate" class="text-right" style="color: #E74C3C;display:none;">Date should be greater than today </label>-->
                            </div>
                            
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Pick up Time</label>
                            <div class="col-sm-2">
                            <select id="pickuptimehr" name="pickuptimehr" class="form-control" >
                                <option selected>Hour</option>
                                <?php for($l=1;$l<25;$l++){ 
                                    $hr = ($l < 10) ? '0'.$l : $l;
                                ?>
                                <option value="<?=$hr;?>"><?=$hr;?></option>
                            <?php }?>
                            </select>
                            </div>
                            <div class="col-sm-2">
                            <select id="pickuptimemin" name="pickuptimemin" class="form-control" >
                                <option selected>Minute</option>
                                <?php for($i=00;$i<60;$i++){
                          $min = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$min;?>"><?=$min;?></option>
                     <?php 
                      }
                      ?>
                            </select>
                            </div>
                        </div>
                        
                        <div class="form-group row" id="return" style="display: none;">
                            <label class="col-sm-4 col-form-label text-right">Return Time</label>
                            
                            <div class="col-sm-2">
                            <select id="returntimehr" name="returntimehr" class="form-control" >
                                <option selected>Hour</option>
                                <?php for($l=1;$l<25;$l++){ ?>
                                <option value="<?=$l;?>"><?=$l;?></option>
                            <?php }?>
                            </select>
                            </div>
                            <div class="col-sm-2">
                            <select id="returntimemin" name="returntimemin" class="form-control" >
                                <option selected>Minute</option>
                                <?php for($i=00;$i<60;$i++){
                          $min = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$min;?>"><?=$min;?></option>
                     <?php 
                      }
                      ?>
                            </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Select Location</label>
                            <div class="col-sm-2">
                                <input type="text" id="from" name="from" class="form-control" required placeholder="From">
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="to" name="to" class="form-control" placeholder="To" required>
                            </div>
                            <div >
                                <button id="add" name="add" class="btn btn-primary btn-sm" type="button" >Add Stop</button>
                                <input type="hidden" name="numadstop" id="numadstop" value="0"/>
                            </div>
                        </div>
                        <div class="form-group row" > 
                            <label class="col-sm-4 col-form-label text-right"></label>
                            <div class="col-sm-4"><table id="dynamic_field"></table></div>
                        </div>                                                 
                           
                        
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">No. of Passengers</label>
                            <div class="col-sm-5">
                                <input type="text" id="passengers" required name="passengers" class="form-control" placeholder="No. of Passengers">
                                <input type="hidden" name="numpass" id="numpass" value="0"/>
                            </div>
                        </div>
                        <div class="form-group row" > 
                            <label class="col-sm-4 col-form-label text-right">Passengers Details</label>
                            <div class="col-sm-5"><table id="dynamic_field_passengers"></table></div>
                        </div> 
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Department</label>
                            <div class="col-sm-5">
                            <input type="text"  class="form-control" placeholder="Department" id="department" name="department" required="" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Project Code</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" placeholder="Project Code" id="project_code" name="project_code" required="" >
                            </div>
                            <label class=" col-form-label text-right">Task Code</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" placeholder="task Code" id="task_code" name="task_code" required="" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Driver Note</label>
                            <div class="col-sm-5">
                                <textarea class="form-control" placeholder="Driver note" id="driver_note" name="driver_note" rows="8" ></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right"></label>
                            <div class="col-sm-5">
                                <button class="btn btn-primary btn-round waves-effect waves-light w-50">Submit</button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $(document).ready(function(){      
      var i=1;  
     
   
      $('#add').click(function(){  
           i++; 
           
                    
           $('#numadstop').val(parseInt($('#numadstop').val()) + 1);
           //$('#dynamic_field').append(' <label class="col-sm-4 col-form-label text-right"></label>   <div id="row'+i+'"  ><input type="text" name="addmore[][stop]" class="form-control" placeholder="Stop" required /><button type="button" name="remove" id="'+i+'" >X</button></div>');
           $('#dynamic_field').append('<tr id="row'+i+'" ><td><input type="text" name="addmore[]" placeholder="Stop"   /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn-sm red-btn">X</button></td></tr>');  
      });
  
      $(document).on('click', '.btn-danger', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
           $('#numadstop').val($('#numadstop').val()-1);
      });  
     

     


      $(':radio').change(function(){
          var trip_typ=$(this).val();
          if(trip_typ==2){
              $('#return').show();
          }else{
            $('#return').hide();
          }
      })
      $('#bookType').on('change', function() {

          var book_type=$(this).val();
          
          if(book_type==1){
            
            $('#mdp-demo').multiDatesPicker('destroy'); 
            $('#mdp-demo').multiDatesPicker('resetDates');           
            $('#mdp-demo').multiDatesPicker({
                autoclose: true,
                dateFormat: 'yy-mm-dd',
                minDate: 0,
                maxDate:0
                }).on('keydown',function(event){
                   
						event.preventDefault();
					});

          } else if(book_type==2){
            $('#mdp-demo').multiDatesPicker('destroy');
            $('#mdp-demo').multiDatesPicker('resetDates');
            $('#mdp-demo').multiDatesPicker({
                autoclose: true,
                dateFormat: 'yy-mm-dd',
                minDate: 0,
                maxPicks: 1
                }).on('keydown',function(event){
                   
						event.preventDefault();
					});
            
          } else if(book_type==3){
            $('#mdp-demo').multiDatesPicker('destroy');
            $('#mdp-demo').multiDatesPicker('resetDates');
            $('#mdp-demo').multiDatesPicker({
                autoclose: true,
                dateFormat: 'yy-mm-dd',
                minDate: 0
                }).on('keydown',function(event){
                   
						event.preventDefault();
					});
          }
      });
      /*$("#submit").click(function() {
          var pickdate=$('#datepicker').val();
          if(pickdate!=''){
          var today = new Date();
			var dd = String(today.getDate()).padStart(2, '0');
			var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
			var yyyy = today.getFullYear();

			today = yyyy + '-' + mm + '-' + dd;
			if(pickdate>=today){                
                return true;
            }else{
                $('#errmsgspan').show();
                $('#errmsg').html('Date should be greater than or same as today date');
                return false;
            }
          }
      });*/
  
    });  
    $(document).ready(function(){      
      var j=1;  
   
      $('#passengers').keyup(function(){  
        
           
           var value=$('#passengers').val();
          
          if(value!=''){
              var n=0;
            var rowCount = $('#dynamic_field_passengers tr').length;
              if(rowCount>value){
                var difference=rowCount-value;
                for(var k=0;k<difference;k++){
                    $('#numpass').val(parseInt($('#numpass').val()) - 1);
                    $('#dynamic_field_passengers tr:last').remove();
                    
                  }
                
              }else{
                  var diff=value-rowCount;
                  n=rowCount;
                  for(var l=n;l<value;l++){
                    j++;
                    $('#numpass').val(parseInt($('#numpass').val()) + 1);
                    $('#dynamic_field_passengers').append('<tr id="rowP'+j+'" ><td><input type="text" name="passengerName[]" placeholder="Name" class="form-control "   /></td><td><input type="text" name="passengerContact[]" class="form-control" placeholder="Contact No:"   /></td><td><input type="text" name="passengerLocation[]" placeholder="Location" class="form-control "   /></td><td><button type="button" name="remove" id="'+j+'" class="btn btn-danger1 btn-sm red-btn" >X</button></td></tr>');  
                
                  }
              }
              
          }
      });

      $(document).on('click', '.btn-danger1', function(){ 
        $('#numpass').val(parseInt($('#numpass').val()) - 1); 
           var button_id = $(this).attr("id");   
           $('#rowP'+button_id+'').remove();  
      });          
  
    });  

   
   
</script>
<?= $this->endSection() ?>