<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

        <input type="text" id="search"  placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">

            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>

            </div>

            <div class="card-block">
            <?php
                    $i=1;
                    foreach($trips as $trip):
                ?>
                <div class="view-detail-div w-50" id="delView<?=$i;?>">
                    <h2> <a href="" data-params="<?=$i;?>" class="dlt-bt close-btn border-0 ">x</a></h2>
                    <form action="<?=base_url('booking/deletbooking/'.$trip['booking_id'])?>" method="POST">
                    <div class="dtails">
                    <span>Are you confirm to delete Booking Id <?=$trip['booking_id'];?>  ?</span> </br></br>
                    <input  type="submit" class="btn btn-danger" value="Delete" />  
                    </div>
                    </form>
                </div>
               
                <div class="dtails">
                <?php 
                        if(trim($trip['booking_amount'])!=''){ ?>
                 <h4 class="text-center text-red"><span><?=$trip['booking_from'];?> To <?=$trip['booking_to'];?> : <?=$trip['booking_amount'];?> AED</span></h4>  
                 <?php } ?>
                <ul>
                    <li class="text-red">Booking ID: <?=$trip['booking_id'];?></li><?=$trip['cor_name'];?>
                    <li><i class="fa fa-building-o" aria-hidden="true" title="Project Code"></i><?=$trip['booking_projectCode'];?></li>                   
                    <li >Booked By: <?=$trip['cor_name'];?></li>
                    <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$trip['ct_type'];?></li>
                    <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$trip['bt_type'];?></li>
                    <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$trip['trt_type'];?></li>
                    <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$trip['booking_date'];?></li>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$trip['booking_time'];?></li>
                    <?php if(trim($trip['booking_return_time'])!=''){?>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$trip['booking_return_time'];?></li>
                    <?php } ?>
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$trip['booking_from'];?></li>                    
                   
                    <?php if($trip['booking_stop']!=''){?>
                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php
                                                            $arr=explode('-*-',$trip['booking_stop']);
                                                            echo $imp=implode(",",$arr);
                                                            ?></li>
                    <?php } ?>
                    <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$trip['booking_to'];?></li>
                    <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$trip['booking_NoPassengers'];?></li>
                    <?php if($trip['cadmin_approval']==0){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Pending</a></li>
                    <?php }else  if($trip['cadmin_approval']==1){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Approved</a></li>
                    <?php } else if($trip['cadmin_approval']==2){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Cancelled</a></li>
                    <?php }else  if($trip['cadmin_approval']==3){ ?>
                                <li><a href="#" class="wait-btn" title="Company Approval">Re Send</a></li>
                    <?php } ?>

                    <?php if($trip['sadmin_approval']==0){
                            if($trip['cadmin_approval']==1){ ?>
                                <li><a href="#" class="pwait-btn" title="Prominent Approval">Pending from prominent</a></li>               
                    <?php   } 
                          }else  if($trip['sadmin_approval']==1){ ?>
                                 <li><a href="#" class="pwait-btn" title="Prominent Approval">Approved by prominent</a></li>    
                    <?php } else if($trip['sadmin_approval']==2){  ?>
                                 <li><a href="#" class="pwait-btn" title="Prominent Approval">Cancelled by prominent</a></li>  
                    <?php } ?>
                   
               
                
                      <?php
                      if(($trip['sadmin_approval']==0)&& ($trip['cadmin_approval']==1)){
                  ?>
            
                                     
                                
                    <li class="mr-2"><a href="<?=base_url('booking/edit/'.$trip['booking_id']);?>"><i class="fa fa-pencil-square-o" aria-hidden="true" title="Edit Booking"></i></a></li>
                    <li class="mr-2"><a href="#" id="urlId" data-params="<?=$i;?>" class="dlt-bt"><i class="fa fa-trash-o" aria-hidden="true" title="Delete"></i></a></li>
                <?php } ?>
               
                <li class="mr-2"><a href="#" class="plus-bt view-more-btn" id="urlIdView" data-params="<?=$i;?>" ><i class="fa fa-search fa-2x mr-0" aria-hidden="true" title="View"></i></a></li>
                <?php
                      if($trip['sadmin_approval']!=1){
                  ?>
                <li class="mr-2"><a href="<?=base_url('booking/approve_assign_corporate/'.$trip['booking_id']);?>"  class="plus-bt"><i class=" fa fa-plus-square" aria-hidden="true" title="Approve /  cancel"></i></a></li>
               <?php } ?>
            </ul>
                <div class="view-detail-acc border-0" id="viewFull<?=$i?>">
                    <div class="dtails p-0 border-0 ">
                    <?php 
                                                    $obj_passengers=new \App\Models\Passengers();
                                                    $getPassengers=$obj_passengers->where('booking_id',$trip['booking_id'])->findAll();
                                                    if(sizeof($getPassengers)>0){
                                                    ?>
                                                    <ul>
                                                    <?php
                                                    $n=1;                                    
                                                    foreach($getPassengers as $get){
                                                    ?>
                                                    <li> <i class="fa fa-user"></i>
                                                        <?php if($get['passenger_name']!='') { 
                                                        echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                                                         } 
                                                        if($get['passenger_contact']!=''){
                                                            echo $get['passenger_contact'];
                                                        } ?>
                                                       
                                                    <?php
                                                    $n++;
                                                    }
                                                    ?>
                                                    </ul>
                                                    <?php
                                                    }
                                                    ?>
                    <ul class="w-100 float-left">
                    <li class="text-red">Driver Note: <?=$trip['driver_note'];?></li>
                    <ul>
                    <?php if($trip['sadmin_approval']==1){
                        
                        $obj_job= new \App\Models\Jobcard(); 
                        $getJob=$obj_job->where('booking_id',$trip['booking_id'])->first();
                       
                        if($getJob['driver_id']!=0){
                        $obj_driver= new \App\Models\Drivers();        
                       $currentdriver=$obj_driver->where('driver_id',$getJob['driver_id'])->first();
                       
                       ?>
                      <div class="dtails border-0">
                      <h3 class="text-left">Driver Details</h3>
                      <hr>
           
                                                               <div class="row">
                                                                   <div class="col-12"></div>
                                                                   <div class="col-lg-4">
                                                                       <?php if($currentdriver['driver_photo']!='') {?>
                                                                       <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                                       <?php } ?>
                                                                       <h3><?=$currentdriver['driver_name'];?></h3>
                                                                   </div>
                                                                   <div class="col-lg-4">
                                                                     
                                                                   <ul>
                                                                           <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                           <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                           <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                           <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                                       </ul>
                                                                   </div>
                                                                   <div class="col-lg-4 text-left">
                                                                       <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                                       <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                                       <p>Eirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                                       <p>Eirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                                   </div>
           
                                                               </div>
                                                           </div>
                                                       <?php } 
                                                       
                                                      
                                                    } ?>
                         
                             
                                
                     
                                                        </div>
                                                    </div>
            </div>
               <?php
                    $i++;
                    endforeach;
                ?>                                 
                

      

                

            </div>

        </div>

    </div>

</div>
<?=$this->endSection()?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $('select').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var rows = $('table tr');
    var cancel = rows.filter('#cancel');
    
    if(valueSelected==2){        
        cancel.show();
    }else{
        cancel.hide();
    }
});
$('form').on('submit', function (e) {
  
    var str=$(this).find("[id=reason]").val();
    
    var valueSelected = $(this).find('#status :selected').val();
    
    if(valueSelected==2){
        
        if($.trim(str)==''){ 
            $(this).find("[id=errmsg]").show();                      
            return false;
        }else{
            $(this).find("[id=errmsg]").hide();  
            return true;
        }
       
    }else{
        return true;
    }
});

/*$('[data-dismiss=modal]').on('click', function (e) {
    alert('hi');
    $(this).find('form').trigger('reset');
});*/

$('.modal').on('hidden.bs.modal', function () {
    
    $(this).find("[id=approval]").trigger('reset');
    var valueSelected = $(this).find('#status :selected').val();
    if(valueSelected==2){
        var rows = $('table tr');
        var cancel = rows.filter('#cancel');
        cancel.show();
    }
    });
    $(document).ready(function() {
            $(".dlt-bt").click(function() {
                var me = $(this);
                var data = me.data('params');
                
                var delView='#delView'+data;
                
                            
                $(delView).toggle('slow');
            });

            $(".view-more-btn").click(function() {
                var me = $(this);
                var data = me.data('params');                
                var ViewFull='#viewFull'+data;        
                            
                $(ViewFull).toggle('slow');
               
            });
        });

</script>
<?=$this->endSection()?>


   