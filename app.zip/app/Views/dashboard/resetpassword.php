<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">


<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">
            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                
                <h5><?=$header?></h5>
                
                
                
            </div>
            <div class="card-block">
                <form  action="" method="POST" >
                <?= csrf_field();?>
                <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Current Password</label>
                 <div class="col-sm-5">
                   <input type="password" name="cupassword" id="cupassword" class="form-control" required="" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">New Password</label>
                 <div class="col-sm-5">
                   <input type="password" name="npassword" id="npassword" class="form-control" required>
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Confirm Password</label>
                 <div class="col-sm-5">
                   <input type="password" name="cpassword" id="cpassword" class="form-control" required >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right"></label>
                <div class="col-sm-5">
                   
                    <input type="submit" class="btn btn-primary" value="Reset Password" />
                </div>
               </div>
      
       </form> 

       </div>


        </div>

    </div>

</div>
<?=$this->endSection()?>


