<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">

<div class="row">

    <div class="col-md-4">

        <input type="text" id="company" onkeyup="searchCompany()" placeholder="Your search text .." title="Type in a search text">

    </div>



</div>

<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">
            <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?></h5>
                
                <a href="<?=base_url('DriverMng/addNew')?>" title="Add" class="btn btn-primary btn-sm" style="float: right;" >Add New Driver </a>
                
            </div>

            <div class="card-block">

                <div class="table-responsive">



                    <table id="bookings" class="table table-striped table-bordered" style="width:100%">

                        <thead>

                            <tr>
                                <th>Sl No</th>
                                <th> Name</th>
                                <th>Email</th>
                                <th>Contact</th> 
                                <th>View/Edit/Delete</th>                                
                            </tr>
                        </thead>

                        <tbody>
                            <?php 
                                $i=1;
                                foreach($details as $det):
                            ?>                       

                            <tr>

                                <td><?=$i;?></td>

                                <td><?=ucfirst($det['driver_name'])?></td>

                                <td><?=$det['driver_email']?></td>
                                <td><?=$det['driver_contact']?></td>
                                

                                <td>
                                <a href="" title="View" class="btn btn-primary btn-sm red-btn" data-toggle="modal" data-target="#exampleModalsearch<?=$i?>">
                                    <i class="fa fa-search fa-2x mr-0" aria-hidden="true"></i>
                                </a>  
                               
                                <div class="modal fade" id="exampleModalsearch<?=$i?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                   
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">View Details</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">                                
                                            <table id="bookings" class="table  table-bordered" >
                                            <thead>
                                            <?php
                                                if($det['driver_photo']!=''):
                                            ?>
                                            <tr><td colspan="2"><img src="<?=base_url('uploads/'.$det['driver_photo']);?>"/></td></tr>
                                            <?php
                                                endif;
                                            ?>
                                                
                                                <tr>
                                                    <td>Driver Name</td>
                                                    <td><?=$det['driver_name'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>Nationality</td>
                                                    <td><?=$det['driver_nationality'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>Contact Number</td>
                                                    <td><?=$det['driver_contact'];?></td>
                                                </tr>

                                                <tr>
                                                    <td>Email</td>
                                                    <td><?=$det['driver_email'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>Address</td>
                                                    <td><?=$det['driver_address'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>License Number</td>
                                                    <td><?=$det['driver_license'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>License Expiry date</td>
                                                    <td><?=$det['driver_license_exp'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>Emirates</td>
                                                    <td><?=$det['driver_emirates_id'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>Emirates Expiry date </td>
                                                    <td><?=$det['driver_emirates_exp'];?></td>
                                                </tr>
                                                <tr>
                                                    <td>History </td>
                                                    <td><?=$det['driver_history'];?></td>
                                                </tr>
                                               
                                               </thead>
                                            </table>
                                                  
                                            </div>
                                            <div class="modal-footer">
                                                 
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                                
                                            </div>
                                        </div>
                                    
                                    </div>
                                </div>
                                 
                                <a href="<?=base_url('DriverMng/edit/'.$det['driver_id'])?>" title="Edit" class="btn btn-info btn-sm">
                                    <i class="fa fa-pencil fa-2x mr-0" aria-hidden="true"></i> 
                                </a>
                                 
                                

                                <a href="" title="Delete" class="btn btn-danger btn-sm red-btn" data-toggle="modal" data-target="#exampleModalDelete<?=$i?>">
                                    <i class="fa fa-trash fa-2x mr-0" aria-hidden="true"></i>
                                </a>  
                               
                                <div class="modal fade" id="exampleModalDelete<?=$i?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                    <form action="<?=base_url('DriverMng/delete/'.$det['driver_id'])?>" method="POST">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation  !!</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">                                
                                                <label> </label>
                                                <span>Are you confirm to delete "<?=$det['driver_name']?>" ?</span>                               
                                            </div>
                                            <div class="modal-footer">
                                                 
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <input  type="submit" class="btn btn-primary" value="OK" />                                
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                                </td>
 
                            </tr>
                            <?php 
                                $i++;
                                endforeach;
                            ?>
                        </tbody>

                    </table>

                </div>
                <?php if ($pager) :?>
                <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                <?php $config = $this-> pager_config;
                      $config ['base_url'] = base_url($pagi_path); ?>
                <?php //$pager->setPath(site_url($pagi_path)); ?>
                <?= $pager->links() ?>
                <?php endif ?>
            </div>

        </div>

    </div>

</div>
<?=$this->endSection()?>


