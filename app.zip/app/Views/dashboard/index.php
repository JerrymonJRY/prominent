<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<?php if($status==1){ ?>
    <?=$this->include('layout/maindashboard')?>
<?php }else if($status==2){?>
            <?php //$this->include('layout/listCorporateUsers');?>
            <?php //$this->include('layout/listTrips_adminView')?>
            <?=$this->include('layout/corporate_dashboard')?>
<?php }else if($status==3){?>
            <?=$this->include('layout/regular_listTrips')?>
<?php }  if($status==4){?>
            <?=$this->include('layout/listTrips')?>
<?php } ?>

<?=$this->endSection()?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    /*$('select').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var rows = $('table tr');
    var cancel = rows.filter('#cancel');
    
    if(valueSelected==2){        
        cancel.show();
    }else{
        cancel.hide();
    }
});
$('form').on('submit', function (e) {
  
    var str=$(this).find("[id=reason]").val();
    
    var valueSelected = $(this).find('#status :selected').val();
    
    if(valueSelected==2){
        
        if($.trim(str)==''){ 
            $(this).find("[id=errmsg]").show();                      
            return false;
        }else{
            $(this).find("[id=errmsg]").hide();  
            return true;
        }
       
    }else{
        return true;
    }
});

/*$('[data-dismiss=modal]').on('click', function (e) {
    alert('hi');
    $(this).find('form').trigger('reset');
});*/

/*$('.modal').on('hidden.bs.modal', function () {
    
    $(this).find("[id=approval]").trigger('reset');
    var valueSelected = $(this).find('#status :selected').val();
    if(valueSelected==2){
        var rows = $('table tr');
        var cancel = rows.filter('#cancel');
        cancel.show();
    }
    });*/
   
    $(document).ready(function() {
            $(".dlt-bt").click(function() {
                var me = $(this);
                var data = me.data('params');
                
                var delView='#delView'+data;
                
                            
                $(delView).toggle('slow');
            });

            $(".view-more-btn").click(function() {
                var me = $(this);
                var data = me.data('params');                
                var ViewFull='#viewFull'+data;        
                            
                $(ViewFull).toggle('slow');
               
            });
        });

</script>
<?=$this->endSection()?>


