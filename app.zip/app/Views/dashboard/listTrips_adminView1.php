<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">

                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row position-rel">
                                            
                                            <?php 
                                            $i=1;
                                            foreach($cards as $card){
                                                $objdriver=new \App\Models\Drivers();
                                                $objsubb= new \App\Models\Supplier();
                                                $objcar= new \App\Models\CarPreference();
                                                $getcar=$objcar->where('ct_id',$card['carType_id'])->first();
                                               $objbook=new \App\Models\Booktype();                                               
                                               $getbook=$objbook->where('bt_id',$card['bookType_id'])->first();
                                               $objtrip=new \App\Models\Triptype();  
                                               $gettrip=$objtrip->where('trt_id',$card['tripType_id'])->first();
                                                if($card['driver_id']!=0){
                                                $getdriver=$objdriver->where('driver_id',$card['driver_id'])->first();
                                               
                                                }
                                                if($card['supplier_id']!=0){
                                                    $getsupp=$objsubb->where('sup_id',$card['supplier_id'])->first();
                                                    }

                                            ?>
                                            <div class="col-sm-6 col-md-4 col-lg-3">
                                                <div class="job-card-box">
                                                 <?php if($card['assign_dr_supp']==0){ ?>
                                                    <img src="<?=base_url('uploads/no-image.jpg');?>">
                                                    <hr>

                                                    <h3 style="color:#f00;"><?php echo "Not Assigned";?></h3>
                                               <?php  }else{ ?>
                                                <?php if($card['driver_id']!=0){
                                                    if($getdriver['driver_photo']!=''){ ?>
                                                    <img src="<?=base_url('uploads/'.$getdriver['driver_photo']);?>">
                                                    <?php }else{?>
                                                        <img src="<?=base_url('uploads/no-image.jpg');?>">
                                                   <?php } ?>
                                                    <hr>

                                                    <h3><?=$getdriver['driver_name'];?></h3>
                                                <?php } ?>
                                                <?php if($card['supplier_id']!=0){ ?>
                                                    <img src="<?=base_url('uploads/no-image.jpg');?>">
                                                    <hr>
                                                        <h3><?=$getsupp['sup_name'];?></h3>
                                                <?php } } ?>
                                                    <p>Booking id: <?=$card['booking_id'];?></p>
                                                    <p class="text-left w-100 position-rel"><i class="fa fa fa-long-arrow-right" aria-hidden="true" title="From"></i> <span class="text-left"><?=$card['booking_from'];?></span></p>
                                                    <p class="text-left w-100 position-rel"><i class="fa fa fa-long-arrow-left" aria-hidden="true" title="To"></i> <span class="text-left "><?=$card['booking_to'];?></span></p>
                                                    <p class="text-left "><i class="fa fa-clock-o" aria-hidden="true" title="Pickup Time"></i><span class="text-left "><?=$card['booking_time'];?></span></p>
                                                    <p class="text-left "><i class="fa fa-car" aria-hidden="true" title="Vehicle Type"></i><span class="text-left "><?=$getcar['ct_type'];?></span></p>
                                                    <a href="# " data-params="<?=$i;?>" class="dtl-btn">View  Details</a>
                                                </div>
                                            </div>
                                            <div class="view-detail-div" id="viewFull<?=$i?>" >
                                                <h2>View Details <a href="# " data-params="<?=$i;?>" class="dtl-btn close-btn">x</a></h2>

                                                <div class="dtails">
                                                <?php 
                        if(trim($card['booking_amount'])!=''){ ?>
                 <h4 class="text-center text-red"><span><?=$card['booking_from'];?> To <?=$card['booking_to'];?> : <?=$card['booking_amount'];?> AED</span></h4>  
                 <?php } ?>
                <ul>
            <?php
            
        if($card['company_Id']==0){
            $companyName='Regular';
            $obj_reg=new \App\Models\Regular_user();           
            $get_user=$obj_reg->where('user_id',$card['user_id'])->first();
            $done_by=$get_user['reg_name'];
        }else{
            $obj_cadmin=new \App\Models\CorporateAdmin();
            $get_user=$obj_cadmin->where('cadmin_id',$companyid)->first();
            $companyName=$get_user['cadmin_companyName'];
            $obj_cor=new \App\Models\Corporate_user();
            $get_user=$obj_cor->where('user_id',$card['user_id'])->first();
            $done_by= $get_user['cor_name'];
        }
        ?>
                    <li class="text-red">Booking ID: <?=$card['booking_id'];?></li>
                    <li >Done By:<?=$done_by;?> </li>
                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i> <?=$companyName;?></li>                  
                    <?php 
                        if($card['booking_projectCode']!=''){ ?>
                         <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$card['booking_projectCode'];?></li>                   
                    <?php } ?>
                    
                    <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$getcar['ct_type'];?></li>
                    <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$getbook['bt_type'];?></li>
                    <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$gettrip['trt_type'];?></li>
                    <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$card['booking_date'];?></li>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$card['booking_time'];?></li>
                    <?php if(trim($card['booking_return_time'])!=''){?>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$card['booking_return_time'];?></li>
                    <?php } ?>
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$card['booking_from'];?></li>                    
                   
                    <?php if($card['booking_stop']!=''){?>
                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php
                                                            $arr=explode('-*-',$card['booking_stop']);
                                                            echo $imp=implode(",",$arr);
                                                            ?></li>
                    <?php } ?>
                    <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$card['booking_to'];?></li>
                    <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$card['booking_NoPassengers'];?></li>
                    
                     <?php 
                            $obj_passengers=new \App\Models\Passengers();
                            $getPassengers=$obj_passengers->where('booking_id',$card['booking_id'])->findAll();
                            if(sizeof($getPassengers)>0){
                                $n=1;                                    
                            foreach($getPassengers as $get){
                    ?>
                             <li> <i class="fa fa-user"></i>
                            <?php if($get['passenger_name']!='') { 
                                    echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                            } 
                                   if($get['passenger_contact']!=''){
                                    echo $get['passenger_contact'];
                            } 
                        $n++;
                            }
                            }
                            ?> 
                            <li>Driver Note: <?php if($card['driver_note']=='') { 
                                                echo 'Nil';
                                                } else{ 
                                                echo $card['driver_note'];
                                                }?></li>                                                                                               
                            

           </ul>
                                                </div>
                                                <div class="dtails">
                                                <?php if($card['driver_id']!=0){ ?>
                                                    <div class="row">
                                                        <div class="col-12">Driver Details</div>
                                                        <div class="col-lg-4">
                                                        <?php if($getdriver['driver_photo']!=''){ ?>
                                                    <img src="<?=base_url('uploads/'.$getdriver['driver_photo']);?>">
                                                    <?php }else{?>
                                                        <img src="<?=base_url('uploads/no-image.jpg');?>">
                                                   <?php } ?>
                                                            <h3><?=$getdriver['driver_name'];?></h3>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <ul>
                                                            <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$getdriver['driver_nationality'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$getdriver['driver_contact'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$getdriver['driver_email'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$getdriver['driver_address'];?></li>
                                                            
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-4 text-left">
                                                        <p>License Number : <?=$getdriver['driver_license'];?></p>
                                                            <p>License Expiry : <?=$getdriver['driver_license_exp'];?></p>
                                                            <p>Eirates ID : <?=$getdriver['driver_emirates_id'];?></p>
                                                            <p>Eirates ID Expiry : <?=$getdriver['driver_emirates_exp'];?></p>
                                                        </div>

                                                    </div>
                                                    <?php } else{ ?>
                                                <div class="dtails">

                                                    <div class="row">
                                                        <div class="col-12">Supplier Details</div>
                                                        <div class="col-lg-4">
                                                            
                                                            <h3><?=$getsupp['sup_name'];?></h3>
                                                        </div>
                                                        <div class="col-lg-4">
                                                          
                                                        <ul>
                                                               
                                                                <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$getsupp['sup_tel'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$getsupp['sup_email'];?></li>
                                                                
                                                            </ul>
                                                        </div>
                                                        

                                                    </div>
                                                </div>
                                           <?php } ?>
                                                </div>
                                            </div>
                                            <?php 
                                            $i++; 
                                        } ?>
                                            
                                        </div>
                                    </div>
                                    <?php if ($pager) :?>
                <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                <?php $config = $this-> pager_config;
                      $config ['base_url'] = base_url($pagi_path); ?>
                <?php //$pager->setPath(site_url($pagi_path)); ?>
                <?= $pager->links() ?>
                <?php endif ?>
                                    <!-- Page body end -->
                                </div>
                            </div>

                        <?=$this->endSection()?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $('select').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var rows = $('table tr');
    var cancel = rows.filter('#cancel');
    
    if(valueSelected==2){        
        cancel.show();
    }else{
        cancel.hide();
    }
});
$('form').on('submit', function (e) {
  
    var str=$(this).find("[id=reason]").val();
    
    var valueSelected = $(this).find('#status :selected').val();
    
    if(valueSelected==2){
        
        if($.trim(str)==''){ 
            $(this).find("[id=errmsg]").show();                      
            return false;
        }else{
            $(this).find("[id=errmsg]").hide();  
            return true;
        }
       
    }else{
        return true;
    }
});

/*$('[data-dismiss=modal]').on('click', function (e) {
    alert('hi');
    $(this).find('form').trigger('reset');
});*/

$('.modal').on('hidden.bs.modal', function () {
    
    $(this).find("[id=approval]").trigger('reset');
    var valueSelected = $(this).find('#status :selected').val();
    if(valueSelected==2){
        var rows = $('table tr');
        var cancel = rows.filter('#cancel');
        cancel.show();
    }
    });

    $(document).ready(function() {
            

        $(".dtl-btn").click(function() {
            
                var me = $(this);
                var data = me.data('params');                
                var ViewFull='#viewFull'+data;        
                            
                $(ViewFull).toggle('slow');
               
            });
    });

</script>
<?=$this->endSection()?>


   