<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
        <!-- Basic Form Inputs card start -->
            <div class="card">
                <div class="card-header">
                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                    <h5><?=$header;?></h5>
                </div>
                <div class="card-block">
                    <form action="" method="POST">
                    <?php 
                        if(($tripdetails['sadmin_approval']==2)||(($tripdetails['sadmin_approval']==3))){
                    ?>
                    <div class="form-group row">
                            <label class="col-sm-9 col-form-label text-center" style="color: #E74C3C;" >Prominent Reason for cancellation: <?=$tripdetails['sadmin_reason_cancel'];?></label>
                            
                        </div> 
                    <?php } ?>   

                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Car Preference</label>
                            <div class="col-sm-5">
                                <select name="carPreference" id="carPreference" class="form-control" required>
                                    
                                    <?php foreach($carType as $type):
                                    if($tripdetails['carType_id']==$type['ct_id']){
                                    ?>
                                    <option selected value="<?=$type['ct_id'];?>"><?=$type['ct_type'];?></option>
                                    <?php
                                    }else{
                                    ?>
                                    <option value="<?=$type['ct_id'];?>"><?=$type['ct_type'];?></option>
                                    <?php
                                    }
                                    endforeach;?>                                                                       
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Booking Type</label>
                            <div class="col-sm-5">
                                <select name="bookType" id="bookType" class="form-control" required>
                                    
                                    <?php foreach($bookType as $btype):
                                     if($tripdetails['bookType_id']==$btype['bt_id']){
                                    ?>                                   
                                    <option selected value="<?=$btype['bt_id'];?>"><?=$btype['bt_type'];?></option>
                                    <?php }else{
                                    ?>
                                    <option value="<?=$btype['bt_id'];?>"><?=$btype['bt_type'];?></option> 
                                    <?php
                                    }
                                    endforeach;?>                                                                            
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Trip Type</label>
                            <div class="col-sm-5">
                                <div class="btn-group btn-group-vertical" data-toggle="buttons">
                                    <?php 
                                    $i=0;
                                    foreach($tripType as $trip):
                                        if($tripdetails['tripType_id']==$trip['trt_id']):
                                    ?>
                                            <label class="btn active">
                                            <input type="radio" name='trip' id="trip" value="<?=$trip['trt_id'];?>" checked><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i> <span> <?=$trip['trt_type'];?></span>
                                            </label>
                                    <?php   
                                        else:
                                    ?>
                                            <label class="btn">
                                            <input type="radio" name='trip' id='trip' value="<?=$trip['trt_id'];?>" ><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i><span> <?=$trip['trt_type'];?></span>
                                            </label>
                                    <?php
                                        endif;
                                        $i++;
                                    endforeach;
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Select Date</label>
                            <div class="col-sm-5">
                                <i class="ti-calendar date-ic"></i>
                                <input id="datepicker" name="datepicker" class="form-control" value="<?=$tripdetails['booking_date'];?>" placeholder="Select Date" required>                                                                   
                                <label class="text-right" style="color: #BDC3C7;">Date format:yyyy-mm-dd  eg:2022-02-02</label>
                                <label id="errdate" class="text-right" style="color: #E74C3C;display:none;">Date should be greater than today </label>
                            </div>
                        </div>
                       
                        
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Pick up Time</label>
                            <div class="col-sm-2">
                            <?php 
                                $explode=explode(':',$tripdetails['booking_time']);
                            ?>
                            <select id="pickuptimehr" name="pickuptimehr" class="form-control" >
                                
                                <?php for($l=1;$l<25;$l++){ 
                                    $hr = ($l < 10) ? '0'.$l : $l; ?>

                                <option <?php if($explode[0]==$hr){ echo 'selected';}else{ '';}?> value="<?=$hr;?>"><?=$hr;?></option>
                            <?php }?>
                            </select>
                            </div>
                            <div class="col-sm-2">
                            <select id="pickuptimemin" name="pickuptimemin" class="form-control" >
                                <option selected>Minute</option>
                                <?php for($i=00;$i<60;$i++){
                          $min = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option <?php if($explode[1]==$min){ echo 'selected';}else{ '';}?> value="<?=$min;?>"><?=$min;?></option>
                     <?php 
                      }
                      ?>
                            </select>
                            </div>
                            
                        </div>
                       
                        <div class="form-group row" id="return" <?php if($tripdetails['tripType_id']!=2){ ?>style="display: none;" <?php }?>>
                            <label class="col-sm-4 col-form-label text-right">Return Time</label>
                            <div class="col-sm-2">
                            <?php 
                                $explode=explode(':',$tripdetails['booking_return_time']);
                            ?>
                            <select id="returntimehr" name="returntimehr" class="form-control" >
                                
                                <?php for($l=1;$l<25;$l++){ 
                                    $hr = ($l < 10) ? '0'.$l : $l; ?>

                                <option <?php if($explode[0]==$hr){ echo 'selected';}else{ '';}?> value="<?=$hr;?>"><?=$hr;?></option>
                            <?php }?>
                            </select>
                            </div>
                            <div class="col-sm-2">
                            <select id="returntimemin" name="returntimemin" class="form-control" >
                                <option selected>Minute</option>
                                <?php for($i=00;$i<60;$i++){
                          $min = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option <?php if($explode[1]==$min){ echo 'selected';}else{ '';}?> value="<?=$min;?>"><?=$min;?></option>
                     <?php 
                      }
                      ?>
                            </select>
                            </div>
                            
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Select Location</label>
                            <div class="col-sm-2">
                                <input type="text" id="from" name="from" class="form-control" value="<?=$tripdetails['booking_from'];?>" required placeholder="From">
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="to" name="to" class="form-control" placeholder="To" value="<?=$tripdetails['booking_to'];?>" required>
                            </div>                            
                            <div >
                                <button id="add" name="add" class="btn btn-primary btn-sm" type="button" >Add Stop</button>
                                
                            </div>
                        </div>
                        <div class="form-group row" > 
                            <label class="col-sm-4 col-form-label text-right"></label>
                            <div class="col-sm-4">
                                <table id="dynamic_field">
                                <?php 
                                if($tripdetails['booking_stop']!=''){
                                    $arr=explode('-*-',$tripdetails['booking_stop']);
                                    $length=sizeof($arr); 
                                    $l=1;
                                    foreach($arr as $stops){
                                ?>
                                <tr id="row<?=$l;?>">
                                <td><input type="text" name="addmore[]" placeholder="Stop" value="<?=$stops;?>"   /></td><td><button type="button" name="remove" id="<?=$l;?>" class="btn btn-danger btn-sm red-btn">X</button></td>
                                </tr>
                                <?php 
                                    }                                  
                                }else{
                                    $length=0;
                                }
                            ?>
                                
                            </table>
                            <input type="hidden" name="numadstop" id="numadstop" value="<?=$length;?>"/>
                            <input type="hidden" name="numadstopjq" id="numadstopjq" value="<?=$length;?>"/>
                        </div>
                        </div>                                                 
                           
                        
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">No. of Passengers</label>
                            <div class="col-sm-5">
                                <input type="text" id="passengers" required name="passengers" class="form-control" value="<?=$tripdetails['booking_NoPassengers'];?>" placeholder="No. of Passengers">
                               
                            </div>
                        </div>
                        <div class="form-group row" > 
                            <label class="col-sm-4 col-form-label text-right">Passengers Details</label>
                            <div class="col-sm-4"><table id="dynamic_field_passengers">
                            <?php 
                                                    $obj_passengers=new \App\Models\Passengers();
                                                    $getPassengers=$obj_passengers->where('booking_id',$tripdetails['booking_id'])->findAll();
                                                    $lengthpass=sizeof($getPassengers);
                                                    if(sizeof($getPassengers)>0){
                                                    $n=0;                                    
                                                    foreach($getPassengers as $get){
                                                    $ids[]=$get['passenger_id'];
                                                    ?>
                                                    <tr id="rowP<?=$n;?>" >
                                                        <td><input type="hidden" name="passengerID[]"  class="form-control " value="<?=$get['passenger_id'];?>" />
                                                            <input type="text" name="passengerName[]" placeholder="Name" class="form-control " value="<?=$get['passenger_name'];?>"   /></td>
                                                        <td><input type="text" name="passengerContact[]" class="form-control" placeholder="Contact No:" value="<?=$get['passenger_contact'];?>"   /></td>
                                                        <td><button type="button" name="remove" id="<?=$n;?>" class="btn btn-danger1 btn-sm red-btn" >X</button></td>
                                                    </tr>
                                                    <?php
                                                    $n++;
                                                    }
                                                    if($tripdetails['booking_NoPassengers']!=$lengthpass){
                                                        $diff=$tripdetails['booking_NoPassengers']-$lengthpass;
                                                        for($m=$n-1;$m<$diff;$m++){
                                                            ?>
                                                            <tr id="rowP<?=$m;?>" >
                                                           <td><input type="hidden" name="passengerID[]"  class="form-control " value="" />

                                                               <input type="text" name="passengerName[]" placeholder="Name" class="form-control " value=""   /></td>
                                                           <td><input type="text" name="passengerContact[]" class="form-control" placeholder="Contact No:" value=""   /></td>
                                                           <td><button type="button" name="remove" id="<?=$m;?>" class="btn btn-danger1 btn-sm red-btn" >X</button></td>
                                                           </tr>
                                                           <?php   
                                                        }
                                                    }
                                                    }else{
                                                        $len=$tripdetails['booking_NoPassengers'];
                                                        $ids=array();
                                                       for($m=0;$m<$len;$m++){
                                                        ?>
                                                         <tr id="rowP<?=$m;?>" >
                                                        <td><input type="hidden" name="passengerID[]"  class="form-control " value=""  />
                                                            <input type="text" name="passengerName[]" placeholder="Name" class="form-control " value=""   /></td>
                                                        <td><input type="text" name="passengerContact[]" class="form-control" placeholder="Contact No:" value=""   /></td>
                                                        <td><button type="button" name="remove" id="<?=$m;?>" class="btn btn-danger1 btn-sm red-btn" >X</button></td>
                                                        </tr>
                                                        <?php
                                                        }

                                                    }
                            ?>

                                   
                            </table>
                            <?php
                            $ids=implode(",",$ids);
                            ?> 

                            <input type="hidden" name="removeId" id="removeId" value="<?=$ids;?>"/>
                            <input type="hidden" name="numpass" id="numpass" value="<?=$tripdetails['booking_NoPassengers'];?>"/>
                            <input type="hidden" name="numpassjq" id="numpassjq" value="<?=$tripdetails['booking_NoPassengers'];?>"/></div>
                        </div> 
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Driver Note</label>
                            <div class="col-sm-5">
                                <textarea class="form-control" placeholder="Driver note" id="driver_note" name="driver_note" rows="8" ><?=$tripdetails['driver_note'];?></textarea>
                            </div>
                        </div>
                       
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">.</label>
                            <div class="col-sm-5">
                                <button class="btn btn-primary btn-round waves-effect waves-light w-50">Submit</button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
    $(document).ready(function(){      
      var i=parseInt($('#numadstopjq').val());  
   
      $('#add').click(function(){  
           i++; 
           
                    
           $('#numadstop').val(parseInt($('#numadstop').val()) + 1);
           //$('#dynamic_field').append(' <label class="col-sm-4 col-form-label text-right"></label>   <div id="row'+i+'"  ><input type="text" name="addmore[][stop]" class="form-control" placeholder="Stop" required /><button type="button" name="remove" id="'+i+'" >X</button></div>');
           $('#dynamic_field').append('<tr id="row'+i+'" ><td><input type="text" name="addmore[]" placeholder="Stop"   /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn-sm red-btn">X</button></td></tr>');  
      });
  
      $(document).on('click', '.btn-danger', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
           $('#numadstop').val($('#numadstop').val()-1);
      });  

      $(':radio').change(function(){
          var trip_typ=$(this).val();
          if(trip_typ==2){
              $('#return').show();
          }else{
            $('#return').hide();
          }
      })
  
    });  
    $(document).ready(function(){      
      var j=parseInt($('#numpassjq').val());    
   
      $('#passengers').keyup(function(){  
        
           
           var value=$('#passengers').val();
          
          if(value!=''){
              var n=0;
            var rowCount = $('#dynamic_field_passengers tr').length;
              if(rowCount>value){
                var difference=rowCount-value;
                for(var k=0;k<difference;k++){
                    $('#numpass').val(parseInt($('#numpass').val()) - 1);
                    $('#dynamic_field_passengers tr:last').remove();
                    
                  }
                
              }else{
                  var diff=value-rowCount;
                  n=rowCount;
                  for(var l=n;l<value;l++){
                    j++;
                    $('#numpass').val(parseInt($('#numpass').val()) + 1);
                    $('#dynamic_field_passengers').append('<tr id="rowP'+j+'" ><td><input type="hidden" name="passengerID[]"  class="form-control " value=""  /><input type="text" name="passengerName[]" placeholder="Name" class="form-control "   /></td><td><input type="text" name="passengerContact[]" class="form-control" placeholder="Contact No:"   /></td><td><button type="button" name="remove" id="'+j+'" class="btn btn-danger1 btn-sm red-btn" >X</button></td></tr>');  
                
                  }
              }
              
          }
      });

      $(document).on('click', '.btn-danger1', function(){ 
        $('#numpass').val(parseInt($('#numpass').val()) - 1); 
           var button_id = $(this).attr("id");   
           $('#rowP'+button_id+'').remove();  
      });          
  
    }); 
    
    $('form').on('submit', function (e) {
  
  var pickdate=$(this).find("[id=datepicker]").val();
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  var yyyy = today.getFullYear();
  today = yyyy + '-' + mm + '-' + dd;
  if(pickdate>today){
      $(this).find("[id=errdate]").hide();
      return true;
  }else{
      $(this).find("[id=errdate]").show();
      return false;
  }

});
   
</script>
<?= $this->endSection() ?>