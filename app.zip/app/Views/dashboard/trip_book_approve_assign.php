<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
        <!-- Basic Form Inputs card start -->
            <div class="card">
                <div class="card-header">
                <div class="dtails">
                <div class="row m-0">
                        <div class="col-md-9 p-4">                            
                            <ul class="float-left w-30 text-left">
                <!--<?php 
                        if(trim($tripdetails['booking_amount'])!=''){ ?>
                 <h4 class="text-center text-red"><span><?=$tripdetails['booking_from'];?> To <?=$tripdetails['booking_to'];?> : <?=$tripdetails['booking_amount'];?> AED</span></h4>  
                 <?php } ?>-->
                
                    <li class="text-red">Booking ID: <?=$tripdetails['booking_id'];?></li>
                    <li >Done By: <?=$doneBy;?></li>
                    <li><i class="fa fa-address-card" aria-hidden="true" title="Company"></i><?=$companyName;?> </li>                  
                    <?php 
                        if($tripdetails['booking_projectCode']!=''){ ?>
                         <li><i class="fa fa-code" aria-hidden="true" title="Project Code"></i><?=$tripdetails['booking_projectCode'];?></li>                   
                    <?php } ?>
                    
                    <li><i class="fa fa-car" aria-hidden="true" title="Car Type"></i><?=$tripdetails['ct_type'];?></li>
                            </ul>
                            <ul class="float-left w-35 text-left">
                    <li><i class="fa fa-bookmark-o" aria-hidden="true" title="Booking Type"></i><?=$tripdetails['bt_type'];?></li>
                    <li><i class="fa fa-tripadvisor" aria-hidden="true" title="Trip Type"></i> <?=$tripdetails['trt_type'];?></li>
                    <li><i class="fa fa-calendar" aria-hidden="true" title="Date"></i><?=$tripdetails['booking_date'];?></li>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Pick Up Time"></i>Pick Up Time: <?=$tripdetails['booking_time'];?></li>
                    <?php if(trim($tripdetails['booking_return_time'])!=''){?>
                    <li><i class="fa fa-clock-o" aria-hidden="true" title="Return Time"></i>Return Time: <?=$tripdetails['booking_return_time'];?></li>
                    <?php } ?>
                            </ul>
                            <ul class="float-left w-35 text-left"> 
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true" title="Trip Root - From"></i><?=$tripdetails['booking_from'];?></li>                    
                   
                    <?php if($tripdetails['booking_stop']!=''){?>
                    <li><i class="fa fa-stop"" aria-hidden="true" title="Trip Root - To"></i><?php
                                                            $arr=explode('-*-',$tripdetails['booking_stop']);
                                                            echo $imp=implode(",",$arr);
                                                            ?></li>
                    <?php } ?>
                    <li><i class="fa fa-long-arrow-left" aria-hidden="true" title="Trip Root - To"></i><?=$tripdetails['booking_to'];?></li>
                    <li><i class="fa fa-male" aria-hidden="true" title="Passengers"></i><?=$tripdetails['booking_NoPassengers'];?></li>
                            </ul>
                            <ul class="float-left w-35 text-left"> 
                     <?php 
                            $obj_passengers=new \App\Models\Passengers();
                            $getPassengers=$obj_passengers->where('booking_id',$tripdetails['booking_id'])->findAll();
                            if(sizeof($getPassengers)>0){
                                $n=1;                                    
                            foreach($getPassengers as $get){
                    ?>
                             <li> <i class="fa fa-user"></i>
                            <?php if($get['passenger_name']!='') { 
                                    echo $get['passenger_name'].'&nbsp;&nbsp;&nbsp;';
                            } 
                                   if($get['passenger_contact']!=''){
                                    echo $get['passenger_contact'];
                            } 
                        $n++;
                            }
                            }
                            ?> 
                            <li>Driver Note: <?php if($tripdetails['driver_note']=='') { 
                                                echo 'Nil';
                                                } else{ 
                                                echo $tripdetails['driver_note'];
                                                }?></li>  
                                                                                                                       
                            
               <?php 
                            if(($tripdetails['sadmin_approval']==2)||($tripdetails['sadmin_approval']==3)){
                        ?>
                   <li> Reason for cancellation : 
                        <?=$tripdetails['sadmin_reason_cancel'];?></li>
                        <?php } ?>
               
           </ul>
                        </div>
                        <div class="col-md-3 p-4"> 
                        <?php if($tripdetails['sadmin_approval']==0){ ?>
                           
                           <li><a href="#" class="wait-btn" title="Prominent Approval">Pending</a></li>               
               <?php    
                     }else if($tripdetails['sadmin_approval']==1){ ?>
                            <li><a href="#" class="wait-btn" title="Prominent Approval">Confirmed By Prominent</a></li>    
               <?php } else if($tripdetails['sadmin_approval']==2){  ?>
                            <li><a href="#" class="wait-btn" title="Prominent Approval">Cancelled</a></li>  
               <?php } else if($tripdetails['sadmin_approval']==3){  ?>
                   <li><a href="#" class="wait-btn" title="Prominent Approval">Re Send</a></li>  
               <?php } ?>

                   </div>
           <?php if($tripdetails['sadmin_approval']==1){
               
            if($currentdriver != 0){ ?>
            
           <div class="dtails border-0">
           <h3 class="text-left">Driver Details</h3>
           <hr>

                                                    <div class="row">
                                                        <div class="col-12"></div>
                                                        <div class="col-lg-4">
                                                            <?php if($currentdriver['driver_photo']!='') {?>
                                                            <img src="<?=base_url('uploads/'.$currentdriver['driver_photo'])?>" class="img-shadow">
                                                            <?php } ?>
                                                            <h3><?=$currentdriver['driver_name'];?></h3>
                                                        </div>
                                                        <div class="col-lg-4">
                                                          
                                                        <ul>
                                                                <li class="float-none text-left"><i class="fa fa-flag" aria-hidden="true" title="Country"></i><?=$currentdriver['driver_nationality'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i> <?=$currentdriver['driver_contact'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentdriver['driver_email'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-map-marker" aria-hidden="true" title="Address"></i><?=$currentdriver['driver_address'];?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-4 text-left">
                                                            <p>License Number : <?=$currentdriver['driver_license'];?></p>
                                                            <p>License Expiry : <?=$currentdriver['driver_license_exp'];?></p>
                                                            <p>Eirates ID : <?=$currentdriver['driver_emirates_id'];?></p>
                                                            <p>Eirates ID Expiry : <?=$currentdriver['driver_emirates_exp'];?></p>
                                                        </div>

                                                    </div>
                                                </div>
                                            <?php } 
                                            
                                            if($currentsupplier != 0){ ?>
                                            
                                                <div class="dtails border-0">
                                                    <h3 class="text-left">Supplier Details</h5>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-12"></div>
                                                        <div class="col-lg-4">
                                                            
                                                            <h3><?=$currentsupplier['sup_name'];?></h3>
                                                        </div>
                                                        <div class="col-lg-4">                                                          
                                                        <ul>
                                                               
                                                                <li class="float-none text-left"><i class="fa fa-phone" aria-hidden="true" title="Call"></i><?=$currentsupplier['sup_tel'];?></li>
                                                                <li class="float-none text-left"><i class="fa fa-envelope-o" aria-hidden="true" title="Email"></i><?=$currentsupplier['sup_email'];?></li>
                                                                
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-4">  </div>
                                                        

                                                    </div>
                                                </div>
                                           <?php }
                                         } ?>
                                                
            
                </div>
                </div>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                    <h5><?=$header;?></h5>
                
                <div class="card-block">
                    <form action="" method="POST">
                    <div class="dtails p-4">
                    <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">Status</label>
                            <div class="col-sm-5">
                                <select id="status" name="status" class="form-control">
                                <?php if($tripdetails['sadmin_approval']==0) { ?><option value="">Select status</option> <?php } ?>
                                    
                                    <option value="1" <?php if($tripdetails['sadmin_approval']==1){ echo 'selected';} else {echo '';} ?> >Confirm</option>
                                    <option value="2" <?php if($tripdetails['sadmin_approval']==2){ echo 'selected';} else {echo '';} ?> >Cancel</option>
                                    <option value="4" <?php if($tripdetails['sadmin_approval']==4){ echo 'selected';} else {echo '';} ?> >Complete</option>
                                   
                                </select>
                            </div>
                        </div>

                        <div class="form-group row" id="reasondiv" style="<?php if($tripdetails['sadmin_approval']==2){ echo ''; }else{ echo 'display: none;'; } ?>">
                            <label class="col-sm-4 col-form-label text-right">Reason For cancellation</label>
                            <div class="col-sm-5">
                            <input type="text" id="reason" name="reason" class="form-control"  value="<?=$tripdetails['sadmin_reason_cancel'];?>" placeholder="cancellation reason">
                            </div>
                        </div>

                        <div id="completediv" style="<?php if(($tripdetails['sadmin_approval']==4)||($tripdetails['sadmin_approval']==5)){ echo ''; }else{ echo 'display: none;'; } ?>">
                        <div class="form-group row" id="amountdiv" >
                            <label class="col-sm-4 col-form-label text-right">Amount</label>
                            <div class="col-sm-5">                          
                             <input type="text" class="form-control" value="<?=$tripdetails['booking_amount'];?>" name="booking_amount_last" id="booking_amount_last" />
                            </div>
                        </div>
                        <div class="form-group row" id="amountdiv" >
                            <label class="col-sm-4 col-form-label text-right">Remarks</label>
                            <div class="col-sm-5">  
                            <textarea name="booking_remarks" id="booking_remarks" class="form-control"  rows="7"><?=$tripdetails['booking_remarks'];?></textarea>                        
                            
                            </div>
                        </div>
                        <div class="form-group row" id="amountdiv" >
                            <label class="col-sm-4 col-form-label text-right"></label>
                            <div class="col-sm-5">  
                            <?php if(($tripdetails['sadmin_approval']==4)||($tripdetails['sadmin_approval']==5)){ ?>                        
                            <input type="radio" name='paid' id="paid" value="4" <?php if($tripdetails['sadmin_approval']==4){echo "checked";}else{echo '';} ?> > Paid
                            
                            <input type="radio" name='paid' id="paid" value="5" <?php if($tripdetails['sadmin_approval']==5){echo "checked";}else{echo '';} ?>  > Un Paid
                            <?php }else{ ?>
                                <input type="radio" name='paid' id="paid" value="4" checked > Paid
                            
                            <input type="radio" name='paid' id="paid" value="5"  > Un Paid
                            <?php } ?>
                            </div>
                        </div>
                        </div>

                        <div id="assigndiv" style="<?php if($tripdetails['sadmin_approval']==1){ echo ''; }else{ echo 'display: none;'; } ?>">
                        <div class="form-group row" id="amountdiv" >
                            <label class="col-sm-4 col-form-label text-right">Amount</label>
                            <div class="col-sm-5">
                           
                           <input type="text" class="form-control" value="<?=$tripdetails['booking_amount'];?>" name="booking_amount" id="booking_amount" />
                                                       
                            </div>
                        </div>
                        <div class="form-group row"  >
                            <label class="col-sm-4 col-form-label text-right">Assign Driver / Supplier</label>
                            <div class="col-sm-5">
                            
                                <input type="radio" name='assigntype' id="assigntype" value="dr" <?php if($currentdriver != 0){echo "checked";}else{echo '';} ?> > Driver
                            
                                <input type="radio" name='assigntype' id="assigntype" value="sp" <?php if($currentsupplier != 0){echo "checked";}else{echo '';} ?>  > Supplier
                                                       
                            </div>
                        </div>
                       
                        <div class="form-group row" id="driverdiv" style="<?php if($currentdriver != 0){echo '';}else{echo 'display: none;';} ?>">
                            <label class="col-sm-4 col-form-label text-right">Driver</label>
                            <div class="col-sm-5">
                           
                            <select id="driver" name="driver" class="form-control" >
                                    <option value="">Select Driver</option>
                                    <?php if($currentdriver != 0){?>
                                        <option selected value="<?=$currentdriver['driver_id'];?>"><?=$currentdriver['driver_name'];?></option>   
                                    <?php } ?>
                                    <?php foreach($driverslist as $lists){ ?>
                                    <option value="<?=$lists['driver_id'];?>"><?=$lists['driver_name'];?></option>
                                    <?php } ?>
                                </select>
                                                       
                            </div>
                        </div>
                    
                        <div class="form-group row" id="supplierdiv" style="<?php if($currentsupplier != 0){echo '';}else{echo 'display: none;';} ?>">
                            <label class="col-sm-4 col-form-label text-right">Supplier</label>
                            <div class="col-sm-5">
                           
                            <select id="supplier" name="supplier" class="form-control">
                                    <option value="">Select Supplier</option>
                                    <?php if($currentsupplier != 0){?>
                                        <option selected value="<?=$currentsupplier['sup_id'];?>"><?=$currentsupplier['sup_name'];?></option>   
                                    <?php } ?>
                                    <?php foreach($suppliers as $sups){ ?>
                                    <option value="<?=$sups['sup_id'];?>"><?=$sups['sup_name'];?></option>
                                    <?php } ?>
                                </select>                     
                            </div>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-right">.</label>
                            <div class="col-sm-5">
                                <button class="btn btn-primary btn-round waves-effect waves-light w-50">Submit</button>
                            </div>
                        </div>
                    </div>
                    </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?=$this->section('scriptjava')?>
<script type="text/javascript">
     $('#status').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
   
    if(valueSelected==2){        
        $('#reasondiv').show();
        $('#assigndiv').hide();
        $('#completediv').hide();
    }else if(valueSelected==1){
        $('#assigndiv').show();
        $('#reasondiv').hide();
        $('#completediv').hide();
       
    }else{
        $('#assigndiv').hide();
        $('#reasondiv').hide();
        $('#completediv').show();
    }
});

$("input[name='assigntype']").on('click', function (e) {
    var radioValue = $("input[name='assigntype']:checked").val();
    if(radioValue=='dr'){
        $('#driverdiv').show();
        $('#supplierdiv').hide();
    }
    if(radioValue=='sp'){
        $('#driverdiv').hide();
        $('#supplierdiv').show();
    }
});
</script>
<?= $this->endSection() ?>