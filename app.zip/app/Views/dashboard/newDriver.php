
<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?=$this->section('sideMenu')?>
<?= $this->include('layout/sideMenu')?>
<?=$this->endSection()?>
<?=$this->section('pageBody')?>
<div class="page-body">


<div class="row">

    <div class="col-sm-12">

        <!-- Basic Form Inputs card start -->

        <div class="card">

            <div class="card-header">
            <?php
                    if(isset($validation)):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?= isset($validation)?display_errors($validation,'contactNo'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'email'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'licenseNo'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'emiratesId'): '' ?><br/>
                    <?= isset($validation)?display_errors($validation,'photo'): '' ?>
                </span>
                <?php endif;?>
                                        
                <?php
                    if(!empty(session()->getFlashdata('success'))):
                ?>
                <span class="alert alert-result-sucess">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('success')?>
                </span>
                <?php endif;?>

                <?php
                    if(!empty(session()->getFlashdata('fail'))):
                ?>
                <span class="alert alert-result-fail">
                    <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <?= session()->getFlashdata('fail')?>
                </span>
                <?php endif;?>
                <h5><?=$header?> </h5>                
                             
            </div>

            <div class="card-block">
<form  action="" method="POST" enctype="multipart/form-data" >
<?= csrf_field();?>
                <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Name</label>
                 <div class="col-sm-5">
                   <input type="text" name="name" id="name" class="form-control" required="" value="<?=set_value('name');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Email</label>
                 <div class="col-sm-5">
                   <input type="email" name="email" id="email" class="form-control"   value="<?=set_value('email');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Contact Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="contactNo" id="contactNo" class="form-control" required="" value="<?=set_value('contactNo');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">DOB</label>
                 <div class="col-sm-5">
                 <i class="ti-calendar date-ic"></i>
                   <input id="dob" name="dob" class="form-control" required="" value="<?=set_value('dob');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Nationality</label>
                 <div class="col-sm-5">
                   <input type="text" name="nationality" id="nationality" class="form-control"  value="<?=set_value('nationality');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Address In Dubai</label>
                 <div class="col-sm-5">
                   <textarea name="address" id="address" class="form-control" required=""><?=set_value('address');?></textarea>
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Address In India</label>
                 <div class="col-sm-5">
                   <textarea name="addressIndia" id="addressIndia" class="form-control" required=""><?=set_value('addressIndia');?></textarea>
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">License Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="licenseNo" id="licenseNo" class="form-control" required="" value="<?=set_value('licenseNo');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">License Expired Date</label>
                 <div class="col-sm-2">
                  <select name="licenseExpM" id="licenseExpM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="licenseExpY" id="licenseExpY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Emergency Contact Person in UAE</label>
                 <div class="col-sm-5">
                   <input type="text" name="emergency_contact" id="emergency_contact" class="form-control" required="" value="<?=set_value('emergency_contact');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Emergency Contact Person in India</label>
                 <div class="col-sm-5">
                   <input type="text" name="emergency_contactIn" id="emergency_contactIn" class="form-control" required="" value="<?=set_value('emergency_contactIn');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Passport Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="passport_no" id="passport_no" class="form-control" required="" value="<?=set_value('passport_no');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Passport Expiry date</label>
                <div class="col-sm-2">
                  <select name="passport_expM" id="passport_expM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="passport_expY" id="passport_expY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Visa Number</label>
                 <div class="col-sm-5">                     
                   <input type="text" name="visa_no" id="visa_no" class="form-control" required="" value="<?=set_value('visa_no');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Visa Expiry Date</label>
                <div class="col-sm-2">
                  <select name="visa_expM" id="visa_expM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="visa_expY" id="visa_expY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Emirates Id</label>
                 <div class="col-sm-5">
                   <input type="text" name="emiratesId" id="emiratesId" class="form-control" required="" value="<?=set_value('emiratesId');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Emirates Id Expiry Date</label>
                <div class="col-sm-2">
                  <select name="emiratesIdExpM" id="emiratesIdExpM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="emiratesIdExpY" id="emiratesIdExpY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Limousine Permit Number</label>
                 <div class="col-sm-5">
                   <input type="text" name="permit_no" id="permit_no" class="form-control" required="" value="<?=set_value('permit_no');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Limousine Permit Expiry date</label>
                <div class="col-sm-2">
                  <select name="permit_expM" id="permit_expM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="permit_expY" id="permit_expY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Daman Expiry Date</label>
                <div class="col-sm-2">
                  <select name="daman_expM" id="daman_expM" class="form-control" required="">
                      <option value="">Month</option>
                      <?php for($i=01;$i<13;$i++){
                          $month = ($i < 10) ? '0'.$i : $i;
                      ?>
                      <option value="<?=$month;?>"><?=$month;?></option>
                     <?php 
                      }
                      ?>
                  </select>                  
                 </div>
                 <div class="col-sm-2">
                 <select name="daman_expY" id="daman_expY" class="form-control" required="">
                      <option value="">Year</option>
                      <?php
                      $year=date('Y');
                      $endyear=$year+15;
                       for($i=$year;$i<$endyear;$i++){
                          
                      ?>
                      <option value="<?=$i;?>"><?=$i;?></option>
                     <?php 
                      }
                      ?>
                  </select>                   
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Joining date</label>
                 <div class="col-sm-5">
                 <i class="ti-calendar date-ic"></i>
                   <input name="join_date" id="join_date" class="form-control" value="<?=set_value('join_date');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Leave starting date</label>
                 <div class="col-sm-5">
                 <i class="ti-calendar date-ic"></i>
                   <input  name="leave_date" id="leave_date" class="form-control" value="<?=set_value('leave_date');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Leave return date</label>
                 <div class="col-sm-5">
                 <i class="ti-calendar date-ic"></i>
                   <input name="return_date" id="return_date" class="form-control" value="<?=set_value('return_date');?>">
                 </div>
               </div>

         
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Profile Pic</label>
                 <div class="col-sm-5">
                   <input type="file" name="photo" id="photo" class="form-control" >
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">Vehicle Model</label>
                 <div class="col-sm-5">                     
                   <input type="text" name="vehicle_model" id="vehicle_model" class="form-control"  value="<?=set_value('vehicle_model');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right"> Plate Number</label>
                 <div class="col-sm-5">                     
                   <input type="text" name="plate_no" id="plate_no" class="form-control"  value="<?=set_value('plate_no');?>">
                 </div>
               </div>
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">History</label>
                 <div class="col-sm-5">
                   <textarea  name="driver_history" id="driver_history" class="form-control" rows="8" ></textarea>
                 </div>
               </div>
         
               <div class="form-group row">
                <label class="col-sm-4 col-form-label text-right">.</label>
                <div class="col-sm-5">
                    <input type="reset" class="btn btn-primary" value="Reset" />
                    <input type="submit" class="btn btn-primary" value="Save" />
                </div>
               </div>

      
       </form> 

       </div>

</div>

</div>

</div>

</div>  
<?=$this->endSection()?>
          