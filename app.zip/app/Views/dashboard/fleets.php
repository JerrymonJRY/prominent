<?php

use CodeIgniter\Filters\CSRF;
?>

<?= $this->extend('layout/layoutdashboard') ?>
<?= $this->section('sideMenu') ?>
<?= $this->include('layout/sideMenu') ?>
<?= $this->endSection() ?>
<?= $this->section('pageBody') ?>
<div class="page-body">

    <div class="row">

        <div class="col-md-4">

            <input type="text" id="company" onkeyup="searchCompany()" placeholder="Your search text .." title="Type in a search text">

        </div>



    </div>

    <div class="row">

        <div class="col-sm-12">

            <!-- Basic Form Inputs card start -->

            <div class="card">


                <div class="card-header">
                    <?php if (isset($validation)) { ?>
                        <span class="alert alert-result-fail">
                            <button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?= isset($validation) ? display_errors($validation, 'fleet_name') : '' ?>
                        </span>
                    <?php } ?>


                    <?php
                    if (!empty(session()->getFlashdata('success'))) :
                    ?>

                        <span class="alert alert-result-sucess"><button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button><?= session()->getFlashdata('success') ?></span>
                    <?php endif; ?>
                    <?php
                    if (!empty(session()->getFlashdata('fail'))) :
                    ?>

                        <span class="alert alert-result-fail"><button type="button" class="close mt-0" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button><?= session()->getFlashdata('fail') ?></span>
                    <?php endif; ?>
                    <h5><?= $header ?></h5>


                    <a href="#" title="Add" class="btn btn-primary btn-sm" style="float: right;" data-toggle="modal" data-target="#exampleModal">Add New</a>

                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">New Fleet</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>

                                    <div class="modal-body">
                                        <label>Fleet Name</label>
                                        <span><input type="text" required="" id="fleet_name" name="fleet_name" class="form-control" placeholder="Fleet Name"></span>
                                        <label>Thumbnail Image</label>
                                        <input type="file" class="form-control" name="thumb_image">
                                        <label>Background Image</label>
                                        <input type="file" class="form-control" name="back_image">
                                        <label>Specifications</label>
                                        <textarea class="form-control" name="spec"></textarea>
                                        <label>Features</label>
                                        <textarea class="form-control" name="features"></textarea>
                                        <label>Description</label>
                                        <textarea class="form-control" name="desc"></textarea>
                                        <label>Why Choose?</label>
                                        <textarea class="form-control" name="Whychoose"></textarea>
                                        <label>Category</label>
                                        <div>
                                            <select name="type" class="form-control">
                                                <?php
                                                foreach ($types as $row) {
                                                ?>

                                                    <option value="<?= $row['ct_id'] ?>"><?= $row['ct_type'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <label>Starting Price(AED)</label>
                                        <input type="number" class="form-control" name="price" step="0.01">
                                        <label>Gallery Images</label>
                                        <input type="file" class="form-control" name="images[]" multiple="multiple" />
                                    </div>
                                    <div class="modal-footer">
                                        <input type="reset" class="btn btn-primary" value="Reset" />
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <input type="submit" class="btn btn-primary" value="Save" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>

                <div class="card-block">

                    <div class="table-responsive">



                        <table id="fleetstable" class="table table-striped table-bordered" style="width:100%">

                            <thead>

                                <tr>
                                    <th>Sl No</th>
                                    <th>Fleet Name</th>
                                    <th>Edit/Delete</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                $i = 1;

                                foreach ($details as $det) :
                                ?>

                                    <tr>

                                        <td><?= $i; ?></td>

                                        <td><?= ucfirst($det['Name']) ?></td>
                                        <td>

                                            <a href="" title="Edit" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal<?= $i ?>">
                                                <i class="fa fa-pencil fa-2x mr-0" aria-hidden="true"></i>
                                            </a>

                                            <div class="modal fade" id="exampleModal<?= $i ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-xl" role="document">
                                                    <form action="<?= base_url('FleetMng/edit/' . $det['Id']) ?>" method="POST" enctype="multipart/form-data">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Update Fleet</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <label> Update Fleet</label>
                                                                <span><input type="text" required="" id="fleet_name" name="fleet_name" class="form-control" placeholder="Fleet Name" value="<?= $det['Name'] ?>"></span>
                                                                <label>Thumbnail Image</label>
                                                                <input type="file" class="form-control" name="thumb_image">
                                                                <img src="../uploads/<?= $det['Thumbnail'] ?>" height="50%" width="30%">
                                                                <input class="form-control" type="hidden" name="oldthumb" value="<?= $det['Thumbnail'] ?>"><?php echo $det['Thumbnail'] ?></span>
                                                                <div>
                                                                    <label>Background Image</label>
                                                                    <input type="file" class="form-control" name="back_image">
                                                                    <img src="../uploads/<?= $det['Background'] ?>" height="50%" width="30%">
                                                                    <input class="form-control" type="hidden" name="oldbackground" value="<?= $det['Background'] ?>"><?php echo $det['Background'] ?></span>
                                                                </div>
                                                                <div>
                                                                    <label>Specifications</label>
                                                                    <?php $spec = json_decode($det['Specifications']);
                                                                    ?>

                                                                    <textarea class="form-control" name="spec"><?php echo implode("\n", $spec); ?></textarea>
                                                                </div>

                                                                <label>Features</label>
                                                                <textarea class="form-control" name="features"><?php echo implode("\n", json_decode($det['Features'])); ?></textarea>
                                                                <label>Description</label>
                                                                <textarea class="form-control" name="desc"><?php echo $det['Description'] ?></textarea>
                                                                <label>Why Choose?</label>
                                                                <textarea class="form-control" name="Whychoose"><?php echo $det['Whychoose'] ?></textarea>
                                                                <label>Category</label>
                                                                <div>
                                                                    <select name="type" class="form-control">
                                                                        <?php
                                                                        foreach ($types as $row) {
                                                                        ?>

                                                                            <option value="<?= $row['ct_id'] ?>" <?php if ($det['Type'] == $row['ct_id']) echo "selected" ?>><?= $row['ct_type'] ?></option>
                                                                        <?php } ?>
                                                                    </select>
                                                                </div>
                                                                <label>Starting Price(AED)</label>
                                                                <input type="number" class="form-control" name="price" value="<?= $det['starting_price'] ?>" step="0.01">
                                                                <label>Gallery Images</label>
                                                                <input type="file" class="form-control" name="images[]" multiple="multiple" />
                                                                <?php
                                                                $gallery = json_decode($det['GalleryImages']);

                                                                foreach ($gallery as $image) { ?>
                                                                    <div>
                                                                        <img src="../uploads/<?= $image ?>" height="50%" width="30%">
                                                                        <span><?php echo $image ?></span>
                                                                    </div>

                                                                <?php }
                                                                ?>
                                                                <textarea class="form-control" name="oldimages" hidden><?php echo implode("\n", $gallery); ?></textarea>
                                                                <!-- <input class="form-control"   name="oldimages" value="<?php print_r($gallery); ?>"> -->
                                                            </div>
                                                            <div class="modal-footer">

                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <input type="submit" class="btn btn-primary" value="Save" />
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>

                                            <a href="" title="Delete" class="btn btn-danger btn-sm red-btn" data-toggle="modal" data-target="#exampleModalDelete<?= $i ?>">
                                                <i class="fa fa-trash fa-2x mr-0" aria-hidden="true"></i>
                                            </a>

                                            <div class="modal fade" id="exampleModalDelete<?= $i ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <form action="<?= base_url('FleetMng/delete/' . $det['Id']) ?>" method="POST">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation !!</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <label> Confirm</label>
                                                                <span>Are you sure to delete "<?= $det['Name'] ?>" ?</span>
                                                            </div>
                                                            <div class="modal-footer">

                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <input type="submit" class="btn btn-primary" value="OK" />
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>

                                        </td>

                                    </tr>
                                <?php
                                    $i++;
                                endforeach;
                                ?>
                            </tbody>

                        </table>

                    </div>
                    <?php if ($pager) :?>
                <?php $pagi_path='/booking/viewCorporateBooking/'.$cat?>
                <?php $config = $this-> pager_config;
                      $config ['base_url'] = base_url($pagi_path); ?>
                <?php //$pager->setPath(site_url($pagi_path)); ?>
                <?= $pager->links() ?>
                <?php endif ?>
                </div>

            </div>

        </div>

    </div>
    <?= $this->endSection() ?>