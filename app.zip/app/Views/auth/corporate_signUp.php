<?php

use CodeIgniter\Filters\CSRF;
?>
<?= $this->extend('layout/layoutAuth') ?>
<?= $this->section('content') ?>
    <section class="login-block">
        <!-- Container-fluid starts -->
        <div class="container v-center">
            <div class="row">
                <!-- <div class="col-sm-6 login-car sm-d-none">
                </div> -->
                <div class="col-sm-12 card m-b-0">
                    <!-- Authentication card start -->
                    
                    <form class="md-float-material form-material" method="POST" action="" >
                        <?= csrf_field();?>
                        <div class="text-center pt-3">
                            <img src="<?php echo base_url('assets/images/logo.png');?>" alt="logo.png">
                        </div>
                        <div class="auth-box">
                            <div class="card-block">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-center">Corporate Sign up</h3>
                                    </div>
                                </div>
                               
                                <div class="form-group form-primary">
                                    <input type="text" name="fullname" id="fullname" class="form-control" value="<?=set_value('fullname');?>"   required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Full name</label>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="text" name="email" id="email" class="form-control" value="<?=set_value('email');?>"   required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Email</label>
                                </div>
                                 <div class="form-group row">
                                    <div class="col-6 col-sm-5">
                                       <?php
                                        $objcountry=new \App\Models\Countries();  
                                        $getCountry=$objcountry->findAll();                                        
                                        ?>
                                     <select name="contactCode" id="contactCode" class="form-control " style="border: none;outline: none;" required>
                                         <option value=''>Country Code</option>
                                         <?php foreach($getCountry as $getc): ?>
                                            <option value='<?='+'.$getc['phone_code'];?>'><?=$getc['country_name'].'('.$getc['country_code'].')'.' +'.$getc['phone_code'];?></option>
                                        <?php endforeach;?>

                                     </select>
                                    <span class="form-bar"></span>
                                    <!--<label class="float-label" style="left: 21px;">Contry Code</label>-->
                                    </div>
                                    <div class="col-6 col-sm-7">
                                    <input type="text" name="contact" id="contact" class="form-control " value="<?=set_value('contact');?>"  required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Contact Number</label>
                                </div>
                                </div>
                               
                               
                                <div class="form-group form-primary">
                                    <input type="text" name="company_code" id="company_code" class="form-control" value="<?=set_value('company_code');?>"  required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Company Code</label>
                                </div>
                                
                                <div class="form-group form-primary">
                                    <input type="text" name="employee_id" id="employee_id" class="form-control" value="<?=set_value('employee_id');?>"  required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Employee ID</label>
                                </div>

                                <div class="form-group form-primary">
                                    <input  type="password" name="password" id="password" class="form-control" required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Password</label>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="password" name="cpassword" id="cpassword" class="form-control" required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Confirm Password</label>
                                </div>
                                <span class="text-danger"><?= isset($validation)?display_errors($validation,'cpassword'): '' ?></span></br>
                                <span class="text-danger"><?= isset($validation)?display_errors($validation,'email'): '' ?></span></br>
                                <span class="text-danger"><?= isset($validation)?display_errors($validation,'company_code'): '' ?></span>
                                <?php
                                    if(!empty(session()->getFlashdata('result'))):
                                ?>
                                    <span class="text-danger"><?= session()->getFlashdata('result')?></span>
                                <?php endif;?>
                                <div class="row m-t-30">
                                    <div class="col-sm-6">
                                        <button type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20">SignUp</button>
                                    </div>
                                    <div class="col-sm-6">
                                      <a href="<?=base_url();?>" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20"> Login</a>                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- end of form -->
                </div>
                <!-- end of col-sm-12 -->
            </div>
            <!-- end of row -->
        </div>
        <!-- end of container-fluid -->
    </section>
    <?= $this->endSection() ?>
  
   