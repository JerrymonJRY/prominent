<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use App\Models\CorporateAdmin;
use App\Models\Corporate_user;
use App\Models\Regular_user;

class AuthcheckFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if(!session()->has('loggeduser')){
            if(!empty($_GET['type'])){
                $type=$_GET['type'];
                return redirect()->to(base_url().'/?type='.$type)->with('result','You must logged in !!');
            }
            else{
                return redirect()->to(base_url())->with('result','You must logged in !!');
            }
        }else{
            
            if(session()->get('loggeduserstatus')==1){
                session()->set('name','Super Admin'); 
            }else if(session()->get('loggeduserstatus')==2){
                $obj_corAdmin=new CorporateAdmin();
                $getCorAdmin=$obj_corAdmin->where('user_id',session()->get('loggeduser'))->first();
                session()->set('companyId',$getCorAdmin['cadmin_id']); 
                session()->set('name',$getCorAdmin['cadmin_companyName']); 
            }else if(session()->get('loggeduserstatus')==3){
                $obj_regUser=new Regular_user();
                $getCorUser=$obj_regUser->where('user_id',session()->get('loggeduser'))->first();
                session()->set('name',$getCorUser['reg_name']);
            }else{
                $obj_corUser=new Corporate_user();
                $getCorUser=$obj_corUser->where('user_id',session()->get('loggeduser'))->first();
                session()->set('name',$getCorUser['cor_name']);
                session()->set('companyId',$getCorUser['cor_companyID']);  
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}