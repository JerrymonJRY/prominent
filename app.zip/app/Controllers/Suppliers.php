<?php

namespace App\Controllers;
use App\Models\Supplier;

class Suppliers extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        
       $userArray=$this->show();
       $obj_supplier=new Supplier();
       $supplierDetails=$obj_supplier->orderby('sup_id','DESC')->paginate(20);

        $data=[
            'active'=>'supplier',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Suppliers Details',
            'details'=>$supplierDetails
        ];
        $data['pager']=$obj_supplier->orderby('sup_id','DESC')->pager;
        return view('dashboard/suppliers', $data);
        
    }

    

   public function addNew()
    {
        $userArray=$this->show();
        $data=[
             'active'=>'supplier',
             'userID'=>$userArray['user_id'],
             'status'=>$userArray['status'],
             'header'=>'New Supplier Details'
            
         ];
         if($_POST):
            
            $validation = $this->validate([
                
                'email'=> [
                    'rules'=>'is_unique[supplier.sup_email]',
                    'errors'=>[
                               'is_unique'=>'Email already exist..please try another...'
                             ],
                    ],
                'contactNo'=>[
                    'rules'=>'is_unique[supplier.sup_tel]',
                    'errors'=>[
                            'is_unique'=>'Contact Number already exist...!!'
                     ],
                    ]                
                
                ]);
               
                if (!$validation){
                    
                    $data['validation']=$this->validator;
                    return view('dashboard/newSupplier',$data);
                }else{
                    $name=$this->request->getPost('name');
                    $email=$this->request->getPost('email');
                    $contact=$this->request->getPost('contactNo');

                    $reserve_contact=$this->request->getPost('reserve_contactNo');
                    $reserve_email=$this->request->getPost('reserve_email');

                    $acc_contact=$this->request->getPost('acc_contactNo');
                    $acc_email=$this->request->getPost('acc_email');

                    $bank_acc=$this->request->getPost('bank_acc');

                    $date=date('Y-m-d');
                    $values=[    'sup_name'=>$name,
                                  'sup_email'=>$email,
                                  'sup_tel'=>$contact,                                  
                                  'sup_created_date'=>$date,
                                  'sup_updated_date'=>$date,
                                  'sup_reservation_contact'=>$reserve_contact,
                                  'sup_reservation_email'=>$reserve_email,
                                  'sup_acc_email'=>$acc_email,
                                  'sup_acc_contact'=>$acc_contact,
                                  'sup_bank_acc'=>$bank_acc];
                    
                    $sup_obj= new Supplier();                         
                        
                        $query_insert=$sup_obj->insert($values);
                        if($query_insert){
                            return redirect()->to(base_url('suppliers'))->with('success','New supplier Details Saved');
                        }else{
                            return redirect()->to(base_url('suppliers'))->with('fail','Adding new supplier deatils is failed');
                        }
                }
    
            else:
                    return view('dashboard/newSupplier',$data);
            endif;
    }

    

    public function edit($suppID)
    {
        
        if($_POST){
            
            $validation = $this->validate([
                
                'email'=> [
                    'rules'=>'is_unique[supplier.sup_email,supplier.sup_id,'.$suppID.']',
                    'errors'=>[
                               'is_unique'=>'Updated Email already exist..please try another...'
                             ],
                    ],
                'contactNo'=>[
                    'rules'=>'is_unique[supplier.sup_tel,supplier.sup_id,'.$suppID.']',
                    'errors'=>[
                            'is_unique'=>'Updated Contact Number already exist...!!'
                     ],
                ],
                                
                ]);
               
                if (!$validation){
                   
                    return redirect()->back()->withInput()->with('result', $this->validator->getErrors()); 
                }else{
                    $name=$this->request->getPost('name');
                    $email=$this->request->getPost('email');
                    $contact=$this->request->getPost('contactNo');
                    $reserve_contact=$this->request->getPost('reserve_contactNo');
                    $reserve_email=$this->request->getPost('reserve_email');

                    $acc_contact=$this->request->getPost('acc_contactNo');
                    $acc_email=$this->request->getPost('acc_email');

                    $bank_acc=$this->request->getPost('bank_acc');

                    $date=date('Y-m-d');
                    $sub_obj= new Supplier();
                    $values=['sup_name'=>$name,
                             'sup_email'=>$email,
                             'sup_tel'=>$contact,
                             'sup_updated_date'=>$date,
                             'sup_reservation_contact'=>$reserve_contact,
                             'sup_reservation_email'=>$reserve_email,
                             'sup_acc_email'=>$acc_email,
                             'sup_acc_contact'=>$acc_contact,
                             'sup_bank_acc'=>$bank_acc];
                    
                                                     
                    $update_query=$sub_obj->update($suppID,$values);
                    if(!$update_query){
                        return redirect()->to(base_url('suppliers'))->with('fail','Updation failed');
                    }else{
                        return redirect()->to(base_url('suppliers'))->with('success','Successfully updated !!!');
                    }
                }

        }else{
                $userArray=$this->show();     
                $sup_obj= new Supplier();
                $getSup_info=$sup_obj->where('sup_id',$suppID)->first();
                $data=[
                    'active'=>'supplier',
                    'userID'=>$userArray['user_id'],
                    'status'=>$userArray['status'],
                    'header'=>'Update Supplier Details',
                    'supInfo'=>$getSup_info            
                 ];
                 return view('dashboard/editSupplier',$data);
        }
    }

    public function delete($supID)
    {
        $supInfo = new Supplier();
        $query_del=$supInfo->where('sup_id', $supID)->delete();
       if($query_del){
            return redirect()->to(base_url('suppliers'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('suppliers'))->with('fail','Deletion failed!!');
        }
       
    }

   
}
?>