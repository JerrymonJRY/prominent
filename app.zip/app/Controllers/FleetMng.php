<?php

namespace App\Controllers;

use App\Models\CarPreference;
use App\Models\Fleet;

class FleetMng extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id'] = session()->get('loggeduser');
        $user['status'] = session()->get('loggeduserstatus');
        return $user;
    }
    public function index()
    {

        $userArray = $this->show();
        $obj_fleet = new Fleet();
        $obj_type = new CarPreference();
        $getfleets = $obj_fleet->join('cartype', 'cartype.ct_id=Type')->orderby('Id', 'DESC')->paginate(20);
        $types = $obj_type->findAll();

        $data = [
            'active' => 'fleet',
            'userID' => $userArray['user_id'],
            'status' => $userArray['status'],
            'header' => 'Fleets',
            'details' => $getfleets,
            'types' => $types
        ];
        $data['pager'] = $obj_fleet->join('cartype', 'cartype.ct_id=Type')->orderby('Id', 'DESC')->pager;

        if ($_POST) :
            $validation = $this->validate([
                'fleet_name' => [
                    'rules' => 'required|is_unique[fleet.Name]',
                    'errors' => [
                        'required' => 'You must enter fleet name',
                        'is_unique' => 'fleet name already exist..'
                    ],
                ],
            ]);
            if (!$validation) {
                $data['validation'] = $this->validator;
                return view('dashboard/fleets', $data);
            } else {
                $fleet_name = $this->request->getPost('fleet_name');

                $thumb = $_FILES['thumb_image'];
                print_r($thumb);
                $thumb_loc = $_FILES['thumb_image']['tmp_name'];
                $thumb_name = $_FILES['thumb_image']['name'];
                //$thumb_des = "uploads/" . $thumb_name;
                move_uploaded_file($thumb_loc, $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $thumb_name);

                $background = $_FILES['back_image'];
                $background_loc = $_FILES['back_image']['tmp_name'];
                $background_name = $_FILES['back_image']['name'];
                //$background_des = "uploads/" . $background_name;
                move_uploaded_file($background_loc, $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $background_name);

                $spec = $this->request->getPost('spec');
                $spec_array = preg_split("/\r\n|\n|\r/", $spec);
                $spec_array = json_encode($spec_array);

                $features = $this->request->getPost('features');
                $features_array = preg_split("/\r\n|\n|\r/", $features);
                $features_array = json_encode($features_array);

                $desc = $this->request->getPost('desc');

                $Whychoose = $this->request->getPost('Whychoose');

                $type = $this->request->getPost('type');
                $price = $this->request->getPost('price');

                $error = array();
                $images = array();
                $extension = array("jpeg", "jpg", "png", "gif");


                if (is_array($_FILES['images']['tmp_name'])) {
                    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                        $file_name = $_FILES['images']['name'][$key];
                        $file_tmp = $_FILES['images']['tmp_name'][$key];
                        $ext = pathinfo($file_name, PATHINFO_EXTENSION);

                        if (in_array($ext, $extension)) {
                            if (!file_exists($_SERVER['DOCUMENT_ROOT'].'/uploads/' . $file_name)) {
                                move_uploaded_file($file_tmp = $_FILES["images"]["tmp_name"][$key], $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $file_name);
                                array_push($images, $file_name);
                            } else {
                                $filename = basename($file_name, $ext);
                                $newFileName = $filename . time() . "." . $ext;
                                move_uploaded_file($file_tmp = $_FILES["images"]["tmp_name"][$key], $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $newFileName);
                                array_push($images, $newFileName);
                            }
                        } else {
                            array_push($error, "$file_name, ");
                        }
                    }
                }

                $images = json_encode($images);

                $date = date('Y-m-d');
                $values = [
                    'Name' => $fleet_name,
                    'Thumbnail' => $thumb_name,
                    'Background' => $background_name,
                    'Specifications' => $spec_array,
                    'Features' => $features_array,
                    'Description' => $desc,
                    'Whychoose' => $Whychoose,
                    'Type' => $type,
                    'starting_price'=>$price,
                    'GalleryImages' => $images,
                    'created_date' => $date,
                    'last_updated' => $date
                ];
                $insert_obj = new Fleet();
                $query_insert = $insert_obj->insert($values);
                if (!$query_insert) {
                    return redirect()->to(base_url('FleetMng'))->with('fail', 'Adding new fleet is failed!!');
                } else {
                    return redirect()->to(base_url('FleetMng'))->with('success', 'Successfully added new fleet!!');
                }
            }
        else :
            return view('dashboard/fleets', $data);
        endif;
    }

    public function edit($fleetID)
    {
        $validation = $this->validate([
            'fleet_name' => [
                'rules' => 'required|is_unique[fleet.Name,fleet.Id,' . $fleetID . ']',
                'errors' => [
                    'required' => 'You must enter fleet name',
                    'is_unique' => 'fleet name already exist..'
                ],
            ],
        ]);
        if (!$validation) {
            $userArray = $this->show();
            $fleet_obj = new Fleet();
            $fleetDetails = $fleet_obj->findAll();
            $data = [
                'active' => 'fleet',
                'userID' => $userArray['user_id'],
                'status' => $userArray['status'],
                'header' => 'Fleets',
                'details' => $fleetDetails
            ];
            $data['validation'] = $this->validator;
            return view('dashboard/fleets', $data);
        } else {
            $fleet_name = $this->request->getPost('fleet_name');

            $thumb = $_FILES['thumb_image'];
            $thumbold = $this->request->getPost('oldthumb');
            $thumbfile = $_FILES['thumb_image']['name'];
            if ($thumbfile != "") {
                $thumb_loc = $_FILES['thumb_image']['tmp_name'];
                $thumb_name = $_FILES['thumb_image']['name'];
                move_uploaded_file($thumb_loc, $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $thumb_name);
            } else {
                $thumb_name = $thumbold;
            }

            $background = $_FILES['back_image'];
            $backold = $this->request->getPost('oldbackground');
            $backfile = $_FILES['back_image']['name'];
            if ($backfile != "") {
                $background_loc = $_FILES['back_image']['tmp_name'];
                $background_name = $_FILES['back_image']['name'];
                move_uploaded_file($background_loc,$_SERVER['DOCUMENT_ROOT'].'/uploads/' . $background_name);
            } else {
                $background_name = $backold;
            }




            $spec = $this->request->getPost('spec');
            $spec_array = preg_split("/\r\n|\n|\r/", $spec);
            $spec_array = json_encode($spec_array);

            $features = $this->request->getPost('features');
            $features_array = preg_split("/\r\n|\n|\r/", $features);
            $features_array = json_encode($features_array);

            $desc = $this->request->getPost('desc');

            $Whychoose = $this->request->getPost('Whychoose');

            $type = $this->request->getPost('type');
            $price=$this->request->getPost('price');

            $error = array();
            $images = array();
            $extension = array("jpeg", "jpg", "png", "gif");


            if (is_array($_FILES['images']['tmp_name'])) {
               $flag=0;

                foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                  
                    if ($_FILES['images']['name'][0] != "") {
                       
                        $file_name = $_FILES['images']['name'][$key];
                        $file_tmp = $_FILES['images']['tmp_name'][$key];
                        $ext = pathinfo($file_name, PATHINFO_EXTENSION);
    
                        if (in_array($ext, $extension)) {
                            //if (!file_exists("C:/xampp/htdocs/prominentlimo.com/uploads/" . $file_name)) {
                                move_uploaded_file($file_tmp = $_FILES["images"]["tmp_name"][$key], $_SERVER['DOCUMENT_ROOT'].'/uploads/' . $file_name);
                                array_push($images, $file_name);
                            //} 
                            // else {
                            //     $filename = basename($file_name, $ext);
                            //     $newFileName = $filename . time() . "." . $ext;
                            //     move_uploaded_file($file_tmp = $_FILES["images"]["tmp_name"][$key], "C:/xampp/htdocs/prominentlimo.com/uploads/" . $newFileName);
                            //     array_push($images, $newFileName);
                            // }
                        } else {
                            array_push($error, "$file_name, ");
                        }
                    }
                    else{
                        $img = $this->request->getPost('oldimages');
                        $img_array = preg_split("/\r\n|\n|\r/", $img);
                        $images = json_encode($img_array);
                        global $flag;
                        $flag=1;
                       
                        break;
                    }
                   
                }
            } 
            if($flag==0){
                $images = json_encode($images);
            }
           
           
            
            $date = date('Y-m-d');
            $values = [
                'Name' => $fleet_name,
                'Thumbnail' => $thumb_name,
                'Background' => $background_name,
                'Specifications' => $spec_array,
                'Features' => $features_array,
                'Description' => $desc,
                'Whychoose' => $Whychoose,
                'Type' => $type,
                'starting_price'=>$price,
                'GalleryImages' => $images,
                'last_updated' => $date
            ];
            $update_obj = new Fleet();
            $query_update = $update_obj->update($fleetID, $values);
            if (!$query_update) {
                return redirect()->to(base_url('FleetMng'))->with('fail', 'Updating  fleet is failed!!');
            } else {
                return redirect()->to(base_url('FleetMng'))->with('success', 'Successfully updated  fleet!!');
            }
        }
    }

    public function delete($fleetID)
    {
        $delete_obj = new Fleet();
        $query_del = $delete_obj->where('Id', $fleetID)->delete();
        if (!$query_del) {
            return redirect()->to(base_url('FleetMng'))->with('fail', 'Deleting fleet is failed');
        } else {
            return redirect()->to(base_url('FleetMng'))->with('success', 'Successfully deleted');
        }
    }
}
