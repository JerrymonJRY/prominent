<?php

namespace App\Controllers;
use App\Models\Regular_user;
use App\Models\User;

class Regular_registrations extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        
       $userArray=$this->show();
       $obj_regular=new Regular_user();
       $regularUser=$obj_regular->join('users','regular_user.user_id=users.user_id')->paginate(20);

        $data=[
            'active'=>'customer',
            'sub'=>'regular',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Regular Users Details',
            'details'=>$regularUser
        ];
        $data['pager']=$obj_regular->join('users','regular_user.user_id=users.user_id')->pager;
        return view('dashboard/regularUsers', $data);
        
    }

    public function delete($regUserID)
    {
        $userInfo = new User();
        $obj_regular= new Regular_user();
        $query_del=$userInfo->where('user_id', $regUserID)->delete();
        if($query_del){
                $obj_regular->where('user_id', $regUserID)->delete();
                return redirect()->to(base_url('regular_registrations'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('regular_registrations'))->with('fail','Deletion failed!!');
        }
    }
}
?>