<?php

namespace App\Controllers;
use App\Models\CorporateAdmin;
use App\Models\User;
class CorporateAdminMng extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        
       $userArray=$this->show();
       $obj_corAdmin=new CorporateAdmin();
       $corAdminDeatils=$obj_corAdmin->join('users','corporate_admin.user_id=users.user_id')->orderby('corporate_admin.user_id','DESC')->paginate(20);
              
        $data=[
            'active'=>'corporateAdmin',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Corporate Admins',
            'details'=>$corAdminDeatils
        ];
        $data['pager'] =$obj_corAdmin->join('users','corporate_admin.user_id=users.user_id')->orderby('corporate_admin.user_id','DESC')->pager;
        return view('dashboard/corporateAdmin', $data);
        
    }

    

    public function addNew()
    {
        $userArray=$this->show();
        $data=[
             'active'=>'corporateAdmin',
             'userID'=>$userArray['user_id'],
             'status'=>$userArray['status'],
             'header'=>'New Corporate Admins'
            
         ];
         if($_POST):
            $validation = $this->validate([
                'companyName'=>[
                    'rules'=>'required',
                    'errors'=>[
                        'required'=>'You must enter company name'
                        
                    ],
                ],
                'email'=> [
                    'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_email]',
                    'errors'=>[
                                'required'=>'You must enter the email',
                                'valid_email'=>'You must enter a valid email',
                                'is_unique'=>'Email  exist..please try another...'
                             ],
                    ],
                'trade_lno'=> [
                    'rules'=>'required|is_unique[corporate_admin.cadmin_tradeLNo]',
                    'errors'=>[
                                'required'=>'You must enter the trade License Number',
                                'is_unique'=>'Trade License number  exist..please try another...'
                            ],
                ],
                'adm_email'=> [
                    'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_adm_email]',
                    'errors'=>[
                                'required'=>'You must enter the email',
                                'valid_email'=>'You must enter a valid email',
                                'is_unique'=>'Administration Email  exist..please try another...'
                             ],
                    ],
                'acc_email'=> [
                    'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_acc_email]',
                    'errors'=>[
                                'required'=>'You must enter the email',
                                'valid_email'=>'You must enter a valid email',
                                'is_unique'=>'Accountant Email  exist..please try another...'
                             ],
                    ],
                'username'=> [
                    'rules'=>'required|valid_email|is_unique[users.user_username]',
                    'errors'=>[
                                'required'=>'You must enter the Username',
                                'valid_email'=>'You must enter the valid username',
                                    'is_unique'=>'Username  exist..please try another...'
                                 ],
                        ],
                'companycode'=>[
                    'rules'=>'required|is_unique[corporate_admin.cadmin_companyCode]',
                    'errors'=>[
                        'required'=>'You must enter the company code',                       
                        'is_unique'=>'Company Code  exist... please use another code!!'
                     ],
                ],
                
                ]);
                
                if (!$validation){
                   $data['validation']=$this->validator;
                    return view('dashboard/newCorporateAdmin',$data);
                }else{
                    $name=$this->request->getPost('companyName');
                    $email=$this->request->getPost('email');
                    $contact=$this->request->getPost('contactNo');
                    $contactPerson=$this->request->getPost('contactPerson');                    
                    $address=$this->request->getPost('address');
                    $companycode=$this->request->getPost('companycode');
                    $trade_lno=$this->request->getPost('trade_lno');
                    $vat_no=$this->request->getPost('vat_no');
                    $vat_no=$this->request->getPost('vat_no');
                    $adm_email=$this->request->getPost('adm_email');
                    $adm_no=$this->request->getPost('adm_no');
                    $acc_email=$this->request->getPost('acc_email');
                    $acc_no=$this->request->getPost('acc_no');
                    $password=$this->request->getPost('password');
                    $username=$this->request->getPost('username');
                    $status='2';
                    $role='Corporate Admin';
                    $active='1';
                    $date=date('Y-m-d');
                    $data=[                        
                             'user_username'=>$username,
                             'user_password'=>$password,
                             'user_status'=>$status,
                             'user_role'=>$role,
                             'user_active'=>$active,
                             'user_created_date'=>$date,
                             'user_updated_date'=>$date
                            ];
                   
                            try {
                                $user= new User();
                                $query=$user->insert($data);
                                $insert_id=$user->getInsertID();                            
                            } catch (\Exception $e) {
                                 die($e->getMessage());
                             }
                      
                        if(!$query){
                           
                            return redirect()->back()->with('fail','Registration failed');
                        }else{
                            $corUser= new CorporateAdmin();
                            $values=['cadmin_companyName'=>$name,
                                      'cadmin_email'=>$email,
                                      'cadmin_contact'=>$contact,
                                      'cadmin_contactPerson'=>$contactPerson,
                                      'cadmin_address'=>$address,
                                      'cadmin_companyCode'=>$companycode,
                                      'user_id'=>$insert_id,
                                      'cadmin_tradeLNo'=>$trade_lno,
                                      'cadmin_vatNo'=>$vat_no,
                                      'cadmin_adm_email'=>$adm_email,
                                      'cadmin_adm_no'=>$adm_no,
                                      'cadmin_acc_email'=>$acc_email,
                                      'cadmin_acc_no'=>$acc_no
                                     ];
                            $query_cor=$corUser->insert($values);
                            if(!$query_cor){
                                $user->where('user_id', $insert_id)->delete(); 
                                return redirect()->back()->with('fail','Registration failed');  
                            }else{
                            
                              //  $this->sendingEmail($email,$username,$password);
                                return redirect()->to(base_url('CorporateAdminMng'))->with('success','Registration done successfully');
                        
                            }
                        }
    
                }
    
            else:
             return view('dashboard/newCorporateAdmin',$data);
            endif;
    }

     
    public function edit($userID,$companyID)
    {
        if($_POST){
            $validation = $this->validate([
                'companyName'=>[
                    'rules'=>'required',
                    'errors'=>[
                        'required'=>'You must enter company name',
                        'is_unique'=>'Updated Company name already exist..'
                    ],
                ],
                'email'=> [
                    'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_email,corporate_admin.cadmin_id,'.$companyID.']',
                    'errors'=>[
                                'required'=>'You must enter the email',
                                'valid_email'=>'You must enter a valid email',
                                'is_unique'=>'Updated Email  exist..please try another...'
                             ],
                    ],
                    'trade_lno'=> [
                        'rules'=>'required|is_unique[corporate_admin.cadmin_tradeLNo,corporate_admin.cadmin_id,'.$companyID.']',
                        'errors'=>[
                                    'required'=>'You must enter the trade License Number',
                                    'is_unique'=>'Trade License number  exist..please try another...'
                                ],
                    ],
                    'adm_email'=> [
                        'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_adm_email,corporate_admin.cadmin_id,'.$companyID.']',
                        'errors'=>[
                                    'required'=>'You must enter the email',
                                    'valid_email'=>'You must enter a valid email',
                                    'is_unique'=>'Administration Email  exist..please try another...'
                                 ],
                        ],
                    'acc_email'=> [
                        'rules'=>'required|valid_email|is_unique[corporate_admin.cadmin_acc_email,corporate_admin.cadmin_id,'.$companyID.']',
                        'errors'=>[
                                    'required'=>'You must enter the email',
                                    'valid_email'=>'You must enter a valid email',
                                    'is_unique'=>'Accountant Email  exist..please try another...'
                                 ],
                        ],
                 'companycode'=>[
                    'rules'=>'required|is_unique[corporate_admin.cadmin_companyCode,corporate_admin.cadmin_id,'.$companyID.']',
                    'errors'=>[
                        'required'=>'You must enter the company code',                       
                        'is_unique'=>'Updated Company Code  exist... please use another code!!'
                     ],
                ],
                
                ]);
                
            if (!$validation){
               
                
                return redirect()->back()->withInput()->with('validation', $this->validator->getErrors()); 
                
            }else{ 
            $name=$this->request->getPost('companyName');
            $email=$this->request->getPost('email');
            $contact=$this->request->getPost('contactNo');
            $contactPerson=$this->request->getPost('contactPerson');                    
            $address=$this->request->getPost('address');
            $companycode=$this->request->getPost('companycode');
            $trade_lno=$this->request->getPost('trade_lno');
            $vat_no=$this->request->getPost('vat_no');
            $vat_no=$this->request->getPost('vat_no');
            $adm_email=$this->request->getPost('adm_email');
            $adm_no=$this->request->getPost('adm_no');
            $acc_email=$this->request->getPost('acc_email');
            $acc_no=$this->request->getPost('acc_no');
            $date=date('Y-m-d');
            $values=['cadmin_companyName'=>$name,
                     'cadmin_email'=>$email,
                     'cadmin_contact'=>$contact,
                     'cadmin_contactPerson'=>$contactPerson,
                     'cadmin_address'=>$address,
                     'cadmin_companyCode'=>$companycode,
                     'cadmin_tradeLNo'=>$trade_lno,
                     'cadmin_vatNo'=>$vat_no,
                     'cadmin_adm_email'=>$adm_email,
                     'cadmin_adm_no'=>$adm_no,
                     'cadmin_acc_email'=>$acc_email,
                     'cadmin_acc_no'=>$acc_no
                   ];
            $upadte_obj=new CorporateAdmin();
            $update_query=$upadte_obj->update($companyID,$values);
            if(!$update_query){
                return redirect()->to(base_url('CorporateAdminMng'))->with('fail','Updation failed');
            }else{
                $update_last_date=new User();
                $val=['user_updated_date'=>$date];
                $updateQuery=$update_last_date->update($userID,$val);
                return redirect()->to(base_url('CorporateAdminMng'))->with('success','Updated successfully');
            }
        }

        }else{
                $userArray=$this->show();        
                $getCompnay= new CorporateAdmin();
                $getCompany_info=$getCompnay->where(['cadmin_id'=>$companyID,'user_id'=>$userID])->first();
                $data=[
                    'active'=>'corporateAdmin',
                    'userID'=>$userArray['user_id'],
                    'status'=>$userArray['status'],
                    'header'=>'Update Corporate Admins',
                    'companyInfo'=>$getCompany_info            
                 ];
                 return view('dashboard/editCorporateAdmin',$data);
        }
    }

    public function delete($userID)
    {
        $userInfo = new User();
        $getCompnay= new CorporateAdmin();
        $query_del=$userInfo->where('user_id', $userID)->delete();
        if($query_del){
                $getCompnay->where('user_id', $userID)->delete();
                return redirect()->to(base_url('CorporateAdminMng'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('CorporateAdminMng'))->with('fail','Deletion failed!!');
        }
       
    }

    public function sendingEmail($to,$username,$password){
       // $message = "Please activate the account ".anchor('user/activate/'.$data['u_link'],'Activate Now','');
       $message="hai";
        $email = \Config\Services::email();
        $email->setFrom('no-reply@reply.com', 'no-reply');
        $email->setTo($to);
        $email->setSubject('');
        $email->setMessage($message);//your message here
        $email->send();
        $email->printDebugger(['headers']);
     }

   
}
?>