<?php

namespace App\Controllers;
use App\Models\Corporate_user;
//use App\Models\User;

class Corporate_registrations extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
       
       $userArray=$this->show();
       $obj_corporate=new Corporate_user();
       $corporateUser=$obj_corporate->join('users','corporate_users.user_id=users.user_id')
                                    ->join('corporate_admin','corporate_admin.cadmin_id=corporate_users.cor_companyID')
                                    ->where('users.user_active','1')->paginate(20);
      
        $data=[
            'active'=>'customer',
            'sub'=>'corporate',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Corporate Users Details',
            'details'=>$corporateUser
        ];
        $data['pager']=$obj_corporate->join('users','corporate_users.user_id=users.user_id')
                                    ->join('corporate_admin','corporate_admin.cadmin_id=corporate_users.cor_companyID')
                                    ->where('users.user_active','1')->pager;
      
       
        return view('dashboard/corporateUsers', $data);
        
    }

    public function delete($regUserID)
    {
        /*$userInfo = new User();
        $obj_regular= new Regular_user();
        $query_del=$userInfo->where('user_id', $regUserID)->delete();
        if($query_del){
                $obj_regular->where('user_id', $regUserID)->delete();
                return redirect()->to(base_url('regular_registrations'))->with('result','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('regular_registrations'))->with('result','Deletion failed!!');
        }*/
    }
}
?>