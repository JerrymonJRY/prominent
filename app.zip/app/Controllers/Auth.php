<?php

namespace App\Controllers;
use App\Models\User;
use App\Models\Regular_user;
use App\Models\Corporate_user;
use App\Models\CorporateAdmin;


class Auth extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }
    public function index()
    {
       
        if($_POST):
              
             $user= new User();
             $validation = $this->validate([
                    'username'=> [
                        'rules'=>'required|valid_email|is_not_unique[users.user_username]',
                        'errors'=>[
                                'required'=>'Email id required ',
                                'valid_email'=>'Valid email id required',
                                'is_not_unique'=>'username not registered'
                             ],
                    ],
                    'password'=>[
                        'rules'=>'required',
                        'errors'=>[
                                    'required'=>'Enter the password'
                                ],
                    ],                   
                ]);
                
                if (!$validation){
                        return view('auth/login',['validation'=>$this->validator]);
                }else{
                   
                    $username=$this->request->getPost('username');
                    $password=$this->request->getPost('password');
                    $checkUser= new User();
                    
                    try{
                    $user_info=$checkUser->where(['user_username'=>$username,'user_active'=>1])->first();

                    $check_password=$checkUser->checkPassword($password,$user_info['user_password']);
                    if(!$check_password){
                        return redirect()->to(base_url())->with('result','Incorrect username or password');
                    }else{
                        
                        session()->set('loggeduser',$user_info['user_id']);
                        session()->set('loggeduserstatus',$user_info['user_status']);
                        //added by shifa
                        if(!empty($_GET['type'])){
                            return redirect()->to('/booking/trip-booking/?type='.$_GET['type']);
                        }
                        else{
                            return redirect()->to('/dashboard');
                        }
                        
                    }  
                    }catch (\Exception $e) {
                    die($e->getMessage());
                    }
                    }
                    
        else:
            if(session()->has('loggeduser')){
                //return redirect()->to('auth/login')->with('result','Logged another User');
                return view('auth/login',['validationsErr'=>"Sorry..You can't access now..Another user logged ",'nolog'=>1]);
            }else{
                return view('auth/login');
            }
        endif;
    }

    //Reset Password
    public function resetPassword(){
        $user_id=session()->get('loggeduser');
        $status=session()->get('loggeduserstatus');
        if($_POST){
            $cupassword=$this->request->getPost('cupassword');
            $npassword=$this->request->getPost('npassword'); 
            $cpassword=$this->request->getPost('cpassword'); 
            $checkUser= new User();
            $user_info=$checkUser->where(['user_id'=>session()->get('loggeduser'),'user_active'=>1])->first();
            $check_password=$checkUser->checkPassword($cupassword,$user_info['user_password']);
            if(!$check_password){
                return redirect()->back()->with('fail','Incorrect Password');
            }else{
                $validation = $this->validate([
                    
                        'cpassword'=>[
                                'rules'=>'required|matches[npassword]',
                                'errors'=>[
                                            
                                            'matches'=>'confirm password not matches to new password'
                                        ],
                                    ],
                    ]);
                    
                    if (!$validation){
                       
                        return redirect()->back()->with('fail','confirm password not matches to new password');
                    }else{
                        $data=[                
                            'user_password'=>$npassword
                           ];
                           $update_query=$checkUser->update(session()->get('loggeduser'),$data);
                           if($update_query){
                            return redirect()->back()->with('success','Successfully reset the password');
                           }else{
                            return redirect()->back()->with('fail','failed the operation');
                           }
                    } 
                  
            }
                   
        }else{
            $data=[
                'userID'=>$user_id,
                'status'=>$status,
                'header'=>'Reset Password'            
            ];
            return view('dashboard/resetpassword',$data); 
        }


    }
    //edit corporate user profile
     public function edituserProfile()
    {
        $cor_user= new Corporate_user();
        $user_id=session()->get('loggeduser');
        $status=session()->get('loggeduserstatus');
        if($_POST){
               $name=$this->request->getPost('name');
                $email=$this->request->getPost('email');
                $contactCode=$this->request->getPost('contactCode');
                $contact=$this->request->getPost('contact');
                $employeeid=$this->request->getPost('employeeid');

                $values=['cor_name'=>$name,
                'cor_contactCode'=>$contactCode,
                'cor_contact'=>$contact, 
                'cor_email'=>$email,
                'cor_employeeId'=>$employeeid              
                ]; 
               $find_id=$cor_user->where('user_id',$user_id)->first();
                $update_info=$cor_user->update( $find_id['cor_id'],$values);
              // $update_info=$cor_user->where('user_id',$user_id)->update($values);
                if($update_info){
                    return redirect()->back()->with('success','Profile updated successfully');
                }else{
                    return redirect()->back()->with('success','Operation Failed');
                }

        }else{
            
            $get_info=$cor_user->where('user_id',session()->get('loggeduser'))->first();
            $data=[
               'info'=>$get_info,
               'userID'=>$user_id,
            'status'=>$status,
                'header'=>'Change Profile',
                            
            ];
            return view('dashboard/edituserProfile',$data);  
        }
    }
   

     //code for regular customer tregistration
    public function regularSignUp()
    {
       
       if($_POST):
        $validation = $this->validate([
            'email'=> [
                'rules'=>'required|valid_email|is_unique[users.user_username]',
                'errors'=>[
                            'required'=>'Email id Required',
                            'valid_email'=>'Valid email id required',
                            'is_unique'=>'Email id already exist..please try another...'
                         ],
                ],
               'password'=>[
                    'rules'=>'required|min_length[8]',
                    'errors'=>[
                                'required'=>'Password required',
                                'min_length'=>'Password required minimum 8 characters'
                            ],
                     ],
                'cpassword'=>[
                        'rules'=>'required|matches[password]|min_length[8]',
                        'errors'=>[
                                    'required'=>'Confirm password required',
                                    'matches'=>'confirm password not matches to password',
                                    'min_length'=>'Confirm Password required minimum 8 characters'
                                ],
                            ],
            ]);
            
            if (!$validation){
               
                return view('auth/regular_signUp',['validation'=>$this->validator]);
            }else{
                $name=$this->request->getPost('fullname');
                $email=$this->request->getPost('email');
                $contactCode=$this->request->getPost('contactCode');
                $contact=$this->request->getPost('contact');

                $password=$this->request->getPost('password');                
                $status='3';
                $role='Regular User';
                $active='1';
                $date=date('Y-m-d');
                $data=[                        
                         'user_username'=>$email,
                         'user_password'=>$password,
                         'user_status'=>$status,
                         'user_role'=>$role,
                         'user_active'=>$active,
                         'user_created_date'=>$date,
                         'user_updated_date'=>$date
                        ];
               
                try {
                        $user= new User();
                        $query=$user->insert($data);
                        $insert_id=$user->getInsertID();                            
                    } catch (\Exception $e) {
                die($e->getMessage());
                }
               
                if(!$query){
                   
                    return redirect()->back()->with('result','Registration failed');
                }else{
                    $regUser= new Regular_user();
                    $values=['reg_name'=>$name,
                              'reg_contactCode'=>$contactCode,
                              'reg_contact'=>$contact,
                              'reg_email'=>$email,
                              'user_id'=>$insert_id];
                    $regUser->insert($values);
                    return redirect()->to(base_url('Auth/regularSignUp'))->with('result','Registration done successfully');
                }

            }

            
       else:
            return view('auth/regular_signUp');
       endif;
  
     
    }

    //lets start code for corporate customer registration
    public function corporateSignUp()
    {
       
       if($_POST):
        $validation = $this->validate([
            'email'=> [
                'rules'=>'required|valid_email|is_unique[users.user_username]',
                'errors'=>[
                            'required'=>'Email id required',
                            'valid_email'=>'Valid Email id required',
                            'is_unique'=>'Email already exist..please try another...'
                         ],
                ],
                'password'=>[
                    'rules'=>'required|min_length[8]',
                    'errors'=>[
                                'required'=>'Password required',
                                'min_length'=>'Password required minimum 8 characters'
                            ],
                     ],
                'cpassword'=>[
                        'rules'=>'required|matches[password]|min_length[8]',
                        'errors'=>[
                                    'required'=>'Confirm password required',
                                    'matches'=>'confirm password not matches to password',
                                    'min_length'=>'Confirm Password required minimum 8 characters'
                                ],
                            ],
                'company_code'=>[
                        'rules'=>'required|is_not_unique[corporate_admin.cadmin_companyCode]',
                        'errors'=>[
                                    'required'=>'Company Code required',
                                    'is_not_unique'=>'Wrong Company Code... '
                                ],
                            ],
                            
            ]);
            
            if (!$validation){
               
                return view('auth/corporate_signUp',['validation'=>$this->validator]);
            }else{
                $name=$this->request->getPost('fullname');
                $email=$this->request->getPost('email');
                $contactCode=$this->request->getPost('contactCode');
                $contact=$this->request->getPost('contact');
                $password=$this->request->getPost('password');
                $company_code=$this->request->getPost('company_code');
                $employee_id=$this->request->getPost('employee_id');
                $status='4';
                $role='Corporate User';
                $active='0';
                $date=date('Y-m-d');
                $data=[                        
                         'user_username'=>$email,
                         'user_password'=>$password,
                         'user_status'=>$status,
                         'user_role'=>$role,
                         'user_active'=>$active,
                         'user_created_date'=>$date,
                         'user_updated_date'=>$date
                        ];
               
                        try {
                            $user= new User();
                            $query=$user->insert($data);
                            $insert_id=$user->getInsertID();                            
                        } catch (\Exception $e) {
                    die($e->getMessage());
                    }
                   
                    if(!$query){
                       
                        return redirect()->back()->with('result','Registration failed');
                    }else{
                        $obj_cadmin=new CorporateAdmin();
                        $sel_query=$obj_cadmin->where('cadmin_companyCode',$company_code)->first();
                        $companyId=$sel_query['cadmin_id'];
                        $corUser= new Corporate_user();
                        $values=['cor_name'=>$name,
                                  'cor_contactCode'=>$contactCode,
                                  'cor_contact'=>$contact,
                                  'cor_email'=>$email,
                                  'cor_companyID'=>$companyId,
                                  'cor_employeeId'=>$employee_id,
                                  'user_id'=>$insert_id];
                        $insert_query=$corUser->insert($values);
                        if($insert_query){
                            return redirect()->to(base_url('Auth/corporateSignUp'))->with('result','Registration done successfully');
                        }else{
                            $obj_user= new User();
                            $query_del=$obj_user->where('user_id', $insert_id)->delete();                            
                            return redirect()->to(base_url('Auth/corporateSignUp'))->with('fail','Registration failed'); 
                        }
                    }

            }

            
       else:
            return view('auth/corporate_signUp');
       endif;
  
     
    }

    
    public function logout(){
       
        if(session()->has('loggeduser')){
            session()->remove('loggeduser');
            return redirect()->to(base_url())->with('result','You are logged out!!');
        }
    }

    
}
