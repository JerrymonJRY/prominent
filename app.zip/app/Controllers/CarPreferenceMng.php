<?php

namespace App\Controllers;
use App\Models\CarPreference;
class CarPreferenceMng extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
              
        $userArray=$this->show();
        $car_obj= new CarPreference();
        $carDetails=$car_obj->findAll();
        $data=[
                'active'=>'car',
                'userID'=>$userArray['user_id'],
                'status'=>$userArray['status'],
                'header'=>'Car Preference',
                'details'=>$carDetails
        ];
        if($_POST):
            $validation = $this->validate([
                'car_type'=>[
                    'rules'=>'required|is_unique[cartype.ct_type]',
                    'errors'=>[
                        'required'=>'You must enter car preference',
                        'is_unique'=>'Car preference already exist..'
                    ],
                ],
            ]);
            if (!$validation){
                $data['validation']=$this->validator;
                return view('dashboard/carPreference',$data);
            }else{
                $car_type=$this->request->getPost('car_type');
                $date=date('Y-m-d');
                $values=['ct_type'=>$car_type,
                         'ct_created_date'=>$date,
                         'ct_lastUpdated_date'=>$date];
                $insert_obj=new CarPreference();
                $query_insert=$insert_obj->insert($values);
                if(!$query_insert){
                    return redirect()->to(base_url('CarPreferenceMng'))->with('fail','Adding new car preference is failed!!');
                }else{
                    return redirect()->to(base_url('CarPreferenceMng'))->with('success','Successfully added new car preference!!');
                }
                
            }
        else:
            return view('dashboard/carPreference', $data);
        endif;   
        
        
    }

    public function edit($carID)
    {
        $validation = $this->validate([
            'car_type'=>[
                'rules'=>'required|is_unique[cartype.ct_type,cartype.ct_id,'.$carID.']',
                'errors'=>[
                    'required'=>'You must enter car preference',
                    'is_unique'=>'Car preference already exist..'
                ],
            ],
        ]);
        if (!$validation){
            $userArray=$this->show();
            $car_obj= new CarPreference();
            $carDetails=$car_obj->findAll();
            $data=[
                    'active'=>'car',
                    'userID'=>$userArray['user_id'],
                    'status'=>$userArray['status'],
                    'header'=>'Car Preference',
                    'details'=>$carDetails
            ];
            $data['validation']=$this->validator;    
            return view('dashboard/carPreference', $data);
        }else{
            $car_type=$this->request->getPost('car_type');
            $date=date('Y-m-d');
            $values=['ct_type'=>$car_type,
                     'ct_lastUpdated_date'=>$date];
            $update_obj=new CarPreference();
            $query_update=$update_obj->update($carID,$values);
            if(!$query_update){
                return redirect()->to(base_url('CarPreferenceMng'))->with('fail','Updating  car preference is failed!!');
            }else{
                return redirect()->to(base_url('CarPreferenceMng'))->with('success','Successfully updayted  car preference!!');
            }
           
        }
    
    }

    public function delete($carID)
    {
        $delete_obj= new CarPreference();
        $query_del=$delete_obj->where('ct_id', $carID)->delete();
        if(!$query_del){
            return redirect()->to(base_url('CarPreferenceMng'))->with('fail','Deleting car preference is failed');
        }else{
            return redirect()->to(base_url('CarPreferenceMng'))->with('success','Successfully deleted');
        }
    }
}
?>