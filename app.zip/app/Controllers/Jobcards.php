<?php

namespace App\Controllers;
use App\Models\Jobcard;

class Jobcards extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        
       $userArray=$this->show();
       $obj_job=new Jobcard();
       $getjobcards= $obj_job->join('trip_booking','trip_booking.booking_id=job_card.booking_id')->where('active',1)->orderby('job_id','DESC')->paginate(20);
     
        $data=[
            'active'=>'jobcard',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Job cards',
            'cards'=>$getjobcards
        ];
        $data['pager']= $obj_job->join('trip_booking','trip_booking.booking_id=job_card.booking_id')->where('active',1)->orderby('job_id','DESC')->pager;
        return view('dashboard/listTrips_adminView1', $data);
        
    }

    

     
}
?>