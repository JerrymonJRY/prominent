<?php

namespace App\Controllers;
use App\Models\CarPreference;
use App\Models\Booktype;
use App\Models\Triptype;
use App\Models\TripBooking;
use App\Models\Passengers;
use App\Models\Corporate_user;
use App\Models\CorporateAdmin;
use App\Models\Drivers;
use App\Models\Regular_user;
use App\Models\Supplier;
use App\Models\Jobcard;
use App\Libraries\Mandrill;

class Booking extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        $userArray=$this->show();
        $car_obj=new CarPreference();
        $sel_query_car=$car_obj->findAll();
        $bookType_obj=new Booktype();
        $sel_query_book=$bookType_obj->findAll();
        $obj_tripType=new Triptype();
        $sel_query_trip=$obj_tripType->findAll();
        $data=[
            'active'=>'book',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Trip Booking',
            'carType'=>$sel_query_car,
            'bookType'=>$sel_query_book,
            'tripType'=>$sel_query_trip
        ];

        return view('dashboard/trip_book', $data);
    }
    
    public function regular(){
        $userArray=$this->show();
        $car_obj=new CarPreference();
        $sel_query_car=$car_obj->findAll();
        $bookType_obj=new Booktype();
        $sel_query_book=$bookType_obj->findAll();
        $obj_tripType=new Triptype();
        $sel_query_trip=$obj_tripType->findAll();
        $data=[
            'active'=>'book',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Trip Booking',
            'carType'=>$sel_query_car,
            'bookType'=>$sel_query_book,
            'tripType'=>$sel_query_trip
        ];

        return view('dashboard/regular_trip_book', $data);
    }
    public function corporate()
    {
        
       if($_POST):
        $idinseert='';
        $carType_id=$this->request->getPost('carPreference');
        $bookType_id=$this->request->getPost('bookType');
        $booking_datem=$this->request->getPost('mdp-demo');       
        $explode_date=explode(",",$booking_datem);
              
        $booking_timehr=$this->request->getPost('pickuptimehr');
        $booking_timemin=$this->request->getPost('pickuptimemin');
        $booking_time=$booking_timehr.':'.$booking_timemin;
        
        $tripType_id=$this->request->getPost('trip');
       
        $booking_from=$this->request->getPost('from');
        $booking_to=$this->request->getPost('to');
        $numstops=$this->request->getPost('numadstop');
        if($numstops!=0){
        $stops=$this->request->getPost('addmore');
        $lengthstops=count($stops);
        if($lengthstops>0){
        foreach($stops as $stop){
            if($stop!=''){
                $book_stops[]=$stop;
            }
        }        
        $booking_stop= implode("-*-",$book_stops);
        }else{
            $booking_stop= '';   
        }
        }else{
            $booking_stop= '';
        }
       
        $booking_NoPassegers=$this->request->getPost('passengers');  
        $booking_department=$this->request->getPost('department'); 
        $booking_projectCode=$this->request->getPost('project_code');
        $task_code=$this->request->getPost('task_code');
        $driver_note=$this->request->getPost('driver_note');
        
        $date= date('Y-m-d');
        $in=0;
        if($tripType_id!=2){
        foreach($explode_date as $exdate):
        
        $values=['carType_id'=>$carType_id, 
                 'booking_date'=>$exdate,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>$tripType_id,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers, 
                 'booking_projectCode'=>$booking_projectCode,
                 'sadmin_approval'=>0, 
                 'cadmin_approval'=>0, 
                 'booking_createdDate'=>$date, 
                 'user_id'=>session()->get('loggeduser'), 
                 'user_type'=>session()->get('loggeduserstatus'), 
                 'company_Id'=>session()->get('companyId'),
                 'driver_note'=>$driver_note,
                 'booking_taskCode'=>$task_code,
                 'booking_department'=>$booking_department]; 

        if($exdate==$date){
            $values['bookType_id']=1;
        }else{
            $values['bookType_id']=2;
        }

        if($tripType_id==2){
            $returntimehr=$this->request->getPost('returntimehr');
            $returntimemin=$this->request->getPost('returntimemin');
            $returntime=$returntimehr.':'.$returntimemin;
            $values['booking_return_time']=$returntime;
        }
        if($booking_projectCode!=''){
            $values['cadmin_approval']=1;
            $values['booking_cadmin_date']=$date;
        }
        
        $obj_insert=new TripBooking();
        $insert_query=$obj_insert->insert($values);
        $insert_id=$obj_insert->getInsertID();
        $idinsert= $idinsert.' '.$insert_id.',';
        if($insert_query){
            $in++;
             //passengers details
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerLocation=$this->request->getPost('passengerLocation');
            $obj_passenger= new Passengers();
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $location=$passengerLocation[$i];
                if(($name!='')||($contact!='')){
                $data=['passenger_name'=>$name, 
                'passenger_contact'=>$contact, 
                'passenger_location'=>$location,
                'booking_id'=>$insert_id];
                $obj_passenger->insert($data);
                }
            }
            }
         
        }
    endforeach;
}else{
    
    foreach($explode_date as $exdate):

        for($z=0;$z<2;$z++){
            
            if($z==0){
                $values=['carType_id'=>$carType_id,
                 'booking_date'=>$exdate,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>1,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers, 
                 'booking_projectCode'=>$booking_projectCode,
                 'sadmin_approval'=>0, 
                 'cadmin_approval'=>0, 
                 'booking_createdDate'=>$date, 
                 'user_id'=>session()->get('loggeduser'), 
                 'user_type'=>session()->get('loggeduserstatus'), 
                 'company_Id'=>session()->get('companyId'),
                 'driver_note'=>$driver_note,
                 'booking_taskCode'=>$task_code,
                 'booking_department'=>$booking_department]; 

                /*if($tripType_id==2){
                    $returntimehr=$this->request->getPost('returntimehr');
                    $returntimemin=$this->request->getPost('returntimemin');
                    $returntime=$returntimehr.':'.$returntimemin;
                    $values['booking_return_time']=$returntime;
                }*/
                if($booking_projectCode!=''){
                    $values['cadmin_approval']=1;
                    $values['booking_cadmin_date']=$date;
                }
                $date= date('Y-m-d');
                if($exdate==$date){
                    $values['bookType_id']=1;
                   }else{
                    $values['bookType_id']=2;
                }
             } else{
                $returntimehr=$this->request->getPost('returntimehr');
                $returntimemin=$this->request->getPost('returntimemin');
                $returntime=$returntimehr.':'.$returntimemin;
                $values['booking_return_time']=$returntime;
                $values=['carType_id'=>$carType_id,
                'bookType_id'=>$bookType_id, 
                'booking_date'=>$exdate,
                'booking_time'=>$returntime,
                'tripType_id'=>1,
                'booking_from'=>$booking_to,
                'booking_to'=>$booking_from,
                'booking_stop'=>$booking_stop,
                'booking_NoPassengers'=>$booking_NoPassegers, 
                'booking_projectCode'=>$booking_projectCode,
                'sadmin_approval'=>0, 
                'cadmin_approval'=>0, 
                'booking_createdDate'=>$date, 
                'user_id'=>session()->get('loggeduser'), 
                'user_type'=>session()->get('loggeduserstatus'), 
                'company_Id'=>session()->get('companyId'),
                'driver_note'=>$driver_note,
                'booking_taskCode'=>$task_code,
                'booking_department'=>$booking_department]; 
                               
               if($booking_projectCode!=''){
                   $values['cadmin_approval']=1;
                   $values['booking_cadmin_date']=$date;
               }
               $date= date('Y-m-d');
                if($exdate==$date){
                    $values['bookType_id']=1;
                }else{
                    $values['bookType_id']=2;
                }

            }
                
        $obj_insert=new TripBooking();
        $insert_query=$obj_insert->insert($values);
        $insert_id=$obj_insert->getInsertID();
        $idinsert= $idinsert.' '.$insert_id.',';
        if($insert_query){
            $in++;
             //passengers details
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerLocation=$this->request->getPost('passengerLocation');
            $obj_passenger= new Passengers();
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $location=$passengerLocation[$i];
                if(($name!='')||($contact!='')){
                $data=['passenger_name'=>$name, 
                'passenger_contact'=>$contact, 
                'passenger_location'=>$location,
                'booking_id'=>$insert_id];
                $obj_passenger->insert($data);
                }
            }
            }
         
        }
    }

    endforeach;
    
}
$insert_id=$idinsert;
        if($in!=0){
           
            $obj_cname=new CorporateAdmin();
            $getCompany=$obj_cname->where('cadmin_id',session()->get('companyId'))->first();
            $nameCompany=$getCompany['cadmin_companyName']; 

            $obj_usermail=new Corporate_user();
            $getmail=$obj_usermail->where('user_id',session()->get('loggeduser'))->first();
            $bookingmail=$getmail['cor_email'];  
            $bookingname=$getmail['cor_name']; 

            $obj_car= new CarPreference();
            $getcarType=$obj_car->where('ct_id',$carType_id)->first();
            $car=$getcarType['ct_type'];

            $obj_trip= new Triptype();
            $gettripType=$obj_trip->where('trt_id',$tripType_id)->first();
            $trip=$gettripType['trt_type'];

            if($tripType_id==2){
                $tr='<tr bgcolor="#ffffff">
                <td>Return Time:</td>
                <td>'.$returntime.'</td>
            </tr><tr bgcolor="#ffffff">
            <td>Return Routing Detail:</td>
            <td>From:'.$booking_to.'<br> To:'.$booking_from.'<br> Stops:'.$booking_stop.'
        </tr>';
            }else{
                $tr='';
            }

            $obj_book= new Booktype();
            $getbookType=$obj_book->where('bt_id',$bookType_id)->first();
            $bookType=$getbookType['bt_type'];
           
            $email = \Config\Services::email();
            $bookmail='noreply@verticsonline.com';
            $bookname='No-reply';
            $email->setFrom($bookmail, $bookname);
            $email->setTo('booking@prominentlimo.com');            
            $email->setCC('prominentlimo@gmail.com');
            $email->setSubject('New Booking From '.$nameCompany);
             $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                <p>
                                                Hello , <br>
                                            </p>
                                             
                                            <p>
                                                New booking received from '.$nameCompany.' . And booking done by '.$bookingname .'
                                            </p>
                                                   
                                                    
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Booking Number # '.$insert_id.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Pick-up Date:</td>
                                                            <td>'.$booking_datem.'</td>
                                                        </tr>
                                                         <tr bgcolor="#ffffff">
                                                            <td>Pick-up Time:</td>
                                                            <td>'.$booking_time.'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Routing Detail:</td>
                                                            <td>From:'.$booking_from.'<br> To:'.$booking_to.'<br> Stops:'.$booking_stop.'
                                                        </tr>
                                                        
                                                        <tr bgcolor="#ffffff">
                                                            <td>Trip type:</td>
                                                            <td>'.$trip.'</td>
                                                        </tr>'.$tr.'
                                                        <tr bgcolor="#ffffff">
                                                            <td>Car preferences:</td>
                                                            <td>'.$car.'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Booking Type:</td>
                                                            <td>'.$bookType.'</td>
                                                        </tr>
                                                                                                      
                                                   </table>
                                                        
                                                    </table>
                                                    <p>
                                                    
                                                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                    
            $email->setMessage($message); 
          
            if($email->send()){
                
            }else{
                $err=$email->printDebugger(['headers']);
                //print_r($err);
                
            }
                            
            return redirect()->to(base_url('dashboard'))->with('success','Your booking has been received. we will get back to you shortly');
        }else{
            return redirect()->back()->with('fail','Booking failed');  
        }      
        
       endif;
    }

    public function save()
    {
       if($_POST):
        $idinseert='';
        $carType_id=$this->request->getPost('carPreference');
        $bookType_id=$this->request->getPost('bookType');
        $booking_datem=$this->request->getPost('mdp-demo');       
        $explode_date=explode(",",$booking_datem);
              
        $booking_timehr=$this->request->getPost('pickuptimehr');
        $booking_timemin=$this->request->getPost('pickuptimemin');
        $booking_time=$booking_timehr.':'.$booking_timemin;
        
        $tripType_id=$this->request->getPost('trip');
       
        $booking_from=$this->request->getPost('from');
        $booking_to=$this->request->getPost('to');
        $numstops=$this->request->getPost('numadstop');
        if($numstops!=0){
        $stops=$this->request->getPost('addmore');
        $lengthstops=count($stops);
        if($lengthstops>0){
        foreach($stops as $stop){
            if($stop!=''){
                $book_stops[]=$stop;
            }
        }        
        $booking_stop= implode("-*-",$book_stops);
        }else{
            $booking_stop= '';   
        }
        }else{
            $booking_stop= '';
        }
       
        $booking_NoPassegers=$this->request->getPost('passengers');  
        
        $driver_note=$this->request->getPost('driver_note');
        
        $date= date('Y-m-d');
        $in=0;
        if($tripType_id!=2){
        foreach($explode_date as $exdate):
        
        $values=['carType_id'=>$carType_id, 
                 'booking_date'=>$exdate,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>$tripType_id,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers, 
                 'sadmin_approval'=>0, 
                 'booking_createdDate'=>$date, 
                 'user_id'=>session()->get('loggeduser'), 
                 'user_type'=>session()->get('loggeduserstatus'), 
                 
                 'driver_note'=>$driver_note
                ]; 

        if($exdate==$date){
            $values['bookType_id']=1;
        }else{
            $values['bookType_id']=2;
        }

        if($tripType_id==2){
            $returntimehr=$this->request->getPost('returntimehr');
            $returntimemin=$this->request->getPost('returntimemin');
            $returntime=$returntimehr.':'.$returntimemin;
            $values['booking_return_time']=$returntime;
        }
        
        
        $obj_insert=new TripBooking();
        $insert_query=$obj_insert->insert($values);
        $insert_id=$obj_insert->getInsertID();
        $idinsert= $idinsert.' '.$insert_id.',';
        if($insert_query){
            $in++;
             //passengers details
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerLocation=$this->request->getPost('passengerLocation');
            $obj_passenger= new Passengers();
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $location=$passengerLocation[$i];
                if(($name!='')||($contact!='')){
                $data=['passenger_name'=>$name, 
                'passenger_contact'=>$contact, 
                'passenger_location'=>$location,
                'booking_id'=>$insert_id];
                $obj_passenger->insert($data);
                }
            }
            }
         
        }
    endforeach;
}else{
    
    foreach($explode_date as $exdate):

        for($z=0;$z<2;$z++){
            
            if($z==0){
                $values=['carType_id'=>$carType_id,
                 'booking_date'=>$exdate,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>1,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers, 
                 
                 'sadmin_approval'=>0, 
                
                 'booking_createdDate'=>$date, 
                 'user_id'=>session()->get('loggeduser'), 
                 'user_type'=>session()->get('loggeduserstatus'), 
                 
                 'driver_note'=>$driver_note
                 ]; 

                /*if($tripType_id==2){
                    $returntimehr=$this->request->getPost('returntimehr');
                    $returntimemin=$this->request->getPost('returntimemin');
                    $returntime=$returntimehr.':'.$returntimemin;
                    $values['booking_return_time']=$returntime;
                }*/
                
                $date= date('Y-m-d');
                if($exdate==$date){
                    $values['bookType_id']=1;
                   }else{
                    $values['bookType_id']=2;
                }
             } else{
                $returntimehr=$this->request->getPost('returntimehr');
                $returntimemin=$this->request->getPost('returntimemin');
                $returntime=$returntimehr.':'.$returntimemin;
                $values['booking_return_time']=$returntime;
                $values=['carType_id'=>$carType_id,
                'bookType_id'=>$bookType_id, 
                'booking_date'=>$exdate,
                'booking_time'=>$returntime,
                'tripType_id'=>1,
                'booking_from'=>$booking_to,
                'booking_to'=>$booking_from,
                'booking_stop'=>$booking_stop,
                'booking_NoPassengers'=>$booking_NoPassegers, 
               
                'sadmin_approval'=>0, 
               
                'booking_createdDate'=>$date, 
                'user_id'=>session()->get('loggeduser'), 
                'user_type'=>session()->get('loggeduserstatus'), 
                
                'driver_note'=>$driver_note
                ]; 
                               
              
               $date= date('Y-m-d');
                if($exdate==$date){
                    $values['bookType_id']=1;
                }else{
                    $values['bookType_id']=2;
                }

            }
                
        $obj_insert=new TripBooking();
        $insert_query=$obj_insert->insert($values);
        $insert_id=$obj_insert->getInsertID();
        $idinsert= $idinsert.' '.$insert_id.',';
        if($insert_query){
            $in++;
             //passengers details
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerLocation=$this->request->getPost('passengerLocation');
            $obj_passenger= new Passengers();
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $location=$passengerLocation[$i];
                if(($name!='')||($contact!='')){
                $data=['passenger_name'=>$name, 
                'passenger_contact'=>$contact, 
                'passenger_location'=>$location,
                'booking_id'=>$insert_id];
                $obj_passenger->insert($data);
                }
            }
            }
         
        }
    }

    endforeach;
    
}
$insert_id=$idinsert;
        if($in!=0){
           
           $companyName='Regular';
            $obj_reg=new Regular_user();
            $get_user=$obj_reg->where('user_id',$bookuserid)->first();
            $bookingname=$get_user['reg_name'];
            $bookingmail=$getmail['reg_email'];  
           

            $obj_car= new CarPreference();
            $getcarType=$obj_car->where('ct_id',$carType_id)->first();
            $car=$getcarType['ct_type'];

            $obj_trip= new Triptype();
            $gettripType=$obj_trip->where('trt_id',$tripType_id)->first();
            $trip=$gettripType['trt_type'];

            if($tripType_id==2){
                $tr='<tr bgcolor="#ffffff">
                <td>Return Time:</td>
                <td>'.$returntime.'</td>
            </tr><tr bgcolor="#ffffff">
            <td>Return Routing Detail:</td>
            <td>From:'.$booking_to.'<br> To:'.$booking_from.'<br> Stops:'.$booking_stop.'
        </tr>';
            }else{
                $tr='';
            }

            $obj_book= new Booktype();
            $getbookType=$obj_book->where('bt_id',$bookType_id)->first();
            $bookType=$getbookType['bt_type'];
           
            $email = \Config\Services::email();
            $bookmail='noreply@verticserp.com';
            $bookname='No-reply';
            $email->setFrom($bookmail, $bookname);
            $email->setTo('booking@prominentlimo.com');            
            $email->setCC('bookingprominentlimo@gmail.com');
            $email->setSubject('New Booking From '.$companyName);
             $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                <p>
                                                Hello , <br>
                                            </p>
                                             
                                            <p>
                                                New booking received from '.$companyName.' . And booking done by '.$bookingname .'
                                            </p>
                                                   
                                                    
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Booking Number # '.$insert_id.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Pick-up Date:</td>
                                                            <td>'.$booking_datem.'</td>
                                                        </tr>
                                                         <tr bgcolor="#ffffff">
                                                            <td>Pick-up Time:</td>
                                                            <td>'.$booking_time.'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Routing Detail:</td>
                                                            <td>From:'.$booking_from.'<br> To:'.$booking_to.'<br> Stops:'.$booking_stop.'
                                                        </tr>
                                                        
                                                        <tr bgcolor="#ffffff">
                                                            <td>Trip type:</td>
                                                            <td>'.$trip.'</td>
                                                        </tr>'.$tr.'
                                                        <tr bgcolor="#ffffff">
                                                            <td>Car preferences:</td>
                                                            <td>'.$car.'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Booking Type:</td>
                                                            <td>'.$bookType.'</td>
                                                        </tr>
                                                                                                      
                                                   </table>
                                                        
                                                    </table>
                                                    <p>
                                                    
                                                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                    
            $email->setMessage($message); 
          
            if($email->send()){
                
            }else{
                $err=$email->printDebugger(['headers']);
                //print_r($err);
                
            }
                            
            return redirect()->to(base_url('dashboard'))->with('success','Your booking has been received. we will get back to you shortly');
           
        }else{
           return redirect()->back()->with('fail','Booking failed');  
        }      
        
       endif;
    }

    public function delete($bookID)
    {
        $obj_book = new TripBooking();
        $obj_pass= new Passengers();
        $query_del=$obj_book->where('booking_id', $bookID)->delete();
        if($query_del){
            
                $obj_pass->where('booking_id', $bookID)->delete();
                return redirect()->to(base_url('dashboard'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('dashboard'))->with('fail','Deletion failed!!');
        }
    }
    public function deleteBooking($bookID)
    {
        $obj_book = new TripBooking();
        $obj_pass= new Passengers();
        $obj_job=new Jobcard();
        $query_del=$obj_book->where('booking_id', $bookID)->delete();
        if($query_del){
                $obj_pass->where('booking_id', $bookID)->delete();
                $obj_job->where('booking_id', $bookID)->delete();
                return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('fail','Deletion failed!!');
        }
    }
    public function deletBooking($bookID)
    {
        $obj_book = new TripBooking();
        $obj_pass= new Passengers();
        $obj_job=new Jobcard();
        $query_del=$obj_book->where('booking_id', $bookID)->delete();
        if($query_del){
                $obj_pass->where('booking_id', $bookID)->delete();
                $obj_job->where('booking_id', $bookID)->delete();
                return redirect()->to(base_url('booking/viewCorporateBooking/'.session()->get('corAdmincat')))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('booking/viewCorporateBooking/'.session()->get('corAdmincat')))->with('fail','Deletion failed!!');
        }
    }
    public function approve($bookID){
        $obj_book = new TripBooking();
        $status=$this->request->getPost('status');       
        $data=['cadmin_approval'=>$status,
                'booking_cadmin_date'=>date('Y-m-d')];
        if($status==2){
            $reason=$this->request->getPost('reason');
            $data['cadmin_reason_cancel']=$reason;
        }else if($status==1){
            $data['cadmin_reason_cancel']='';
        }
        $update_query=$obj_book->update($bookID,$data);
        if($update_query){
            if($status==1){
                return redirect()->to(base_url('dashboard'))->with('success','Approved!!');
            }else if($status==2){
                return redirect()->to(base_url('dashboard'))->with('success','Cancelled!!'); 
            }
        }else{
            return redirect()->to(base_url('dashboard'))->with('fail','Operation failed!!Please Try again');
        }

    }

    public function view($cat)
    {
        $userArray=$this->show();
        session()->set('Admincat',$cat);
        
        $data=[
            'active'=>'view',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'View Trip Bookings',
            'cat'=>$cat            
        ];
        $obj_trip=new TripBooking();
        if($cat=='all'){
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                          
        }
        
        if($cat=='new'){
            $in = ['0', '3'];
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->whereIn('sadmin_approval', $in)->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->whereIn('sadmin_approval', $in)->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                          
        }

        if($cat=='assign'){
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval','1')->where('assign_dr_supp','1')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager']=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval','1')->where('assign_dr_supp','1')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                          
        }

        if($cat=='notAssign'){
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval','1')->where('assign_dr_supp','0')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager']=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval','1')->where('assign_dr_supp','0')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                                                    
        }

        if($cat=='complete'){
            $in = ['4', '5'];
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->whereIn('sadmin_approval', $in)->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->whereIn('sadmin_approval', $in)->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                          
        }

        if($cat=='cancel'){
            
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval', '2')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->paginate(20);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->where('sadmin_approval', '2')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->pager;                          
        }

        return view('dashboard/tripsView', $data);
    }
    public function assign($bookID){
        $obj_book = new TripBooking();
        $data=['sadmin_approval'=>1,
                'booking_sadmin_date'=>date('Y-m-d')];
        $update_query=$obj_book->update($bookID,$data);
        if($update_query){
            return redirect()->to(base_url('dashboard'))->with('success','Approved!!');
        }else{
            return redirect()->to(base_url('dashboard'))->with('fail','Operation failed!!Please Try again');
        }

    }
    
    //edit booking of corporate user        

    public function edit($bookID)
    {
      
       if($_POST):       
        $carType_id=$this->request->getPost('carPreference');
        //$bookType_id=$this->request->getPost('bookType');
        $booking_date=$this->request->getPost('datepicker');
        $booking_timehr=$this->request->getPost('pickuptimehr');
        $booking_timemin=$this->request->getPost('pickuptimemin');
        $booking_time=$booking_timehr.':'.$booking_timemin;
        $tripType_id=$this->request->getPost('trip');
        $booking_from=$this->request->getPost('from');
        $booking_to=$this->request->getPost('to');
        $numstops=$this->request->getPost('numadstop');
        if($numstops!=0){
        $stops=$this->request->getPost('addmore');
        $lengthstops=count($stops);
        if($lengthstops>0){
        foreach($stops as $stop){
            if($stop!=''){
                $book_stops[]=$stop;
            }
        }        
        $booking_stop= implode("-*-",$book_stops);
        }else{
            $booking_stop= '';   
        }
        }else{
            $booking_stop= '';
        }
        $booking_NoPassegers=$this->request->getPost('passengers');
        $booking_department=$this->request->getPost('department');
        $booking_projectCode=$this->request->getPost('project_code');
        $task_code=$this->request->getPost('task_code');
        $driver_note=$this->request->getPost('driver_note');
       //passengers details
       
        $date= date('Y-m-d');
        
        
        $values=['carType_id'=>$carType_id, 
                 'booking_date'=>$booking_date,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>$tripType_id,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers,
                 'booking_department'=>$booking_department,
                 'booking_projectCode'=>$booking_projectCode,
                 'driver_note'=>$driver_note,
                 'booking_taskCode'=>$task_code];  
        
        if($booking_date==$date) {
            $values['bookType_id']=1;
        }else{
            $values['bookType_id']=2;
        }               
                 
                 if($tripType_id==2){
                    $returntimehr=$this->request->getPost('returntimehr');
                    $returntimemin=$this->request->getPost('returntimemin');
                    $returntime=$returntimehr.':'.$returntimemin;
                    $values['booking_return_time']=$returntime;
                }
                if($booking_projectCode!=''){
                    $values['cadmin_approval']=1;
                    $values['booking_cadmin_date']=$date;
                }
               
        $obj_update=new TripBooking();
        $select_query=$obj_update->where('booking_id',$bookID)->first();
        $sadmin_app=$select_query['sadmin_approval'];
        if($cadmin_app==2){
            $values['cadmin_approval']=3;
        }
        if($sadmin_app!=1){
        $update_query=$obj_update->update($bookID,$values);
        
        if($update_query){
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $obj_passenger= new Passengers(); 
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerLocation=$this->request->getPost('passengerLocation');
            $passengerID=$this->request->getPost('passengerID');
            
            $remove=explode(',',$this->request->getPost('removeId'));
          
            $diff=array_diff($remove,$passengerID);
           
            foreach($diff as $dif){
               $obj_passenger->where('passenger_id', $dif)->delete(); 
            }
                      
            
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $location=$passengerLocation[$i];
                $id=$passengerID[$i];
                
                if(($name!='')||($contact!='')){
                 if($id!=''){
                     $data=['passenger_name'=>$name, 
                            'passenger_contact'=>$contact,
                            'passenger_location'=>$location
                           ];
                     $obj_passenger->update($id,$data);
                 }else{
                    $data=['passenger_name'=>$name, 
                           'passenger_contact'=>$contact,
                           'passenger_location'=>$location, 
                           'booking_id'=>$bookID];
                    $obj_passenger->insert($data);
                 }
                }else{
                    if($id!=''){
                        $obj_passenger->where('passenger_id', $id)->delete(); 
                    }
                }
            }
            }else{
                $obj_passenger= new Passengers();  
                $obj_passenger->where('booking_id', $bookID)->delete(); 
            }
            return redirect()->to(base_url('dashboard'))->with('success','Booking updated successfully');

        }else{
            return redirect()->back()->with('fail','Updating booking failed');  
        }      
    }else{
        return redirect()->back()->with('fail','You could not update now');  
    }
    else:
        $userArray=$this->show();
        $car_obj=new CarPreference();
        $sel_query_car=$car_obj->findAll();
        $bookType_obj=new Booktype();
        $sel_query_book=$bookType_obj->findAll();
        $obj_tripType=new Triptype();
        $sel_query_trip=$obj_tripType->findAll();
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->where('booking_id',$bookID)->first();                          
        $data=[
            'active'=>'book',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Edit Booking',
            'carType'=>$sel_query_car,
            'bookType'=>$sel_query_book,
            'tripType'=>$sel_query_trip,
            'tripdetails'=>$getTrips
        ];

        return view('dashboard/trip_book_edit', $data);
    endif;
    }

    //edit booking of regular customers
    public function editTrip($bookID)
    {
       
        if($_POST):
       
            $carType_id=$this->request->getPost('carPreference');
            $bookType_id=$this->request->getPost('bookType');
            $booking_date=$this->request->getPost('datepicker');
            $booking_timehr=$this->request->getPost('pickuptimehr');
            $booking_timemin=$this->request->getPost('pickuptimemin');
            $booking_time=$booking_timehr.':'.$booking_timemin;
            $tripType_id=$this->request->getPost('trip');
            $booking_from=$this->request->getPost('from');
            $booking_to=$this->request->getPost('to');
            $numstops=$this->request->getPost('numadstop');
            if($numstops!=0){
            $stops=$this->request->getPost('addmore');
            $lengthstops=count($stops);
            if($lengthstops>0){
            foreach($stops as $stop){
                if($stop!=''){
                    $book_stops[]=$stop;
                }
            }        
            $booking_stop= implode("-*-",$book_stops);
            }else{
                $booking_stop= '';   
            }
            }else{
                $booking_stop= '';
            }
            $booking_NoPassegers=$this->request->getPost('passengers');
            $driver_note=$this->request->getPost('driver_note');
            
           //passengers details
           
            //$date= date('Y-m-d');
            
            $values=['carType_id'=>$carType_id,
                     'bookType_id'=>$bookType_id, 
                     'booking_date'=>$booking_date,
                     'booking_time'=>$booking_time,
                     'tripType_id'=>$tripType_id,
                     'booking_from'=>$booking_from,
                     'booking_to'=>$booking_to,
                     'booking_stop'=>$booking_stop,
                     'booking_NoPassengers'=>$booking_NoPassegers,
                     'driver_note'=>$driver_note                                   
                     ]; 
            if($tripType_id==2){
            
                $returntimehr=$this->request->getPost('returntimehr');
                $returntimemin=$this->request->getPost('returntimemin');
                $returntime=$returntimehr.':'.$returntimemin;
                $values['booking_return_time']=$returntime;
                
            }
            $obj_update=new TripBooking();
            $select_query=$obj_update->where('booking_id',$bookID)->first();
            $sadmin_app=$select_query['sadmin_approval'];
            if($sadmin_app==2){
                $values['sadmin_approval']=3;
            }
            if($sadmin_app!=1){
            $update_query=$obj_update->update($bookID,$values);
            
            if($update_query){
                $numpass=$this->request->getPost('numpass');
                if($numpass !=0){
                $obj_passenger= new Passengers(); 
                $passengerName=$this->request->getPost('passengerName');
                $length=count($passengerName);
                $passengerContact=$this->request->getPost('passengerContact');
                $passengerID=$this->request->getPost('passengerID');
                
                $remove=explode(',',$this->request->getPost('removeId'));
              
                $diff=array_diff($remove,$passengerID);
               
                foreach($diff as $dif){
                   $obj_passenger->where('passenger_id', $dif)->delete(); 
                }
                          
                
                for($i=0;$i<$length;$i++){
                    $name=$passengerName[$i];
                    $contact=$passengerContact[$i];
                    $id=$passengerID[$i];
                    
                    if(($name!='')||($contact!='')){
                     if($id!=''){
                         $data=['passenger_name'=>$name, 
                                'passenger_contact'=>$contact
                               ];
                         $obj_passenger->update($id,$data);
                     }else{
                        $data=['passenger_name'=>$name, 
                        'passenger_contact'=>$contact, 
                        'booking_id'=>$bookID];
                        $obj_passenger->insert($data);
                     }
                    }else{
                        if($id!=''){
                            $obj_passenger->where('passenger_id', $id)->delete(); 
                        }
                    }
                }
                }else{
                    $obj_passenger= new Passengers();  
                    $obj_passenger->where('booking_id', $bookID)->delete(); 
                }
                return redirect()->to(base_url('dashboard'))->with('success','Booking updated successfully');
    
            }else{
                return redirect()->back()->with('fail','Updating booking failed');  
            }      
        }else{
            return redirect()->back()->with('fail','You could not update now');  
        }   
        else:
            $userArray=$this->show();
            $car_obj=new CarPreference();
            $sel_query_car=$car_obj->findAll();
            $bookType_obj=new Booktype();
            $sel_query_book=$bookType_obj->findAll();
            $obj_tripType=new Triptype();
            $sel_query_trip=$obj_tripType->findAll();
            $obj_trip=new TripBooking();
            $getTrips=$obj_trip->where('booking_id',$bookID)->first();                          
            $data=[
                'active'=>'index',
                'userID'=>$userArray['user_id'],
                'status'=>$userArray['status'],
                'header'=>'Edit Booking',
                'carType'=>$sel_query_car,
                'bookType'=>$sel_query_book,
                'tripType'=>$sel_query_trip,
                'tripdetails'=>$getTrips
            ];
    
            return view('dashboard/reg_trip_book_edit', $data);
        endif;
    }

    
    //corporate admin edit booking of corporate user        

    public function editBooking($bookID)
    {
      
       if($_POST):
       
        $carType_id=$this->request->getPost('carPreference');
       // $bookType_id=$this->request->getPost('bookType');
        $booking_date=$this->request->getPost('datepicker');
        $booking_timehr=$this->request->getPost('pickuptimehr');
        $booking_timemin=$this->request->getPost('pickuptimemin');
        $booking_time=$booking_timehr.':'.$booking_timemin;
        $tripType_id=$this->request->getPost('trip');
        $booking_from=$this->request->getPost('from');
        $booking_to=$this->request->getPost('to');
        $numstops=$this->request->getPost('numadstop');
        if($numstops!=0){
        $stops=$this->request->getPost('addmore');
        $lengthstops=count($stops);
        if($lengthstops>0){
        foreach($stops as $stop){
            if($stop!=''){
                $book_stops[]=$stop;
            }
        }        
        $booking_stop= implode("-*-",$book_stops);
        }else{
            $booking_stop= '';   
        }
        }else{
            $booking_stop= '';
        }
        $booking_NoPassegers=$this->request->getPost('passengers');
        $booking_department=$this->request->getPost('department');
        
        $booking_projectCode=$this->request->getPost('project_code');
        $driver_note=$this->request->getPost('driver_note');
        
       //passengers details
       
        $date= date('Y-m-d');
        
        $values=['carType_id'=>$carType_id, 
                 'booking_date'=>$booking_date,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>$tripType_id,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers,
                 'booking_department'=>$booking_department,
                 'booking_projectCode'=>$booking_projectCode,
                 'driver_note'=>$driver_note,                 
                 ]; 
                 if($booking_date==$date) {
                    $values['bookType_id']=1;
                }else{
                    $values['bookType_id']=2;
                }  
                 if($tripType_id==2){
                    $returntimehr=$this->request->getPost('returntimehr');
                    $returntimemin=$this->request->getPost('returntimemin');
                    $returntime=$returntimehr.':'.$returntimemin;
                    $values['booking_return_time']=$returntime;
                }
                $obj_update=new TripBooking();
                $select_query=$obj_update->where('booking_id',$bookID)->first();
                $sadmin_app=$select_query['sadmin_approval'];
                if($sadmin_app==2){
                    $values['sadmin_approval']=3;
                }
                if($sadmin_app!=1){
             
        $update_query=$obj_update->update($bookID,$values);
        
        if($update_query){
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $obj_passenger= new Passengers(); 
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerID=$this->request->getPost('passengerID');
            
            $remove=explode(',',$this->request->getPost('removeId'));
          
            $diff=array_diff($remove,$passengerID);
           
            foreach($diff as $dif){
               $obj_passenger->where('passenger_id', $dif)->delete(); 
            }
                      
            
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $id=$passengerID[$i];
                
                if(($name!='')||($contact!='')){
                 if($id!=''){
                     $data=['passenger_name'=>$name, 
                            'passenger_contact'=>$contact
                           ];
                     $obj_passenger->update($id,$data);
                 }else{
                    $data=['passenger_name'=>$name, 
                    'passenger_contact'=>$contact, 
                    'booking_id'=>$bookID];
                    $obj_passenger->insert($data);
                 }
                }else{
                    if($id!=''){
                        $obj_passenger->where('passenger_id', $id)->delete(); 
                    }
                }
            }
            }else{
                $obj_passenger= new Passengers();  
                $obj_passenger->where('booking_id', $bookID)->delete(); 
            }
            return redirect()->to(base_url('booking/viewCorporateBooking/'.session()->get('corAdmincat')))->with('success','Booking updated successfully');

        }else{
            return redirect()->back()->with('fail','Updating booking failed');  
        }   
    }else{
        return redirect()->back()->with('fail','You could not update now');  
    }
    else:
        $userArray=$this->show();
        $car_obj=new CarPreference();
        $sel_query_car=$car_obj->findAll();
        $bookType_obj=new Booktype();
        $sel_query_book=$bookType_obj->findAll();
        $obj_tripType=new Triptype();
        $sel_query_trip=$obj_tripType->findAll();
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->where('booking_id',$bookID)->first();                          
        $data=[
            'active'=>'book',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Edit Booking',
            'carType'=>$sel_query_car,
            'bookType'=>$sel_query_book,
            'tripType'=>$sel_query_trip,
            'tripdetails'=>$getTrips
        ];

        return view('dashboard/trip_book_edit', $data);
    endif;
    }


    //prominent edit booking of regular customers 
    public function regularEditTrip($bookID)
    {
       
        if($_POST):
       
            $carType_id=$this->request->getPost('carPreference');
            $bookType_id=$this->request->getPost('bookType');
            $booking_date=$this->request->getPost('datepicker');
            $booking_timehr=$this->request->getPost('pickuptimehr');
            $booking_timemin=$this->request->getPost('pickuptimemin');
            $booking_time=$booking_timehr.':'.$booking_timemin;
            $tripType_id=$this->request->getPost('trip');
            $booking_from=$this->request->getPost('from');
            $booking_to=$this->request->getPost('to');
            $numstops=$this->request->getPost('numadstop');
            if($numstops!=0){
            $stops=$this->request->getPost('addmore');
            $lengthstops=count($stops);
            if($lengthstops>0){
            foreach($stops as $stop){
                if($stop!=''){
                    $book_stops[]=$stop;
                }
            }        
            $booking_stop= implode("-*-",$book_stops);
            }else{
                $booking_stop= '';   
            }
            }else{
                $booking_stop= '';
            }
            $booking_NoPassegers=$this->request->getPost('passengers');
            $driver_note=$this->request->getPost('driver_note');
            
           //passengers details
           
            //$date= date('Y-m-d');
            
            $values=['carType_id'=>$carType_id,
                     'bookType_id'=>$bookType_id, 
                     'booking_date'=>$booking_date,
                     'booking_time'=>$booking_time,
                     'tripType_id'=>$tripType_id,
                     'booking_from'=>$booking_from,
                     'booking_to'=>$booking_to,
                     'booking_stop'=>$booking_stop,
                     'booking_NoPassengers'=>$booking_NoPassegers,
                     'driver_note'=>$driver_note                                  
                     ]; 
                     if($tripType_id==2){
                        $returntimehr=$this->request->getPost('returntimehr');
                        $returntimemin=$this->request->getPost('returntimemin');
                        $returntime=$returntimehr.':'.$returntimemin;
                        $values['booking_return_time']=$returntime;
                    }
            $obj_update=new TripBooking();
            $select_query=$obj_update->where('booking_id',$bookID)->first();
           
            $update_query=$obj_update->update($bookID,$values);
            
            if($update_query){
                $numpass=$this->request->getPost('numpass');
                if($numpass !=0){
                $obj_passenger= new Passengers(); 
                $passengerName=$this->request->getPost('passengerName');
                $length=count($passengerName);
                $passengerContact=$this->request->getPost('passengerContact');
                $passengerID=$this->request->getPost('passengerID');
                
                $remove=explode(',',$this->request->getPost('removeId'));
              
                $diff=array_diff($remove,$passengerID);
               
                foreach($diff as $dif){
                   $obj_passenger->where('passenger_id', $dif)->delete(); 
                }
                          
                
                for($i=0;$i<$length;$i++){
                    $name=$passengerName[$i];
                    $contact=$passengerContact[$i];
                    $id=$passengerID[$i];
                    
                    if(($name!='')||($contact!='')){
                     if($id!=''){
                         $data=['passenger_name'=>$name, 
                                'passenger_contact'=>$contact
                               ];
                         $obj_passenger->update($id,$data);
                     }else{
                        $data=['passenger_name'=>$name, 
                        'passenger_contact'=>$contact, 
                        'booking_id'=>$bookID];
                        $obj_passenger->insert($data);
                     }
                    }else{
                        if($id!=''){
                            $obj_passenger->where('passenger_id', $id)->delete(); 
                        }
                    }
                }
                }else{
                    $obj_passenger= new Passengers();  
                    $obj_passenger->where('booking_id', $bookID)->delete(); 
                }
                return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('success','Booking updated successfully');
    
            }else{
                return redirect()->back()->with('fail','Updating booking failed');  
            }      
       
        else:
            $userArray=$this->show();
            $car_obj=new CarPreference();
            $sel_query_car=$car_obj->findAll();
            $bookType_obj=new Booktype();
            $sel_query_book=$bookType_obj->findAll();
            $obj_tripType=new Triptype();
            $sel_query_trip=$obj_tripType->findAll();
            $obj_trip=new TripBooking();
            $getTrips=$obj_trip->where('booking_id',$bookID)->first();                          
            $data=[
                'active'=>'index',
                'userID'=>$userArray['user_id'],
                'status'=>$userArray['status'],
                'header'=>'Edit Booking',
                'carType'=>$sel_query_car,
                'bookType'=>$sel_query_book,
                'tripType'=>$sel_query_trip,
                'tripdetails'=>$getTrips
            ];
    
            return view('dashboard/reg_trip_book_edit', $data);
        endif;
    }

    //prominent edit of corporate booking 
    public function corporateEditTrip($bookID)
    {
      
       if($_POST):
       
        $carType_id=$this->request->getPost('carPreference');
        //$bookType_id=$this->request->getPost('bookType');
        $booking_date=$this->request->getPost('datepicker');
        $booking_timehr=$this->request->getPost('pickuptimehr');
        $booking_timemin=$this->request->getPost('pickuptimemin');
        $booking_time=$booking_timehr.':'.$booking_timemin;
        $tripType_id=$this->request->getPost('trip');
        $booking_from=$this->request->getPost('from');
        $booking_to=$this->request->getPost('to');
        $numstops=$this->request->getPost('numadstop');
        if($numstops!=0){
        $stops=$this->request->getPost('addmore');
        $lengthstops=count($stops);
        if($lengthstops>0){
        foreach($stops as $stop){
            if($stop!=''){
                $book_stops[]=$stop;
            }
        }        
        $booking_stop= implode("-*-",$book_stops);
        }else{
            $booking_stop= '';   
        }
        }else{
            $booking_stop= '';
        }
        $booking_NoPassegers=$this->request->getPost('passengers');
        $booking_department=$this->request->getPost('department');
        $booking_projectCode=$this->request->getPost('project_code');
        $booking_taskCode=$this->request->getPost('task_code');

        
       //passengers details
       
        $date= date('Y-m-d');
        $driver_note=$this->request->getPost('driver_note');
        $values=['carType_id'=>$carType_id, 
                 'booking_date'=>$booking_date,
                 'booking_time'=>$booking_time,
                 'tripType_id'=>$tripType_id,
                 'booking_from'=>$booking_from,
                 'booking_to'=>$booking_to,
                 'booking_stop'=>$booking_stop,
                 'booking_NoPassengers'=>$booking_NoPassegers,
                 'booking_department'=>$booking_department,
                 'booking_projectCode'=>$booking_projectCode,
                 'booking_taskCode'=>$booking_taskCode,
                 'driver_note'=>$driver_note                 
                 ]; 
                 if($booking_date==$date) {
                    $values['bookType_id']=1;
                }else{
                    $values['bookType_id']=2;
                }  
                 if($tripType_id==2){
                    $returntimehr=$this->request->getPost('returntimehr');
            $returntimemin=$this->request->getPost('returntimemin');
            $returntime=$returntimehr.':'.$returntimemin;
            $values['booking_return_time']=$returntime;
                }
        $obj_update=new TripBooking();
       
        $update_query=$obj_update->update($bookID,$values);
        
        if($update_query){
            $numpass=$this->request->getPost('numpass');
            if($numpass !=0){
            $obj_passenger= new Passengers(); 
            $passengerName=$this->request->getPost('passengerName');
            $length=count($passengerName);
            $passengerContact=$this->request->getPost('passengerContact');
            $passengerID=$this->request->getPost('passengerID');
            
            $remove=explode(',',$this->request->getPost('removeId'));
          
            $diff=array_diff($remove,$passengerID);
           
            foreach($diff as $dif){
               $obj_passenger->where('passenger_id', $dif)->delete(); 
            }
                      
            
            for($i=0;$i<$length;$i++){
                $name=$passengerName[$i];
                $contact=$passengerContact[$i];
                $id=$passengerID[$i];
                
                if(($name!='')||($contact!='')){
                 if($id!=''){
                     $data=['passenger_name'=>$name, 
                            'passenger_contact'=>$contact
                           ];
                     $obj_passenger->update($id,$data);
                 }else{
                    $data=['passenger_name'=>$name, 
                    'passenger_contact'=>$contact, 
                    'booking_id'=>$bookID];
                    $obj_passenger->insert($data);
                 }
                }else{
                    if($id!=''){
                        $obj_passenger->where('passenger_id', $id)->delete(); 
                    }
                }
            }
            }else{
                $obj_passenger= new Passengers();  
                $obj_passenger->where('booking_id', $bookID)->delete(); 
            }
            return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('success','Booking updated successfully');

        }else{
            return redirect()->back()->with('fail','Updating booking failed');  
        }      
    
    else:
        $userArray=$this->show();
        $car_obj=new CarPreference();
        $sel_query_car=$car_obj->findAll();
        $bookType_obj=new Booktype();
        $sel_query_book=$bookType_obj->findAll();
        $obj_tripType=new Triptype();
        $sel_query_trip=$obj_tripType->findAll();
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->where('booking_id',$bookID)->first();                          
        $data=[
            'active'=>'book',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Edit Booking',
            'carType'=>$sel_query_car,
            'bookType'=>$sel_query_book,
            'tripType'=>$sel_query_trip,
            'tripdetails'=>$getTrips
        ];

        return view('dashboard/trip_book_edit', $data);
    endif;
    }

    //Prominent Approve and assign 
    public function approve_assign($bookID)
    {
        if($_POST){
            $status=$this->request->getPost('status');  
            if($status==1){
                $date= date('Y-m-d');
                $booking_amount=$this->request->getPost('booking_amount'); 
                $data=[ 'sadmin_approval'=>$status,
                         'sadmin_reason_cancel'=>'',
                         'booking_sadmin_date'=>$date,
                        'booking_amount'=>$booking_amount]; 
                $data2=['booking_id'=>$bookID,
                        'assigned_date'=>$date,
                        'active'=>1];

                $assigntype=$this->request->getPost('assigntype'); 
                if($assigntype=='dr'){
                    $driverid=$this->request->getPost('driver'); 
                    $data2['driver_id']=$driverid;   
                    $data2['supplier_id']=0;  
                    if(trim($driverid)==''){
                    $data['assign_dr_supp']=0;  
                    }else{
                     $data['assign_dr_supp']=1;    
                    }
                }
                if($assigntype=='sp'){
                    $supplierid=$this->request->getPost('supplier'); 
                    $data2['supplier_id']=$supplierid;     
                    $data2['driver_id']=0;     
                    if(trim($supplierid)==''){
                    $data['assign_dr_supp']=0;  
                    }else{
                     $data['assign_dr_supp']=1;    
                    }        
                }
                $obj_book=new TripBooking();
                $obj_job= new Jobcard();
                $update_query=$obj_book->update($bookID,$data);
                $select=$obj_job->where('booking_id',$bookID)->find();               
                
                if(sizeof($select)>0){
                   
                $update_query2=$obj_job->set($data2)->where('booking_id',$bookID)->update(); 
                }else{
                $query_insert=$obj_job->insert($data2);
                }
                
                $obj_trip=new TripBooking();
                //echo $bookID;
                $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('booking_id',$bookID)->first();
                           // print_r($getTrips);   
                $toEmail=$getTrips['cor_email'];
               
                $toName=$getTrips['cor_name'];
                 $obj_passenger= new Passengers();
                $getpass=$obj_passenger->where('booking_id',$bookID)->findAll();
                $name='';
                

                foreach($getpass as $pass){
                    $name= $name.$pass['passenger_name'].'&nbsp;&nbsp;&nbsp;'.$pass['passenger_contact'].' </br> ';
                }
           

                if($assigntype=='dr'){
                    $obj_job= new Jobcard();
                
                $getDriver=$obj_job->join('drivers','drivers.driver_id=job_card.driver_id')->where('booking_id',$bookID)->first();
               // print_r($getDriver);
               
                    $email = \Config\Services::email();
                    $bookmail='noreply@verticsonline.com';
                    $bookname='No-reply';
                    $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                /* border: 1px solid #89a3c3;
                                border-left: 25px solid #3969a5; */
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            <tr>
                                                <td bgcolor="#ffffff" align="left"> 
                                                    <table width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="right"> <br>                              
                                                                <h2><span>Call : +971 26441013, +971 553415371  <br>
                                                                    Email: booking@prominentlimo.com</span> 
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                <td>
                                                        
                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff"><br>   
                                                <img src="http://prominentlimo.com/images/banner.jpg" alt="Prominent Limousin">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                    <p>
                                                        Hello '.$toName.', <br>
                                                    </p>
                                                    <h1>Greetings from Prominent Limousine!!</h1>    
                                                    <p>
                                                        Many thanks for booking with Prominent Limousine, we are pleased to confirm the booking as below
                                                    </p>
                                                    
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Confirmation Summary For '.$bookID.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Passenger(s):</td>
                                                            <td>'.$name.'</td>
                                                        </tr>

                                                        <tr bgcolor="#eeeeee">
                                                            <td>Pick-up Date:</td>
                                                            <td>'.$getTrips["booking_date"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Pick-up Time:</td>
                                                            <td>'.$getTrips["booking_date"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Service Type:</td>
                                                            <td>'.$getTrips["trt_type"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Vehicle Type:</td>
                                                            <td>'.$getTrips["ct_type"].'</td>
                                                        </tr>
                                                        
                                                        <tr bgcolor="#ffffff">
                                                            <td>Routing Detail:</td>
                                                            <td>From:'.$getTrips["booking_from"].'</br> To:'.$getTrips["booking_to"].'</br> Stops'.$getTrips["booking_stop"].'
                                                            </td>
                                                        </tr>
                                                        
                                                       
                                                        <tr bgcolor="#ffffff">
                                                            <td>Notes</td>
                                                            <td>'.$getTrips["driver_note"].'</td>
                                                        </tr>
                                                        
                                                        
                                                    </table>
                                                    <p>
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Assigned Driver Details For #'.$bookID.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Driver Name:</td>
                                                            <td>'.$getDriver["driver_name"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Contact Number :</td>
                                                            <td>'.$getDriver["driver_contact"].'</td>
                                                        </tr>
                                                       
                                                    </table>
                                                    <p>
                                                        <br>
                                                        If you have any queries, please don’t hesitate to get in touch with me.<br> </p>                                   
                                                        
                                                        <p><strong>Best regards,</strong></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="left">
                                                    <table style="border-top:1px solid #8e7a3d;" width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/mailer-logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="left"> 
                                                                <h3><strong>Operation Team</strong></h3>                               
                                                                <h2>Land Line: <strong>+971 26441013</strong> &nbsp;&nbsp; Operation: <strong>+971 553415371</strong> &nbsp;&nbsp; <br>
                                                                    Email: <strong>booking@prominentlimo.com</strong> &nbsp;&nbsp; <strong>www.prominentlimo.com</strong>
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center">
                                                    <h2><br>Copyright © 2022 Prominent Limousin. All rights reserved.</h2>
                                                </td>
                                            </tr>
                            
                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                    //echo $toEmail;
                   // echo $message;
                    $email->setFrom($bookmail, $bookname);
                    $email->setTo($toEmail);
                    $email->setCC('prominentlimo@gmail.com');
                    $email->setSubject('The driver has been assigned for the booking no:'.$bookID);
                    $email->setMessage($message);
                    if($email->send()){
                       // echo "send";
                    }else{
                        $err=$email->printDebugger(['headers']);
                        //print_r($err);
                    }
              
               
                    
                    
                }else if($assigntype=='sp'){
                   $email = \Config\Services::email();
                    $bookmail='noreply@verticsonline.com';
                    $bookname='No-reply';
                    $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                /* border: 1px solid #89a3c3;
                                border-left: 25px solid #3969a5; */
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            <tr>
                                                <td bgcolor="#ffffff" align="left"> 
                                                    <table width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="right"> <br>                              
                                                                <h2><span>Call : +971 26441013, +971 553415371  <br>
                                                                    Email: booking@prominentlimo.com</span> 
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                <td>
                                                        
                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff"><br>   
                                                <img src="http://prominentlimo.com/images/banner.jpg" alt="Prominent Limousin">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                    <p>
                                                        Hello '.$toName.', <br>
                                                    </p>
                                                    <h1>Greetings from Prominent Limousine!!</h1>    
                                                    <p>
                                                        Many thanks for booking with Prominent Limousine, we are pleased to confirm the booking as below
                                                    </p>
                                                    
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Confirmation Summary For '.$bookID.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                        <td>Passenger(s):</td>
                                                        <td>'.$name.'</td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Pick-up Date:</td>
                                                            <td>'.$getTrips["booking_date"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Pick-up Time:</td>
                                                            <td>'.$getTrips["booking_date"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Service Type:</td>
                                                            <td>'.$getTrips["trt_type"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Vehicle Type:</td>
                                                            <td>'.$getTrips["ct_type"].'</td>
                                                        </tr>
                                                       
                                                        <tr bgcolor="#ffffff">
                                                            <td>Routing Detail:</td>
                                                            <td>From:'.$getTrips["booking_from"].'</br> To:'.$getTrips["booking_to"].'</br> Stops'.$getTrips["booking_stop"].'
                                                            </td>
                                                        </tr>
                                                        
                                                       
                                                        <tr bgcolor="#ffffff">
                                                            <td>Notes</td>
                                                            <td>'.$getTrips["driver_note"].'</td>
                                                        </tr>
                                                    </table>
                                                    <p>
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">The driver has been assigned for the booking no: #'.$bookID.'</h3></td>
                                                        </tr>
                                                       
                                                    </table>
                                                    <p>
                                                        <br>
                                                        If you have any queries, please don’t hesitate to get in touch with me.<br> </p>                                   
                                                        
                                                        <p><strong>Best regards,</strong></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="left">
                                                    <table style="border-top:1px solid #8e7a3d;" width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/mailer-logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="left"> 
                                                                <h3><strong>Operation Team</strong></h3>                               
                                                                <h2>Land Line: <strong>+971 26441013</strong> &nbsp;&nbsp; Operation: <strong>+971 553415371</strong> &nbsp;&nbsp; <br>
                                                                    Email: <strong>booking@prominentlimo.com</strong> &nbsp;&nbsp; <strong>www.prominentlimo.com</strong>
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center">
                                                    <h2><br>Copyright © 2022 Prominent Limousin. All rights reserved.</h2>
                                                </td>
                                            </tr>
                            
                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                    //echo $toEmail;
                   // echo $message;
                    $email->setFrom($bookmail, $bookname);
                    $email->setTo($toEmail);
                    $email->setCC('prominentlimo@gmail.com');
                    $email->setSubject('The driver has been assigned for the booking no:'.$bookID);
                    $email->setMessage($message);
                    if($email->send()){
                       // echo "send";
                    }else{
                        $err=$email->printDebugger(['headers']);
                        //print_r($err);
                    }
              
               
                }else{

                      $email = \Config\Services::email();
                    $bookmail='noreply@verticsonline.com';
                    $bookname='No-reply';
                    $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                /* border: 1px solid #89a3c3;
                                border-left: 25px solid #3969a5; */
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            <tr>
                                                <td bgcolor="#ffffff" align="left"> 
                                                    <table width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="right"> <br>                              
                                                                <h2><span>Call : +971 26441013, +971 553415371  <br>
                                                                    Email: booking@prominentlimo.com</span> 
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                <td>
                                                        
                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff"><br>   
                                                <img src="http://prominentlimo.com/images/banner.jpg" alt="Prominent Limousin">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                <p>
                                                Hello '.$toName.', <br>
                                                </p>
                                                    <h1>Greetings from Prominent Limousine!!</h1>    
                                                    <p>
                                                        Many thanks for booking with Prominent Limousine, we are pleased to confirm the booking as below
                                                    </p>
                                                    
                                                    <table bgcolor="#999999" cellpadding="15" cellspacing="1">
                                                        <tr bgcolor="#fffed1">
                                                            <td colspan="2"><h3 style="margin:0">Confirmation Summary For #'.$bookID.'</h3></td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Passenger(s):</td>
                                                             <td>'.$name.'</td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Pick-up Date:</td>
                                                            <td>'.$getTrips["booking_date"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Pick-up Time:</td>
                                                           <td>'.$getTrips["booking_time"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#ffffff">
                                                            <td>Service Type:</td>
                                                            <td>'.$getTrips["trt_type"].'</td>
                                                        </tr>
                                                        <tr bgcolor="#eeeeee">
                                                            <td>Vehicle Type:</td>
                                                            <td>'.$getTrips["ct_type"].'</td>
                                                        </tr>
                                                        
                                                        <tr bgcolor="#ffffff">
                                                            <td>Routing Detail:</td>
                                                             <td>From:'.$getTrips["booking_from"].'<br> To:'.$getTrips["booking_to"].'<br> Stops:'.$getTrips["booking_stop"].'
                                                            </td>
                                                        </tr>
                                                        
                                                       
                                                        <tr bgcolor="#ffffff">
                                                            <td>Notes</td>
                                                            <td>'.$getTrips["driver_note"].'</td>
                                                        </tr>
                                                    </table>
                            
                                                    <p>
                                                        Driver details will update you once assigned <br>
                                                        If you have any queries, please don’t hesitate to get in touch with me.<br> </p>                                   
                                                        
                                                        <p><strong>Best regards,</strong></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="left">
                                                    <table style="border-top:1px solid #8e7a3d;" width="100%">
                                                        <tr>
                                                            <td bgcolor="#ffffff" align="left" width="40%"><br>                                           
                                                                <img src="http://prominentlimo.com/images/mailer-logo.png">
                                                            </td>  
                                                            <td bgcolor="#ffffff" align="left"> 
                                                                <h3><strong>Operation Team</strong></h3>                               
                                                                <h2>Land Line: <strong>+971 26441013</strong> &nbsp;&nbsp; Operation: <strong>+971 553415371</strong> &nbsp;&nbsp; <br>
                                                                    Email: <strong>booking@prominentlimo.com</strong> &nbsp;&nbsp; <strong>www.prominentlimo.com</strong>
                                                                </h2>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center">
                                                    <h2><br>Copyright © 2022 Prominent Limousin. All rights reserved.</h2>
                                                </td>
                                            </tr>
                            
                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                   
                    $email->setFrom($bookmail, $bookname);
                    $email->setTo($toEmail);
                    $email->setCC('prominentlimo@gmail.com');
                    $email->setSubject('Booking confirmation from Prominent ');
                    $email->setMessage($message);
                     if($email->send()){
                        //echo "send";
                    }else{
                        $err=$email->printDebugger(['headers']);
                        //print_r($err);
                    }
             //  exit;
               
            }
                return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('success','Job card created');
            }
            if($status==2){
                $obj_book=new TripBooking();
                $obj_job= new Jobcard();
                $reason=$this->request->getPost('reason');
                $date= date('Y-m-d');
                $data=[ 'sadmin_approval'=>$status,
                        'sadmin_reason_cancel'=>$reason,
                        'booking_sadmin_date'=>$date,
                        'booking_amount'=>'']; 
                $update_query=$obj_book->update($bookID,$data);

                $data2['active']=0;
                $update_query2=$obj_job->set($data2)->where('booking_id',$bookID)->update();

                return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('fail','Cancelled');

            }
            if($status==4){
                $obj_book=new TripBooking();
                $obj_job= new Jobcard();
                $date= date('Y-m-d');
                $booking_amount=$this->request->getPost('booking_amount_last'); 
                $remarks=$this->request->getPost('booking_remarks'); 
                $paid=$this->request->getPost('paid'); 
                $data=[ 'sadmin_approval'=>$paid,
                         'sadmin_reason_cancel'=>'',
                         'booking_sadmin_date'=>$date,
                        'booking_amount'=>$booking_amount,
                        'booking_remarks'=>$remarks]; 
                $update_query=$obj_book->update($bookID,$data);

                $data2['active']=0;
                $update_query2=$obj_job->set($data2)->where('booking_id',$bookID)->update();

                return redirect()->to(base_url('booking/view/'.session()->get('Admincat')))->with('success','Trip Completed');

            }

        }else{
           
        $userArray=$this->show();
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('booking_id',$bookID)->first();                          
        $companyid=$getTrips['company_Id'];
        $bookuserid=$getTrips['user_id'];
      
        if($companyid==0){
            $companyName='Regular';
            $obj_reg=new Regular_user();
            $get_user=$obj_reg->where('user_id',$bookuserid)->first();
            $done_by=$get_user['reg_name'];
        }else{
            $obj_cadmin=new CorporateAdmin();
            $get_user=$obj_cadmin->where('cadmin_id',$companyid)->first();
            $companyName=$get_user['cadmin_companyName'];
            $obj_cor=new Corporate_user();
            $get_user=$obj_cor->where('user_id',$bookuserid)->first();
            $done_by= $get_user['cor_name'];
        }
        $obj_supp= new Supplier();
        $getsupp=$obj_supp->find();

        
        $date=$getTrips['booking_date'];
        $time=$getTrips['booking_time'];
        //$return=$getTrips['booking_time'];
        $getFilter=$obj_trip->select('booking_id')->where('booking_date',$date)->where('booking_time',$time)->find();
       
       $driverids=Array();
      
       $obj_job=new Jobcard();
      
        if(sizeof($getFilter)>0){
        foreach($getFilter as $fil){
         
           //$arr=array('booking_id'=> $fil['booking_id'],'active'=>'1');
          
             $get_job=$obj_job->where('booking_id',$fil['booking_id'])->where('active',1)->first();
          
            if(($get_job)>0){
               
                 $driverids[]= $get_job['driver_id'];
            }
                   
         }
        }
        
       
        $obj_driver=new Drivers();
        if(sizeof($driverids)>0){
           
            $getdriver=$obj_driver->whereNotIn('driver_id',$driverids)->find();
        }else{
            $getdriver=$obj_driver->find();  
        }
        
        $getcurrentdriver=$obj_job->where('booking_id',$bookID)->first();
        $driverId=$getcurrentdriver['driver_id'];
        $suppID=$getcurrentdriver['supplier_id'];
        
        if($driverId!=0){
            $currentdriver=$obj_driver->where('driver_id',$driverId)->first();
        }else{
            $currentdriver=0;
        }
        if($suppID!=0){
            $currentsupp=$obj_supp->where('sup_id',$suppID)->first();
        }else{
            $currentsupp=0;
        }
        

        $data=[
            'active'=>'view',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Update status / Assign Job',            
            'tripdetails'=>$getTrips,
            'companyName'=>$companyName,
            'doneBy'=>$done_by,
            'suppliers'=>$getsupp,
            'driverslist'=>$getdriver,
            'currentdriver'=>$currentdriver,
            'currentsupplier'=>$currentsupp
        ];

        return view('dashboard/trip_book_approve_assign', $data);
    }
    }


    //corporate Approve and assign 
    public function approve_assign_corporate($bookID)
    {
        if($_POST){
            $status=$this->request->getPost('status');  
            if($status==1){
                $date= date('Y-m-d');
                $data=[ 'cadmin_approval'=>$status,
                         'cadmin_reason_cancel'=>'',
                         'booking_cadmin_date'=>$date]; 
                         $obj_book=new TripBooking();
                
                         $update_query=$obj_book->update($bookID,$data);
                        
                         return redirect()->to(base_url('booking/viewCorporateBooking/'.session()->get('corAdmincat')))->with('success','Job card created');
            }else{
                $date= date('Y-m-d');
                $reason=$this->request->getPost('reason');  
                $data=[ 'cadmin_approval'=>$status,
                        'cadmin_reason_cancel'=>$reason,
                        'booking_cadmin_date'=>$date];
                        $obj_book=new TripBooking();
                
                        $update_query=$obj_book->update($bookID,$data);  
                return redirect()->to(base_url('booking/viewCorporateBooking/'.session()->get('corAdmincat')))->with('fail','Cancelled');


            }
               
           
        }else{
           
        $userArray=$this->show();
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('booking_id',$bookID)->first();                          
        $companyid=$getTrips['company_Id'];
        $bookuserid=$getTrips['user_id'];
      
        if($companyid==0){
            $companyName='Regular';
            $obj_reg=new Regular_user();
            $get_user=$obj_reg->where('user_id',$bookuserid)->first();
            $done_by=$get_user['reg_name'];
        }else{
            $obj_cadmin=new CorporateAdmin();
            $get_user=$obj_cadmin->where('cadmin_id',$companyid)->first();
            $companyName=$get_user['cadmin_companyName'];
            $obj_cor=new Corporate_user();
            $get_user=$obj_cor->where('user_id',$bookuserid)->first();
            $done_by= $get_user['cor_name'];
        }
      
       
        $data=[
            'active'=>'view',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Update Status',            
            'tripdetails'=>$getTrips,
            'companyName'=>$companyName,
            'doneBy'=>$done_by
            
        ];

        return view('dashboard/trip_book_approve_assign_corporate', $data);
    }
    }

    //corporate View booking
    public function viewCorporateBooking($cat)
    {
       
        $userArray=$this->show();
        session()->set('corAdmincat',$cat);
        
        $data=[
            'active'=>'view',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'View Trip Bookings',
            'cat'=>$cat            
        ];
            $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$userArray['user_id'])->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']); 
            $obj_trip=new TripBooking();
        if($cat=='all'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->paginate(20);                          
            $data['trips']=$getTrips; 
           
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->pager;                          
        }
        if($cat=='bookings'){
            $in = ['0', '2', '3'];

            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->whereIn('sadmin_approval', $in)->paginate(3);                          
            $data['trips']=$getTrips; 
            
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->whereIn('sadmin_approval', $in)->pager;                          
        }
        if($cat=='confirmed'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '1')->paginate(3);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '1')->pager;                          
        }
        if($cat=='cancelled'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '2')->paginate(3);                          
            $data['trips']=$getTrips; 
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '2')->pager;                          
        }
        if($cat=='pending'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '0')->where('cadmin_approval', '1')->paginate(3);                          
            $data['trips']=$getTrips; 
           
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '0')->where('cadmin_approval', '1')->pager;                          
        }
        if($cat=='paid'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '4')->paginate(3);                          
            $data['trips']=$getTrips;             
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '4')->pager;                          
        }
        if($cat=='unpaid'){
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '5')->paginate(3);                          
            $data['trips']=$getTrips;             
            $data['pager'] =$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval', '5')->pager;                          
        }

       
        return view('dashboard/listTrips_adminView', $data);
    }

    //Corporate View Reports
    public function viewReports()
    {
        
        $userArray=$this->show();
        $data=[
            'active'=>'report',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Booking Summery'            
        ];
        $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$userArray['user_id'])->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']); 
        $obj_trip=new TripBooking();
       // $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval','4')->orWhere('sadmin_approval','5')->findAll(); 
       $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->paginate(20);                                                   
        $data['trips']=$getTrips; 
        $data['pager']=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->pager;  
        return view('dashboard/list_reports', $data);
    }
    public function export()
    {
        $userArray=$this->show();
        
        $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$userArray['user_id'])->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']); 
        $obj_trip=new TripBooking();
        //$array_get_trips= array();
       // $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->where('sadmin_approval','4')->orWhere('sadmin_approval','5')->findAll(); 
       $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->findAll();                                                   
     
       $filename = 'booking_reports_'.date('Ymd').'.csv'; 
       header("Content-Description: File Transfer"); 
       header("Content-Disposition: attachment; filename=$filename"); 
       header("Content-Type: application/csv; ");
      
       /* file creation */
       $file = fopen("php://output", 'w');       
       $header = array("Date","Booking ID","User","Pick up time","From","To","Booking Type","Trip Type","Car Preferences","Passengers Details","Department","Project Code","Task code","Trip Amount","Payment Status"); 
       fputcsv($file, $header);  
       foreach ($getTrips as $value){ 
            $getvalue[0]=$value['booking_date'];
            $getvalue[1]=$value['booking_id'];
            $getvalue[2]=$value['cor_name'];
            $getvalue[3]=$value['booking_time'];

            $getvalue[4]=$value['booking_from'];
            $getvalue[5]=$value['booking_to'];
            $getvalue[6]=$value['bt_type'];
            $getvalue[7]=$value['trt_type'];

            $getvalue[8]=$value['ct_type'];
           $obj_passengers=new Passengers();
            $getPassengers=$obj_passengers->where('booking_id',$value['booking_id'])->findAll();
            if(sizeof($getPassengers)>0){                                          
            foreach($getPassengers as $get){
           
            $passenger='';
               if($get['passenger_name']!='') { 
                $passenger .= $get['passenger_name'].'  ';
                } 
                if($get['passenger_contact']!=''){
                    $passenger .= $get['passenger_contact'].'  ';
                } 
                if($get['passenger_location']!=''){
                    $passenger .= $get['passenger_location'];
                } 
            $passenger .= ' ';
            }
            
            }else{
                $passenger='No details';
            }
            
            $getvalue[9]=$passenger;
            $getvalue[10]=$value['booking_department'];
            $getvalue[11]=$value['booking_projectCode'];

            $getvalue[12]=$value['booking_taskCode'];
            $getvalue[13]=$value['booking_amount'];
             
                if($value['sadmin_approval']==4){
                    $pay= "Paid";
                }
                if($value['sadmin_approval']==5){
                    $pay= "Un Paid";
                }
            
            $getvalue[14]=$pay;
            
           fputcsv($file,$getvalue); 
       }
       fclose($file); 
       //exit; 
    }
   
    //For superadmin export codes
    
    public function mainviewReports()
    {
        
        $userArray=$this->show();
        $data=[
            'active'=>'report',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Booking Summery'            
        ];
        $obj_trip=new TripBooking();
        $getTrips=$obj_trip->join('corporate_admin','corporate_admin.cadmin_id=trip_booking.company_Id')->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->paginate(20);                          
        $data['trips']=$getTrips;  
        $data['pager']=$obj_trip->join('corporate_admin','corporate_admin.cadmin_id=trip_booking.company_Id')->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->pager; 
       
        return view('dashboard/main_list_reports', $data);
    }
    public function mainexport()
    {
        $userArray=$this->show();
        
        $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$userArray['user_id'])->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']); 
        $obj_trip=new TripBooking();
        
        $getTrips=$obj_trip->join('corporate_admin','corporate_admin.cadmin_id=trip_booking.company_Id')->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->findAll();                          
     
       $filename = 'booking_reports_'.date('Ymd').'.csv'; 
       header("Content-Description: File Transfer"); 
       header("Content-Disposition: attachment; filename=$filename"); 
       header("Content-Type: application/csv; ");
      
       /* file creation */
       $file = fopen("php://output", 'w');       
       $header = array("Date","Booking ID","User","Pick up time","From","To","Booking Type","Trip Type","Car Preferences","Passengers Details","Department","Project Code","Task code","Trip Amount","Payment Status"); 
       fputcsv($file, $header);  
       foreach ($getTrips as $value){ 
            $getvalue[0]=$value['booking_date'];
            $getvalue[1]=$value['booking_id'];
            $getvalue[2]=$value['cor_name']. "( ".$value['cadmin_companyName']." )";
            $getvalue[3]=$value['booking_time'];

            $getvalue[4]=$value['booking_from'];
            $getvalue[5]=$value['booking_to'];
            $getvalue[6]=$value['bt_type'];
            $getvalue[7]=$value['trt_type'];

            $getvalue[8]=$value['ct_type'];
           $obj_passengers=new Passengers();
            $getPassengers=$obj_passengers->where('booking_id',$value['booking_id'])->findAll();
            if(sizeof($getPassengers)>0){                                          
            foreach($getPassengers as $get){
           
            $passenger='';
               if($get['passenger_name']!='') { 
                $passenger .= $get['passenger_name'].'  ';
                } 
                if($get['passenger_contact']!=''){
                    $passenger .= $get['passenger_contact'].'  ';
                } 
                if($get['passenger_location']!=''){
                    $passenger .= $get['passenger_location'];
                } 
            $passenger .= ' ';
            }
            
            }else{
                $passenger='No details';
            }
            
            $getvalue[9]=$passenger;
            $getvalue[10]=$value['booking_department'];
            $getvalue[11]=$value['booking_projectCode'];

            $getvalue[12]=$value['booking_taskCode'];
            $getvalue[13]=$value['booking_amount'];
             
                if($value['sadmin_approval']==4){
                    $pay= "Paid";
                }
                if($value['sadmin_approval']==5){
                    $pay= "Un Paid";
                }
            
            $getvalue[14]=$pay;
            
           fputcsv($file,$getvalue); 
       }
       fclose($file); 
       //exit; 
    }
  
   

}
?>