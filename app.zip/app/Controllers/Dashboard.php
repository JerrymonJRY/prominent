<?php

namespace App\Controllers;
use App\Models\CorporateAdmin;
use App\Models\Corporate_user;
use App\Models\User;
use App\Models\TripBooking;
use App\Models\Passengers;
use App\Models\Regular_user;
use App\Models\Jobcard;
use App\Models\Drivers;
class Dashboard extends BaseController
{
    public function index(){
              
        $user_id=session()->get('loggeduser');
        $status=session()->get('loggeduserstatus');
        $data=[
            'active'=>'index',
            'userID'=>$user_id,
            'status'=>$status,
        ];
        if($status==1){
            $data['header']='Dashboard';
            session()->set('name','Super Admin'); 
            $obj_trip=new TripBooking();
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->where('cadmin_approval','1')->orWhere('company_id','0')->orderby('assign_dr_supp','asc')->orderby('booking_date','asc')->orderby('booking_time','asc')->findAll();                          
            $data['trips']=$getTrips;
            $obj_trip_curr=new TripBooking();

            $data['total']= $obj_trip_curr->countAllResults();            

            $data['totalReg']=$obj_trip_curr->where('user_type',3)->countAllResults();

            $data['totalCor']=$obj_trip_curr->where('user_type',4)->countAllResults();

            $obj_users= new User();
            $data['totalUsers']=$obj_users->countAllResults();

            $obj_job=new Jobcard();
            $data['jobcards']=$obj_job->countAllResults();

            $obj_driver= new Drivers();
            $data['drivers']=$obj_driver->countAllResults();

            $obj_graph=new TripBooking();
            $curr_year=date('Y');
            $get_graph=$obj_graph->select('count(booking_id) as counter, DATE_FORMAT(booking_date, "%b") as barmonth')->where('YEAR(booking_date)',$curr_year)->groupBy('month(booking_date)')->findAll();
            $array_month[0]['counter']=0;
            $array_month[0]['barmonth']="Jan";
            $array_month[1]['counter']=0;
            $array_month[1]['barmonth']="Feb";
            $array_month[2]['counter']=0;
            $array_month[2]['barmonth']="Mar";
            $array_month[3]['counter']=0;
            $array_month[3]['barmonth']="Apr";
            $array_month[4]['counter']=0;
            $array_month[4]['barmonth']="May";
            $array_month[5]['counter']=0;
            $array_month[5]['barmonth']="Jun";
            $array_month[6]['counter']=0;
            $array_month[6]['barmonth']="Jul";
            $array_month[7]['counter']=0;
            $array_month[7]['barmonth']="Aug";
            $array_month[8]['counter']=0;
            $array_month[8]['barmonth']="Sep";
            $array_month[9]['counter']=0;
            $array_month[9]['barmonth']="Oct";
            $array_month[10]['counter']=0;
            $array_month[10]['barmonth']="Nov";
            $array_month[11]['counter']=0;
            $array_month[11]['barmonth']="Dec";

            foreach($get_graph as $row){
                if($row['barmonth']=='Jan'){
                    $array_month[0]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Feb'){
                    $array_month[1]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Mar'){
                    $array_month[2]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Apr'){
                    $array_month[3]['counter']=$row['counter'];
                }
                if($row['barmonth']=='May'){
                    $array_month[4]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Jun'){
                    $array_month[5]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Jul'){
                    $array_month[6]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Aug'){
                    $array_month[7]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Sep'){
                    $array_month[8]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Oct'){
                    $array_month[9]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Nov'){
                    $array_month[10]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Dec'){
                    $array_month[11]['counter']=$row['counter'];
                }
            
            }
            
            $data['get_graph']=$array_month;

            //Total Ampount graph
            $obj_graph_total=new TripBooking();
            $curr_year=date('Y');
            $get_graph_total=$obj_graph_total->select('SUM(booking_amount) as totalAmount, DATE_FORMAT(booking_date, "%b") as barmonth')->where('YEAR(booking_date)',$curr_year)->groupBy('month(booking_date)')->findAll();
           
            $array_month_total[0]['total']=0;
            $array_month_total[0]['barmonth']="Jan";
            $array_month_total[1]['total']=0;
            $array_month_total[1]['barmonth']="Feb";
            $array_month_total[2]['total']=0;
            $array_month_total[2]['barmonth']="Mar";
            $array_month_total[3]['total']=0;
            $array_month_total[3]['barmonth']="Apr";
            $array_month_total[4]['total']=0;
            $array_month_total[4]['barmonth']="May";
            $array_month_total[5]['total']=0;
            $array_month_total[5]['barmonth']="Jun";
            $array_month_total[6]['total']=0;
            $array_month_total[6]['barmonth']="Jul";
            $array_month_total[7]['total']=0;
            $array_month_total[7]['barmonth']="Aug";
            $array_month_total[8]['total']=0;
            $array_month_total[8]['barmonth']="Sep";
            $array_month_total[9]['total']=0;
            $array_month_total[9]['barmonth']="Oct";
            $array_month_total[10]['total']=0;
            $array_month_total[10]['barmonth']="Nov";
            $array_month_total[11]['total']=0;
            $array_month_total[11]['barmonth']="Dec";

            foreach($get_graph_total as $row){
                if($row['barmonth']=='Jan'){
                    $array_month_total[0]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Feb'){
                    $array_month_total[1]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Mar'){
                    $array_month_total[2]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Apr'){
                    $array_month_total[3]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='May'){
                    $array_month_total[4]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Jun'){
                    $array_month_total[5]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Jul'){
                    $array_month_total[6]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Aug'){
                    $array_month_total[7]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Sep'){
                    $array_month_total[8]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Oct'){
                    $array_month_total[9]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Nov'){
                    $array_month_total[10]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Dec'){
                    $array_month_total[11]['total']=$row['totalAmount'];
                }
            
            }
            
            $data['get_graph_total']=$array_month_total;//booking_amount
//print_r( $data['get_graph_total']);
//exit;



        }
        if($status==2){
            $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$user_id)->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']); 

            $obj_trip=new TripBooking();
            $obj_trip_curr= new TripBooking();
            $getTrips=$obj_trip->join('corporate_users','corporate_users.user_id=trip_booking.user_id')->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('company_Id',$data['companyId'])->findAll();                          
            $data['header']='View Bookings';
            $data['trips']=$getTrips;
            $data['total']= $obj_trip_curr->where('company_Id',$data['companyId'])->countAllResults();
            
            $month=date('m');
            $data['curr_total']=$obj_trip_curr->where('month(booking_date)',$month)->where('company_Id',$data['companyId'])->countAllResults();
           
            $d=strtotime("-1 Months");            
            $prevmonth= date("m", $d);
            $data['prev_total']=$obj_trip_curr->where('company_Id',$data['companyId'])->where('MONTH(booking_date)',$prevmonth)->where('company_Id',$data['companyId'])->countAllResults();                          
           //Monthly wise bookings graph 
            $obj_graph=new TripBooking();
            $curr_year=date('Y');
            $get_graph=$obj_graph->select('count(booking_id) as counter, DATE_FORMAT(booking_date, "%b") as barmonth')->where('company_Id',$data['companyId'])->where('YEAR(booking_date)',$curr_year)->groupBy('month(booking_date)')->findAll();
            $array_month[0]['counter']=0;
            $array_month[0]['barmonth']="Jan";
            $array_month[1]['counter']=0;
            $array_month[1]['barmonth']="Feb";
            $array_month[2]['counter']=0;
            $array_month[2]['barmonth']="Mar";
            $array_month[3]['counter']=0;
            $array_month[3]['barmonth']="Apr";
            $array_month[4]['counter']=0;
            $array_month[4]['barmonth']="May";
            $array_month[5]['counter']=0;
            $array_month[5]['barmonth']="Jun";
            $array_month[6]['counter']=0;
            $array_month[6]['barmonth']="Jul";
            $array_month[7]['counter']=0;
            $array_month[7]['barmonth']="Aug";
            $array_month[8]['counter']=0;
            $array_month[8]['barmonth']="Sep";
            $array_month[9]['counter']=0;
            $array_month[9]['barmonth']="Oct";
            $array_month[10]['counter']=0;
            $array_month[10]['barmonth']="Nov";
            $array_month[11]['counter']=0;
            $array_month[11]['barmonth']="Dec";

            foreach($get_graph as $row){
                if($row['barmonth']=='Jan'){
                    $array_month[0]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Feb'){
                    $array_month[1]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Mar'){
                    $array_month[2]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Apr'){
                    $array_month[3]['counter']=$row['counter'];
                }
                if($row['barmonth']=='May'){
                    $array_month[4]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Jun'){
                    $array_month[5]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Jul'){
                    $array_month[6]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Aug'){
                    $array_month[7]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Sep'){
                    $array_month[8]['counter']=$row['counter'];
                }

                if($row['barmonth']=='Oct'){
                    $array_month[9]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Nov'){
                    $array_month[10]['counter']=$row['counter'];
                }
                if($row['barmonth']=='Dec'){
                    $array_month[11]['counter']=$row['counter'];
                }
            
            }
            
            $data['get_graph']=$array_month;

            //Total Ampount graph
            $obj_graph_total=new TripBooking();
            $curr_year=date('Y');
            $get_graph_total=$obj_graph_total->select('SUM(booking_amount) as totalAmount, DATE_FORMAT(booking_date, "%b") as barmonth')->where('company_Id',$data['companyId'])->where('YEAR(booking_date)',$curr_year)->groupBy('month(booking_date)')->findAll();
           
            $array_month_total[0]['total']=0;
            $array_month_total[0]['barmonth']="Jan";
            $array_month_total[1]['total']=0;
            $array_month_total[1]['barmonth']="Feb";
            $array_month_total[2]['total']=0;
            $array_month_total[2]['barmonth']="Mar";
            $array_month_total[3]['total']=0;
            $array_month_total[3]['barmonth']="Apr";
            $array_month_total[4]['total']=0;
            $array_month_total[4]['barmonth']="May";
            $array_month_total[5]['total']=0;
            $array_month_total[5]['barmonth']="Jun";
            $array_month_total[6]['total']=0;
            $array_month_total[6]['barmonth']="Jul";
            $array_month_total[7]['total']=0;
            $array_month_total[7]['barmonth']="Aug";
            $array_month_total[8]['total']=0;
            $array_month_total[8]['barmonth']="Sep";
            $array_month_total[9]['total']=0;
            $array_month_total[9]['barmonth']="Oct";
            $array_month_total[10]['total']=0;
            $array_month_total[10]['barmonth']="Nov";
            $array_month_total[11]['total']=0;
            $array_month_total[11]['barmonth']="Dec";

            foreach($get_graph_total as $row){
                if($row['barmonth']=='Jan'){
                    $array_month_total[0]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Feb'){
                    $array_month_total[1]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Mar'){
                    $array_month_total[2]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Apr'){
                    $array_month_total[3]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='May'){
                    $array_month_total[4]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Jun'){
                    $array_month_total[5]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Jul'){
                    $array_month_total[6]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Aug'){
                    $array_month_total[7]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Sep'){
                    $array_month_total[8]['total']=$row['totalAmount'];
                }

                if($row['barmonth']=='Oct'){
                    $array_month_total[9]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Nov'){
                    $array_month_total[10]['total']=$row['totalAmount'];
                }
                if($row['barmonth']=='Dec'){
                    $array_month_total[11]['total']=$row['totalAmount'];
                }
            
            }
            
            $data['get_graph_total']=$array_month_total;//booking_amount
//print_r( $data['get_graph_total']);
//exit;


            
        }elseif($status==3){
            $obj_regUser=new Regular_user();
            $getCorUser=$obj_regUser->where('user_id',$user_id)->first();
            session()->set('name',$getCorUser['reg_name']);
            $obj_trip=new TripBooking();
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('user_id',$user_id)->findAll();                          
            $data['header']='View Bookings';
            $data['trips']=$getTrips;          

        }elseif($status==4){
            $obj_corUser=new Corporate_user();
            $getCorUser=$obj_corUser->where('user_id',$user_id)->first();
            session()->set('name',$getCorUser['cor_name']);
            session()->set('companyId',$getCorUser['cor_companyID']);  
            $obj_trip=new TripBooking();
            $getTrips=$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('user_id',$user_id)->paginate(20);                          
            $data['header']='View Bookings';
            $data['trips']=$getTrips;
            $data['pager'] =$obj_trip->join('cartype','cartype.ct_id=trip_booking.carType_id')->join('book_type','book_type.bt_id=trip_booking.bookType_id')->join('trip_type','trip_type.trt_id=trip_booking.tripType_id')->orderby('booking_id','DESC')->where('user_id',$user_id)->pager;
          
        }
        
           return view('dashboard/index', $data);
        
    }
    public function activate($userID)
    {
        $obj_user=new User();
        $values=['user_active'=>1];
        $update_query=$obj_user->update($userID,$values);
        if(!$update_query){
            return redirect()->to(base_url('dashboard/users'))->with('fail','Updation failed');
        }else{
            $obj_cuser= new Corporate_user;
            $sel_query=$obj_cuser->where('user_id',$userID)->first();
            $useremail=$sel_query['cor_email'];
            $username=$sel_query['cor_name'];
           
            $email = \Config\Services::email();
            $bookmail='noreply@verticsonline.com';
            $bookname='No-reply';
            $email->setFrom($bookmail, $bookname);
            $email->setTo($useremail);            
            //$email->setCC('razyusman@gmail.com');
            $email->setSubject('Your Account activated in Prominent');
             $message='<!DOCTYPE html>
                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
                        xmlns:o="urn:schemas-microsoft-com:office:office">
                    
                    <head>
                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                        <meta name="viewport" content="width=device-width"> 
                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                        <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
                        <title>Global supply chain challenges</title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                    
                    
                        <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
                    
                        <!-- CSS Reset : BEGIN -->
                        <style>
                            html,
                            body {
                                margin: 10px;
                                padding: 0 !important;
                                background-color: #ffffff;
                                font-family: "Roboto", sans-serif;
                    
                            }
                    
                            .container {
                                width: 900px;
                                margin: 0 auto;
                                border-radius: 0px;
                                border: 1px solid #8e7a3d;
                                border-left: 25px solid #8e7a3d;
                                background-color: #ffffff;
                            }
                    
                            .main-div {
                                width: 800px;
                                padding: 0 20px;
                                display: inline-block;
                                background-color: #ffffff;
                                
                            }
                    
                            .img-responsive {
                                width: 100%;
                            }
                    
                            ul {
                                margin: 0;
                                padding: 0;
                            }
                    
                            li {
                                margin: 10px 10px 0 30px;
                                padding: 0;
                                list-style: circle;
                                font-weight: 600;
                                font-size: 17px;
                                color: #2a3e6c;
                            }
                    
                            .footer {
                                width: 750px;
                                float: left;
                                padding: 25px 0;
                                border-top: 1px solid #ccc;
                            }
                            h1 {
                                font-size: 35px;
                                color: #a78f45;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                            }
                    
                            h2 {
                                font-size: 13px;
                                color: #333;
                                font-weight: 300;
                                text-decoration: none;
                                line-height: 19px;
                            }
                            h2 span{
                                font-size: 15px;
                                color: #333;
                                font-weight: 500;
                                text-decoration: none;
                                line-height: 23px;
                                float: right;
                                margin-top: 10px;
                            }
                            h3 {
                                font-size: 18px;
                                color: #333;
                                font-weight: 600;
                                text-decoration: none;
                                line-height: 19px;
                                margin: 0;
                                padding: 0;
                                margin-top: 40px;
                            }
                    
                            p {
                                font-size: 17px;
                                color: #000;
                                font-weight: 400;
                                text-decoration: none;
                                line-height: 34px;
                            }
                    
                            p span {
                                font-size: 18px;
                                color: #000;
                            }
                    
                            .row {
                                width: 750px;
                                float: left;
                                padding: 15px 0;
                                background-color: #ffffff;
                            }
                    
                            .text-center {
                                text-align: center;
                            }
                    
                            .text-left {
                                text-align: left;
                            }
                    
                            .pb-0 {
                                padding-bottom: 0 !important;
                            }
                    
                            .ban {
                                width: 800px !important;
                                float: left;
                                padding-top: 10px;
                            }
                    
                            .ban img {
                                width: 100% !important;
                            }
                    
                            @media screen and (max-width: 767px) {
                                .container {
                                    width: 100%;
                                    display: inline-block;
                                }
                    
                                .main-div {
                                    width: 90%;
                                }
                    
                                .ban {
                                    width: 100%;
                                }
                    
                                .row {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    
                    <body bgcolor="#FFFFFF" style="background-color: #ffffff;">
                        
                            <table align="center" width="800" style="border:1px; border-left: 15px; border-color:#8e7a3d; border-style: solid;">
                                <tr>
                                    <td>
                                        <div class="main-div">
                                        <table align="center" bgcolor="#ffffff" width="780">
                                            
                                            <tr>
                                                <td bgcolor="#ffffff">
                                                <p>
                                                Hello '.$username.',<br>
                                            </p>
                                             
                                            <p>
                                            Your account has been activated in Prominetlimo.com .You can login through <a href="http://prominentlimo.com/booking/">http://prominentlimo.com/booking/</a>
                                            </p>
                                                   
                                                    
                                                    
                                                    </table>
                                                    <p>
                                                    
                                                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#ffffff" align="center"><br>
                                                  
                                                </td>
                                            </tr>
                                            
                                        </table>
                                        </div>
                                    </td>
                                </tr>
                                
                                
                            </table>
                       
                    </body>
                    
                    </html>';
                    
            $email->setMessage($message); 
          
            if($email->send()){
                
            }else{
                $err=$email->printDebugger(['headers']);
                //print_r($err);
                
            }
            return redirect()->to(base_url('dashboard/users'))->with('success','Activated');
        }
    }

    public function deactivate($userID)
    {
        $obj_user=new User();
        $values=['user_active'=>0];
        $update_query=$obj_user->update($userID,$values);
        if(!$update_query){
            return redirect()->to(base_url('dashboard/users'))->with('fail','Updation failed');
        }else{
            return redirect()->to(base_url('dashboard/users'))->with('success','Deactivated');
        }

    }

    public function delete($userID)
    {
        $obj_user = new User();
        $obj_cuser= new Corporate_user();
        $query_del=$obj_user->where('user_id', $userID)->delete();
        if($query_del){
                $obj_cuser->where('user_id', $userID)->delete();
                return redirect()->to(base_url('dashboard/users'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('dashboard/users'))->with('fail','Deletion failed!!');
        }
       
    }
    public function users()
    {
            $user_id=session()->get('loggeduser');
            $status=session()->get('loggeduserstatus');
            $data=[
                'active'=>'users',
                 'userID'=>$user_id,
                'status'=>$status                            
            ];
            $obj_corAdmin=new CorporateAdmin();
            $getCorAdmin=$obj_corAdmin->where('user_id',$user_id)->first();
           
            $data['companyId']=$getCorAdmin['cadmin_id'];
            $data['companyName']=$getCorAdmin['cadmin_companyName'];
            
            session()->set('companyId',$getCorAdmin['cadmin_id']); 
            session()->set('name',$getCorAdmin['cadmin_companyName']);                  
        
            $obj_corUser= new Corporate_user();            
            $getCorUser=$obj_corUser->join('users','users.user_id=corporate_users.user_id')->where('corporate_users.cor_companyID',$data['companyId'])->orderBy('corporate_users.cor_companyID','ASC')->paginate(20);
           
            $data['corUser']=$getCorUser;
            $data['header']='Users of '.$data['companyName']; 
            $data['pager']=$obj_corUser->join('users','users.user_id=corporate_users.user_id')->where('corporate_users.cor_companyID',$data['companyId'])->orderBy('corporate_users.cor_companyID','ASC')->pager;
           
            return view('dashboard/listCorporateUsers', $data);
    }
}
?>