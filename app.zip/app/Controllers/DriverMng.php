<?php

namespace App\Controllers;
use App\Models\Drivers;

class DriverMng extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function show()
    {
        $user['user_id']=session()->get('loggeduser');
        $user['status']=session()->get('loggeduserstatus');
        return $user;    
    }
    public function index(){
        
       $userArray=$this->show();
       $obj_driver=new Drivers();
       $driversDetails=$obj_driver->orderby('driver_id','DESC')->paginate(20);

        $data=[
            'active'=>'driver',
            'userID'=>$userArray['user_id'],
            'status'=>$userArray['status'],
            'header'=>'Drivers Details',
            'details'=>$driversDetails
        ];
        $data['pager']=$obj_driver->orderby('driver_id','DESC')->pager;
        return view('dashboard/drivers', $data);
        
    }

    

    public function addNew()
    {
        $userArray=$this->show();
        $data=[
             'active'=>'driver',
             'userID'=>$userArray['user_id'],
             'status'=>$userArray['status'],
             'header'=>'New Driver Details'
            
         ];
         if($_POST):
            
            $validation = $this->validate([
                
                'email'=> [
                    'rules'=>'is_unique[drivers.driver_email]',
                    'errors'=>[
                               'is_unique'=>'Email already exist..please try another...'
                             ],
                    ],
                'contactNo'=>[
                    'rules'=>'is_unique[drivers.driver_contact]',
                    'errors'=>[
                            'is_unique'=>'Contact Number already exist...!!'
                     ],
                ],
                'licenseNo'=>[
                    'rules'=>'required|is_unique[drivers.driver_license]',
                    'errors'=>[
                            'required'=>'License Number required',
                            'is_unique'=>'License number already exist... !!'
                     ],
                ],
                'emiratesId'=>[
                    'rules'=>'required|is_unique[drivers.driver_emirates_id]',
                    'errors'=>[
                            'required'=>'Emirates Id required',
                            'is_unique'=>'Emirates ID already exist... !!'
                     ],
                ],
                'visa_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_visa_no]',
                    'errors'=>[
                            'required'=>'Visa number required',
                            'is_unique'=>'visa number already exist... !!'
                     ],
                ],
                'passport_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_passport_no]',
                    'errors'=>[
                            'required'=>'Passport number required',
                            'is_unique'=>'Passport number already exist... !!'
                     ],
                ],
                'permit_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_limousin_Permit_no]',
                    'errors'=>[
                            'required'=>'Limousine Permit number required',
                            'is_unique'=>'Limousine Permit number already exist... !!'
                     ],
                ],
                'photo' => [
                    'rules'=>'mime_in[photo,image/jpg,image/jpeg,image/png,image/gif]',
                    'errors'=>[
                            
                            'mime_in'=>'jpg,jpeg,png,gif are the allowed image type'
                    ],
                ],
                
                ]);
               
                if (!$validation){
                    
                    $data['validation']=$this->validator;
                    return view('dashboard/newDriver',$data);
                }else{
                    $name=$this->request->getPost('name');
                    $email=$this->request->getPost('email');
                    $contact=$this->request->getPost('contactNo');                    
                    $dob=$this->request->getPost('dob');
                    
                    $nationality=$this->request->getPost('nationality');
                    $address=$this->request->getPost('address');
                    $addressIndia=$this->request->getPost('addressIndia');

                    $licenseNo=$this->request->getPost('licenseNo'); 

                    $licenseExpM=$this->request->getPost('licenseExpM'); 
                    $licenseExpY=$this->request->getPost('licenseExpY');                
                    $licenseExp=$licenseExpM.'/'.$licenseExpY;

                    $emiratesId=$this->request->getPost('emiratesId');

                    $emiratesIdExpM=$this->request->getPost('emiratesIdExpM'); 
                    $emiratesIdExpY=$this->request->getPost('emiratesIdExpY');                
                    $emiratesIdExp=$emiratesIdExpM.'/'.$emiratesIdExpY;
                    
                    $emergency_contact=$this->request->getPost('emergency_contact');
                    $emergency_contactIn=$this->request->getPost('emergency_contactIn');
                    $passport_no=$this->request->getPost('passport_no');

                    $passport_expM=$this->request->getPost('passport_expM'); 
                    $passport_expY=$this->request->getPost('passport_expY');                
                    $passport_exp=$passport_expM.'/'.$passport_expY;
                   
                    $visa_no=$this->request->getPost('visa_no');

                    $visa_expM=$this->request->getPost('visa_expM'); 
                    $visa_expY=$this->request->getPost('visa_expY');                
                    $visa_exp=$visa_expM.'/'.$visa_expY;
                   
                    $permit_no=$this->request->getPost('permit_no');

                    $permit_expM=$this->request->getPost('permit_expM'); 
                    $permit_expY=$this->request->getPost('permit_expY');                
                    $permit_exp=$permit_expM.'/'.$permit_expY;

                    $daman_expM=$this->request->getPost('daman_expM'); 
                    $daman_expY=$this->request->getPost('daman_expY');                
                    $daman=$daman_expM.'/'.$daman_expY;

                    $join=$this->request->getPost('join_date');                  
                    
                    $leave=$this->request->getPost('leave_date');
                   
                    $return=$this->request->getPost('return_date');
                    $driver_history=$this->request->getPost('driver_history');
                    $vehicle_model=$this->request->getPost('vehicle_model');
                    $plate_no=$this->request->getPost('plate_no');
                    $file = $this->request->getFile('photo');
                    $date=date('Y-m-d');
                    $values=['driver_name'=>$name,
                                  'driver_email'=>$email,
                                  'driver_contact'=>$contact,
                                  'driver_nationality'=>$nationality,
                                  'driver_address'=>$address,
                                  'driver_address_india'=>$addressIndia,
                                  'driver_dob'=>$dob,
                                  'driver_license'=>$licenseNo,
                                  'driver_license_exp'=>$licenseExp,
                                  'driver_emirates_id'=>$emiratesId,
                                  'driver_emirates_exp'=>$emiratesIdExp,
                                  'driver_createdDate'=>$date,
                                  'driver_lastUpdatedDate'=>$date,
                                  'driver_emergency_contact'=>$emergency_contact,
                                  'driver_emergency_contactIn'=>$emergency_contactIn,
                                  'driver_passport_no'=>$passport_no,
                                  'driver_passport_exp'=>$passport_exp,
                                  'driver_visa_no'=>$visa_no,
                                  'driver_visa_exp'=>$visa_exp,
                                  'driver_limousin_Permit_no'=>$permit_no,
                                  'driver_limousin_Permit_exp'=>$permit_exp,
                                  'driver_daman_exp'=>$daman,
                                  'driver_join_date'=>$join,
                                  'driver_leave_date'=>$leave,
                                  'driver_return_date'=>$return,
                                  'driver_history'=>$driver_history,
                                  'driver_vehicle_model'=>$vehicle_model,
                                  'driver_plate_no'=>$plate_no
                                ];
                    if($file!=''){
                    $imgname=$file->getRandomName();
                    
                    $image = \Config\Services::image()
                            ->withFile($file)
                            ->resize(100, 100, true, 'height')
                            ->save(FCPATH .'/uploads/'. $imgname);

                    $file->move(WRITEPATH . 'uploads');
                    $values['driver_photo']=$imgname;
                    }
                   
                    $driver_obj= new Drivers();
                         
                        
                        $query_insert=$driver_obj->insert($values);
                        if($query_insert){
                            return redirect()->to(base_url('DriverMng'))->with('success','New Driver Details Saved');
                        }else{
                            return redirect()->to(base_url('DriverMng'))->with('fail','Adding new driver deatils is failed');
                        }
                }
    
            else:
                    return view('dashboard/newDriver',$data);
            endif;
    }

    

    public function edit($driverID)
    {
        if($_POST){
            
            $validation = $this->validate([
                
                'email'=> [
                    'rules'=>'is_unique[drivers.driver_email,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                               'is_unique'=>'Updated Email already exist..please try another...'
                             ],
                    ],
                'contactNo'=>[
                    'rules'=>'is_unique[drivers.driver_contact,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'is_unique'=>'Updated Contact Number already exist...!!'
                     ],
                ],
                'licenseNo'=>[
                    'rules'=>'required|is_unique[drivers.driver_license,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'required'=>'License Number required',
                            'is_unique'=>'Updated License number already exist... !!'
                     ],
                ],
                'emiratesId'=>[
                    'rules'=>'required|is_unique[drivers.driver_emirates_id,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'required'=>'Emirates Id required',
                            'is_unique'=>'Emirates ID already exist... !!'
                     ],
                ],
                'visa_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_visa_no,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'required'=>'Visa number required',
                            'is_unique'=>'visa number already exist... !!'
                     ],
                ],
                'passport_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_passport_no,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'required'=>'Passport number required',
                            'is_unique'=>'Passport number already exist... !!'
                     ],
                ],
                'permit_no'=>[
                    'rules'=>'required|is_unique[drivers.driver_limousin_Permit_no,drivers.driver_id,'.$driverID.']',
                    'errors'=>[
                            'required'=>'Limousine Permit number required',
                            'is_unique'=>'Limousine Permit number already exist... !!'
                     ],
                ],
                'photo' => [
                    'rules'=>'mime_in[photo,image/jpg,image/jpeg,image/png,image/gif]',
                    'errors'=>[
                            
                            'mime_in'=>'jpg,jpeg,png,gif are the allowed image type'
                    ],
                ],
                
                ]);
               
                if (!$validation){
                   
                    return redirect()->back()->withInput()->with('result', $this->validator->getErrors()); 
                }else{
                    $name=$this->request->getPost('name');
                    $email=$this->request->getPost('email');
                    $contact=$this->request->getPost('contactNo');

                    $dob=$this->request->getPost('dob');                    

                    $nationality=$this->request->getPost('nationality');
                    $address=$this->request->getPost('address');
                    $addressIndia=$this->request->getPost('addressIndia');
                    $licenseNo=$this->request->getPost('licenseNo');  

                    $licenseExpM=$this->request->getPost('licenseExpM'); 
                    $licenseExpY=$this->request->getPost('licenseExpY');                
                    $licenseExp=$licenseExpM.'/'.$licenseExpY;                  
                    
                    $emiratesId=$this->request->getPost('emiratesId');
                    $emiratesIdExpM=$this->request->getPost('emiratesIdExpM'); 
                    $emiratesIdExpY=$this->request->getPost('emiratesIdExpY');                
                    $emiratesIdExp=$emiratesIdExpM.'/'.$emiratesIdExpY;
                    
                    $emergency_contact=$this->request->getPost('emergency_contact');
                    $emergency_contactIn=$this->request->getPost('emergency_contactIn');
                    $passport_no=$this->request->getPost('passport_no');
                    $passport_expM=$this->request->getPost('passport_expM'); 
                    $passport_expY=$this->request->getPost('passport_expY');                
                    $passport_exp=$passport_expM.'/'.$passport_expY;

                    $visa_no=$this->request->getPost('visa_no');
                    $visa_expM=$this->request->getPost('visa_expM'); 
                    $visa_expY=$this->request->getPost('visa_expY');                
                    $visa_exp=$visa_expM.'/'.$visa_expY;

                    $permit_no=$this->request->getPost('permit_no');
                    $permit_expM=$this->request->getPost('permit_expM'); 
                    $permit_expY=$this->request->getPost('permit_expY');                
                    $permit_exp=$permit_expM.'/'.$permit_expY;                   

                    $daman_expM=$this->request->getPost('daman_expM'); 
                    $daman_expY=$this->request->getPost('daman_expY');                
                    $daman=$daman_expM.'/'.$daman_expY;

                    $join_date=$this->request->getPost('join_date'); 
                    $leave_date=$this->request->getPost('leave_date');
                    $return_date=$this->request->getPost('return_date');
                    $vehicle_model=$this->request->getPost('vehicle_model');
                    $plate_no=$this->request->getPost('plate_no');
                    $driver_history=$this->request->getPost('driver_history');
                    $date=date('Y-m-d');
                    $driver_obj= new Drivers();
                    $values=['driver_name'=>$name,
                             'driver_email'=>$email,
                             'driver_contact'=>$contact,
                             'driver_dob'=>$dob,
                             'driver_nationality'=>$nationality,
                             'driver_address'=>$address,
                             'driver_address_india'=>$addressIndia,
                             'driver_license'=>$licenseNo,
                             'driver_license_exp'=>$licenseExp,
                             'driver_emirates_id'=>$emiratesId,
                             'driver_emirates_exp'=>$emiratesIdExp,
                             'driver_emergency_contact'=>$emergency_contact,
                             'driver_emergency_contactIn'=>$emergency_contactIn,
                             'driver_passport_no'=>$passport_no,
                             'driver_passport_exp'=>$passport_exp,
                             'driver_visa_no'=>$visa_no,
                             'driver_visa_exp'=>$visa_exp,
                             'driver_limousin_Permit_no'=>$permit_no,
                             'driver_limousin_Permit_exp'=>$permit_exp,
                             'driver_leave_date'=>$leave_date,
                             'driver_daman_exp'=>$daman,
                             'driver_join_date'=>$join_date,
                             'driver_return_date'=>$return_date,
                             'driver_lastUpdatedDate'=>$date,
                             'driver_history'=>$driver_history,
                             'driver_vehicle_model'=>$vehicle_model,
                             'driver_plate_no'=>$plate_no
                             ];
                    $file = $this->request->getFile('photo');
                    if($file!=''){
                     $imgname=$file->getRandomName();
                     $image = \Config\Services::image()
                            ->withFile($file)
                            ->resize(100, 100, true, 'height')
                            ->save(FCPATH .'/uploads/'. $imgname);

                    $file->move(WRITEPATH . 'uploads');
                    $values['driver_photo']=$imgname;
                    $selquery=$driver_obj->where('driver_id', $driverID)->first();
                    $img=$selquery['driver_photo'];
                    }
                                                            
                    $update_query=$driver_obj->update($driverID,$values);
                    if(!$update_query){
                        return redirect()->to(base_url('DriverMng'))->with('fail','Updation failed');
                    }else{
                        if($file!=''){
                            if($img!=''){
                                unlink(FCPATH .'/uploads/'. $img);
                            }
                        }
                        return redirect()->to(base_url('DriverMng'))->with('success','Successfully updated !!!');
                    }
                }

        }else{
                $userArray=$this->show();     
                $driver_obj= new Drivers();
                $getDriver_info=$driver_obj->where('driver_id',$driverID)->first();
                $data=[
                    'active'=>'driver',
                    'userID'=>$userArray['user_id'],
                    'status'=>$userArray['status'],
                    'header'=>'Update Driver Details',
                    'driverInfo'=>$getDriver_info            
                 ];
                 return view('dashboard/editDriver',$data);
        }
    }

    public function delete($driverID)
    {
        $driverInfo = new Drivers();        
       
        $selquery=$driverInfo->where('driver_id', $driverID)->first();
        $img=$selquery['driver_photo'];
        $query_del=$driverInfo->where('driver_id', $driverID)->delete();
       if($query_del){
            if($img!=''){
              unlink(FCPATH .'/uploads/'. $img);
            }
            return redirect()->to(base_url('DriverMng'))->with('success','Deleted Successfully!!');
        }else{
            return redirect()->to(base_url('DriverMng'))->with('fail','Deletion failed!!');
        }
       
    }

   
}
?>