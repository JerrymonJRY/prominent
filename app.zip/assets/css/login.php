<?= $this->extend('layout/layoutAuth') ?>
<?= $this->section('content') ?>
    <section class="login-block">
        <!-- Container-fluid starts -->
        <div class="container v-center">
            <div class="row">
                <!-- <div class="col-sm-6 login-car sm-d-none">
                </div> -->
                <div class="col-12 card m-b-0">
                    <!-- Authentication card start -->

                    <form class="md-float-material form-material" method="POST" action="" >
                        <div class="text-center pt-3">
                            <img src="<?php echo base_url('assets/images/logo.png');?>" alt="logo.png">
                        </div>
                        <div class="auth-box">
                            <div class="card-block">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-center">Log In</h3>
                                    </div>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="text" name="username" id="username" class="form-control" required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Username</label>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="password" name="password" id="password" class="form-control" required>
                                    <span class="form-bar"></span>
                                    <label class="float-label">Password</label>
                                </div>
                                <?php
                                    if(!empty(session()->getFlashdata('result'))):
                                ?>
                                    <span class=" alert alert-danger"><?= session()->getFlashdata('result')?></span>
                                <?php endif;?>
                                <span class="text-danger"><?= isset($validation)?display_errors($validation,'username'): '' ?></span>
                                <span class="text-danger"><?= isset($validation)?display_errors($validation,'password'): '' ?></span>
                                <div class="row m-t-25 text-left">
                                    <div class="col-12">
                                        <div class="checkbox-fade fade-in-primary d-">
                                            <label>
                                                    <input type="checkbox" value="">
                                                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                    <span class="text-inverse">Remember me</span>
                                                </label>
                                        </div>
                                        <div class="forgot-phone text-right f-right">
                                            <a href="#" class="text-right f-w-600"> Forgot Password?</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20">Sign in</button>
                                    </div>
                                </div>
                                <div class="row m-t-25 text-left">
                                    <div class="col-12">
                                        <div class="checkbox-fade fade-in-primary d-">
                                            <label>
                                                    
                                                    
                                                    <span class="text-inverse"><a href="<?php echo base_url('Auth/regularSignUp');?>">Regular Signup</a></span>
                                                </label>
                                        </div>
                                        <div class="forgot-phone text-right f-right">
                                            <a href="<?php echo base_url('Auth/corporateSignUp');?>" class="text-right f-w-600">Corporate Signup</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- end of form -->
                </div>
                <!-- end of col-sm-12 -->
            </div>
            <!-- end of row -->
        </div>
        <!-- end of container-fluid -->
    </section>
    <?= $this->endSection() ?>
  
   